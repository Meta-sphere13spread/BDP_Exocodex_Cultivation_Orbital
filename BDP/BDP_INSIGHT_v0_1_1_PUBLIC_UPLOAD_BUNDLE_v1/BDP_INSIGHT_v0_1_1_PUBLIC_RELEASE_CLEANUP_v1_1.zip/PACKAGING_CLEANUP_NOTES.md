# Packaging cleanup notes

This package now uses a root-level `example_run.py` for the main user flow.

## Already changed

- `examples/example_run.py` moved to `example_run.py`.
- README quick start now points to `python example_run.py`.
- `__pycache__` folders removed from this package build.

## Keep for public package

- `example_run.py`
- `bdp_insight/api.py`
- `examples/example_direct_api.py`
- `examples/example_gemma.py`
- `README.md`
- `pyproject.toml`
- `bdp_insight/`
- `meta13_mri/` if required by attach/debugger internals

## Candidate removals before pip/PyPI final

Review before deleting:

- legacy BAT files, if any remain
- local credential txt files such as `rapidapi_key.txt`, `auth_token.txt`, `provider-side secret.txt`
- old patch scripts
- dev-only test files
- generated result folders

Customer examples must never include `provider-side secret`.
