# Packaging next steps

This build adds Python-first entry points:

```text
example_run.py           minimal copy/paste example
example_interactive.py   guided chat + optional dynamic/static dashboards
bdp_insight/cli.py       console scripts
bdp_insight/launchers.py dashboard subprocess helpers
```

## Local install test

```bash
pip install -e ".[hf,studio]"
python example_run.py
python example_interactive.py
bdp-insight-smoke
bdp-insight-chat
```

## Before PyPI/TestPyPI

Check and remove from public source distributions if present:

```text
__pycache__/
results/
rapidapi_key.txt
provider-side secret.txt
auth_token.txt
*.bat
old patch scripts
```

Customer examples must only request:

```text
rapidapi_url
rapidapi_host
rapidapi_key
```

Never request or expose:

```text
provider-side secret
Modal AUTH_TOKEN
provider secrets
```

## Release check pycache note

`__pycache__` folders can be created during normal imports, editable installs, or
`py_compile`. The release checker now removes project-local `__pycache__`
folders before and after compile validation, and ignores local virtual
environment folders such as `.venv_bdp`.

For a clean build, it is still recommended to create the venv outside the
release source tree, or remove `.venv*` before uploading source files.
