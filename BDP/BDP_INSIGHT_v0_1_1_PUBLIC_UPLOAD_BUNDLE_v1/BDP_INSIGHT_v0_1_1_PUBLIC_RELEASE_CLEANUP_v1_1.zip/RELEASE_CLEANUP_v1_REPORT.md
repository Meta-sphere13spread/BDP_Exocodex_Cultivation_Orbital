# BDP-insight v0.1.1 Public Release Cleanup v1

Source package:
BDP_INSIGHT_v0_1_1_STATIC_IRSDCE_CAPTURE_HOTFIX_PACKAGE.zip

Release root:
BDP_INSIGHT_v0_1_1_PUBLIC_RELEASE_CLEANUP_v1

Cleanup performed:
- Trimmed legacy examples from examples/
- Added MANIFEST.in
- Added LICENSE
- Added tools/check_release_ready.py
- Rewrote README.md for public release
- Removed credential/server/dev-only artifacts if present
- Removed __pycache__/results/build/dist artifacts
- Kept Python-first user examples:
  - example_run.py
  - example_interactive.py
  - examples/example_direct_api.py
  - examples/example_gemma.py

Release check output:

```text
[OK] required root files exist
[OK] forbidden filenames absent
[OK] public files do not expose provider-side secret wording
[OK] py_compile passed
[OK] release-ready checks passed
```
