# Static Studio IRS-DCE capture note

## Problem

The IRS-DCE Dynamics tab requires a selected capture run whose
`result_minimal.json` includes:

```json
"hidden_states_per_layer": [...]
```

Older public `bdp_insight` builds wrote only prompt/answer previews, so Static
Studio could find a capture directory but IRS-DCE returned:

```text
No capture run with hidden states selected.
```

## Fix in this patch

- `bdp_insight/capture_basic.py` now preserves optional `hidden_states_per_layer`.
- `bdp_insight/attach.py` captures per-layer hidden-state token matrices when
  `enable_capture=True`.
- `bdp_insight.api.attach_hodge_debugger(...)` defaults to `enable_capture=True`.
- `example_run.py` uses `enable_capture=True`.
- `bdp-insight-chat` captures hidden states by default; use `--no-capture` to disable.

## Notes

Hidden-state capture performs one extra forward pass after generation. For long
answers or large models, this costs time and memory. You can tune:

```bash
set BDP_STATIC_CAPTURE_MAX_TOKENS=128
set BDP_STATIC_CAPTURE_HIDDEN_STRIDE_THRESHOLD=1024
```

Then run:

```bash
python example_interactive.py
```

Launch Static Studio, generate at least one answer, then Rescan.
