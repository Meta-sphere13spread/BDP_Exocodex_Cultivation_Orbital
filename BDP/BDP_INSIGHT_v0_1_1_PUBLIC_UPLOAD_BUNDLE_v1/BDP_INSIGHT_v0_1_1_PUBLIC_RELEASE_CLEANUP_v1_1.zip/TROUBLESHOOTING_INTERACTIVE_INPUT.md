# Interactive input troubleshooting

## Error: `unknown url type: 'y/v1/hodge/convert'`

This means `y` was entered at the RapidAPI URL prompt. The dashboard yes/no
question comes later.

Correct flow:

```text
RapidAPI URL [https://bdp-insight-l2.p.rapidapi.com/v1/hodge/convert]:
  -> press Enter, or paste full URL

RapidAPI Host [bdp-insight-l2.p.rapidapi.com]:
  -> press Enter, or paste host

RapidAPI Key:
  -> paste X-RapidAPI-Key

Launch dynamic dashboard? [y/N]:
  -> now type y if desired
```

Client code must use only:

```text
rapidapi_url
rapidapi_host
rapidapi_key
```

Do not paste `provider-side secret`; it is provider-side only.
