"""BDP Insight — MRI Signal · Type 1 (Public Reference, Prototype).

This package is an intervention-aware diagnostic layer.  It does NOT replace
internal viewers like NNsight, TransformerLens, Captum, or LIT.  Instead it
reads "what was changed and how the change propagated" in a single sober frame.

Five indicators (free, prototype):
    1. surgery_impact            — Low / Moderate / High + affected_stage + stability
    2. dependency_shift          — changed_anchor + result_path bucket + small graph
    3. stale_reasoning           — consistency Stable / Stale + warning
    4. continuation_recond       — Reconditioned / Partially / Stale / No hit
    5. intervention_timeline     — ordered list of normalised events

All indicators take an InterventionEvent (or list) and return natural-language
labels.  Raw tensors / exact float weights / candidate ranks / selector
internals are never exposed by this package.

Product line marker (2026-05-03 user policy):
    `__product_line__ = "mri_signal_type_1"`
        Public reference — OBDA / IRS-DCE / lens output / attention output.
        Already published research artefacts.  Free.
    Future product line "whitebox_mri" (brain-anatomical visualisation)
    will live in a separate sub-package.
"""
from __future__ import annotations

import os
import sys

__version__       = "0.1.1"
__prototype__     = True
__release_phase__ = "Phase 0–6 — schema + 5 indicators + cherry-pick + dashboard + studio + tests + packaging"
__product_line__  = "mri_signal_type_1"   # ← 2026-05-03 split: type 1 = public reference

# Re-exports for ergonomic import:
#   from bdp_insight import InterventionEvent, indicators
from .intervention_event import InterventionEvent, normalize_event  # noqa: E402, F401

# Lazy import to keep `import bdp_insight` cheap and to avoid pulling indicator
# modules when the user only wants the schema.  The actual functions live in
# bdp_insight.indicators.*.
from . import indicators  # noqa: E402, F401


# ──────────────────────────────────────────────────────────────────────
# Prototype banner — emitted once per Python process to stderr.
# Suppressed by setting BDP_INSIGHT_QUIET=1 (CI-friendly).
# Per user requirement: callers must SEE the prototype label early so
# they don't mistake this for a finished product.
# ──────────────────────────────────────────────────────────────────────
_BANNER_FLAG = "_BDP_INSIGHT_BANNER_SHOWN"


def _emit_banner_once() -> None:
    if os.environ.get("BDP_INSIGHT_QUIET", "").strip() in ("1", "true", "yes"):
        return
    if getattr(sys.modules[__name__], _BANNER_FLAG, False):
        return
    setattr(sys.modules[__name__], _BANNER_FLAG, True)
    print(
        f"[BDP_INSIGHT v{__version__} · PROTOTYPE · {__product_line__}] "
        f"intervention-aware MRI · 5 indicators · phase={__release_phase__}",
        file=sys.stderr,
    )


_emit_banner_once()


# Public API surface
__all__ = [
    "__version__",
    "__prototype__",
    "__release_phase__",
    "__product_line__",
    "InterventionEvent",
    "normalize_event",
    "indicators",
]


# Public v0.1.1 HodgeConverter API surface
try:
    from .api import (  # noqa: F401
        BDPHodgeConfig,
        attach_hodge_debugger,
        check_rapidapi_config,
        configure_rapidapi,
        generate_text,
        queue_hodge_output_intervention,
    )
except Exception:
    # Keep import bdp_insight robust even if optional HF deps are absent.
    pass
