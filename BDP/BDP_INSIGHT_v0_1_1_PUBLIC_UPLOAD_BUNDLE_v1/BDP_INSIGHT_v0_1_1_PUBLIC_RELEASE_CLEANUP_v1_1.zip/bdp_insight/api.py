"""Public Python API for BDP-insight L2 HodgeConverter v0.1.1.

This module is the recommended integration surface for API Hub users.
Users provide their RapidAPI values as function arguments.  The wrapper then
configures the existing runtime so the model's generate() path can use the
server-bound HodgeConverter output-prefix intervention.

Important separation:
- Customer/client code uses: rapidapi_url, rapidapi_host, rapidapi_key.
- Provider-side provider-side secret is never used here.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Optional
import json
import os
import time

from .attach import attach_debugger as _attach_debugger


@dataclass
class BDPHodgeConfig:
    """Client-side RapidAPI/API Hub configuration.

    Parameters are intentionally explicit so examples can be copy-pasted from
    the RapidAPI Code Snippet into Python code without using .bat files or
    local text config files.
    """

    rapidapi_url: str
    rapidapi_host: str
    rapidapi_key: str
    timeout_sec: int = 60
    debug: bool = False
    allow_underscore_ssl_fallback: Optional[bool] = None
    paid_key_hint: str = "bdp-insight-rapidapi"

    def normalized_url(self) -> str:
        """Return normalized RapidAPI endpoint URL.

        Accepted forms:
        - full URL: https://<slug>.p.rapidapi.com/v1/hodge/convert
        - path only: /v1/hodge/convert, combined with rapidapi_host

        Intentionally do not turn arbitrary text such as "y" into a URL.
        That prevents accidental dashboard yes/no input from becoming
        "y/v1/hodge/convert".
        """
        url = str(self.rapidapi_url or "").strip()
        host = self.normalized_host()
        if not url:
            return url
        if url.startswith("/"):
            return ("https://" + host + url) if host else url
        if not (url.startswith("https://") or url.startswith("http://")):
            return url
        if "/v1/hodge/convert" not in url:
            url = url.rstrip("/") + "/v1/hodge/convert"
        return url

    def normalized_host(self) -> str:
        return str(self.rapidapi_host or "").strip()

    def masked_key(self) -> str:
        key = str(self.rapidapi_key or "").strip()
        if len(key) <= 12:
            return "[set]" if key else "[missing]"
        return key[:6] + "..." + key[-4:]

    def apply_env(self) -> None:
        """Apply config to the existing runtime via environment variables.

        The internal code already supports env-based configuration.  This
        method simply lets users pass values as Python arguments instead of
        writing rapidapi_url.txt / rapidapi_host.txt / rapidapi_key.txt.
        """
        url = self.normalized_url()
        host = self.normalized_host()
        key = str(self.rapidapi_key or "").strip()

        if not url.startswith("https://"):
            raise ValueError(
                "rapidapi_url must be a full https:// URL or /v1/hodge/convert path with a valid host. "
                f"Got {url!r}. If you meant to answer yes/no for dashboard launch, press Enter at the URL prompt first."
            )
        if not host:
            raise ValueError("rapidapi_host is required, e.g. bdp-insight-l2.p.rapidapi.com")
        if not key:
            raise ValueError("rapidapi_key is required. Paste your X-RapidAPI-Key from the API Hub Code Snippet.")

        os.environ["BDP_RAPIDAPI_URL"] = url
        os.environ["BDP_RAPIDAPI_HOST"] = host
        os.environ["BDP_RAPIDAPI_KEY"] = key
        os.environ["BDP_RAPIDAPI_TIMEOUT"] = str(int(self.timeout_sec))
        os.environ["BDP_RAPIDAPI_DEBUG"] = "1" if self.debug else "0"

        if self.allow_underscore_ssl_fallback is None:
            allow = "_" in host
        else:
            allow = bool(self.allow_underscore_ssl_fallback)
        os.environ["BDP_RAPIDAPI_ALLOW_UNDERSCORE_SSL_FALLBACK"] = "1" if allow else "0"

        # Product path: paid L2 via API Hub / Modal.  Prompt-side input bridge
        # stays disabled so HodgeConverter uses hidden output-prefix fallback.
        os.environ["META13_ENABLE_PAID"] = "1"
        os.environ["META13_PAID_MODE"] = "modal_remote"
        os.environ["META13_PAID_KEY"] = self.paid_key_hint or "bdp-insight-rapidapi"
        os.environ["BDP_HODGE_OUTPUT_FALLBACK_ONLY"] = "1"
        os.environ["BDP_ALLOW_HODGE_INPUT_BRIDGE"] = "0"


def check_rapidapi_config(config: BDPHodgeConfig) -> Dict[str, Any]:
    """Return a public-safe validation summary."""
    url = config.normalized_url()
    host = config.normalized_host()
    key = str(config.rapidapi_key or "").strip()
    missing = []
    if not url:
        missing.append("rapidapi_url")
    if not host:
        missing.append("rapidapi_host")
    if not key:
        missing.append("rapidapi_key")

    warnings = []
    if url and not url.startswith("https://"):
        warnings.append("rapidapi_url must start with https:// or be a /v1/hodge/convert path with host")
        missing.append("valid_rapidapi_url")
    if url and "/v1/hodge/convert" not in url:
        warnings.append("rapidapi_url should point to /v1/hodge/convert")
    if host and not host.endswith(".p.rapidapi.com"):
        warnings.append("rapidapi_host usually ends with .p.rapidapi.com")
    if "_" in host:
        warnings.append("RapidAPI host contains underscore; prefer a hyphen-only API slug for production.")

    return {
        "ok": not missing,
        "missing": missing,
        "warnings": warnings,
        "rapidapi_url": url,
        "rapidapi_host": host,
        "rapidapi_key": config.masked_key(),
    }


def configure_rapidapi(config: BDPHodgeConfig) -> BDPHodgeConfig:
    """Apply RapidAPI configuration and return the same config."""
    config.apply_env()
    return config


def attach_hodge_debugger(
    *,
    model: Any,
    tokenizer: Any,
    config: BDPHodgeConfig,
    model_id: str = "",
    run_dir: str = "results/bdp_hodge_run",
    outdir: str = "results/bdp_hodge_capture",
    max_new_tokens_hint: Optional[int] = None,
    enable_l1: bool = True,
    enable_capture: bool = True,
) -> Any:
    """Attach BDP-insight Hodge debugger to an already loaded HF-like model.

    The returned object is the same model instance with generate() wrapped.
    After this, users can keep calling model.generate(...) normally.

    By default, capture is enabled so Static Studio / IRS-DCE Dynamics can
    read hidden_states_per_layer from result_minimal.json. Set
    enable_capture=False to skip the extra hidden-state forward pass.
    """
    config.apply_env()
    model = _attach_debugger(
        model,
        tokenizer=tokenizer,
        model_id=model_id,
        run_dir=run_dir,
        outdir=outdir,
        max_new_tokens_hint=max_new_tokens_hint,
        enable_l1=enable_l1,
        enable_capture=enable_capture,
        paid_key=config.paid_key_hint or "bdp-insight-rapidapi",
        paid_mode="modal_remote",
        paid_enabled=True,
        allow_local_import=False,
    )
    return model


def queue_hodge_output_intervention(
    *,
    run_dir: str = "results/bdp_hodge_run",
    new_word: str,
    target_regex: Optional[str] = None,
    wait_tokens: int = 8,
    continuation_tokens: int = 32,
    old_word: Optional[str] = None,
) -> Path:
    """Queue one L2 Hodge output-prefix intervention for the next generate().

    This writes the same dynamic-debug command that the dashboard button writes.
    The product path keeps the original prompt unchanged, watches the partial
    generated output, calls the API Hub / Modal Hodge kernel when the target
    appears, and resumes continuation from the patched prefix.
    """
    dyn = Path(run_dir).resolve() / "dynamic_debug"
    dyn.mkdir(parents=True, exist_ok=True)
    cmd_path = dyn / "commands.jsonl"
    cmd_path.touch(exist_ok=True)

    payload: Dict[str, Any] = {
        "new_word": str(new_word),
        "replacement": str(new_word),
        "value": str(new_word),
        "auto_output_fallback": True,
        "hodge_wait_tokens": int(wait_tokens),
        "wait_tokens": int(wait_tokens),
        "after_tokens": int(wait_tokens),
        "continuation_tokens": int(continuation_tokens),
        "stabilize_prefix": True,
        "public_safe": True,
    }
    if target_regex is not None and str(target_regex).strip():
        payload["target_regex"] = str(target_regex).strip()
    if old_word is not None and str(old_word).strip():
        payload["old_word"] = str(old_word).strip()

    cmd = {
        "op": "hodge_token_auto",
        "payload": payload,
        "source": "bdp_insight.api",
        "ts": time.time(),
    }
    with cmd_path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(cmd, ensure_ascii=False) + "\n")
    return cmd_path


def generate_text(
    *,
    model: Any,
    tokenizer: Any,
    prompt: str,
    max_new_tokens: int = 128,
    system: str = "You are a helpful assistant. Answer in the user's language.",
    do_sample: bool = False,
) -> str:
    """Small HF generation helper used by examples.

    Users can replace this with their own generation code.  The important part
    is that model.generate() is called after attach_hodge_debugger(...).
    """
    messages = [
        {"role": "system", "content": system},
        {"role": "user", "content": prompt},
    ]
    if hasattr(tokenizer, "apply_chat_template") and getattr(tokenizer, "chat_template", None):
        text = tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
    else:
        text = f"Question: {prompt}\nAnswer:"
    inputs = tokenizer(text, return_tensors="pt")
    try:
        device = next(model.parameters()).device
        inputs = {k: v.to(device) for k, v in inputs.items()}
    except Exception:
        pass

    kwargs = {
        "max_new_tokens": int(max_new_tokens),
        "do_sample": bool(do_sample),
        "pad_token_id": getattr(tokenizer, "pad_token_id", None) or getattr(tokenizer, "eos_token_id", None),
    }
    out = model.generate(**inputs, **kwargs)
    in_len = int(inputs["input_ids"].shape[-1])
    return tokenizer.decode(out[0][in_len:], skip_special_tokens=True).strip()


__all__ = [
    "BDPHodgeConfig",
    "check_rapidapi_config",
    "configure_rapidapi",
    "attach_hodge_debugger",
    "queue_hodge_output_intervention",
    "generate_text",
]
