# -*- coding: utf-8 -*-
from __future__ import annotations

import json
import os
import tempfile
import time
from pathlib import Path
from typing import Any, Dict


def atomic_write_json(
    path: str | Path,
    obj: Any,
    *,
    retries: int = 12,
    delay: float = 0.035,
) -> None:
    """Windows-safe JSON writer.

    v1.9 hotfix: os.replace(tmp, path) can raise PermissionError on Windows
    when the dashboard, editor, antivirus, or indexer briefly holds
    current_state.json. State files are diagnostic artifacts, so retry and then
    fall back to direct write instead of crashing generation/freeze.
    """
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)

    text = json.dumps(obj, ensure_ascii=False, indent=2, default=str)

    fd, tmp_name = tempfile.mkstemp(
        prefix=path.name + '.',
        suffix='.tmp',
        dir=str(path.parent),
        text=True,
    )
    tmp = Path(tmp_name)
    try:
        with os.fdopen(fd, 'w', encoding='utf-8', newline='\n') as f:
            f.write(text)
            f.write('\n')
            f.flush()
            try:
                os.fsync(f.fileno())
            except OSError:
                pass

        last_err: BaseException | None = None
        for _ in range(max(1, int(retries))):
            try:
                os.replace(str(tmp), str(path))
                return
            except PermissionError as exc:
                last_err = exc
                time.sleep(delay)
            except OSError as exc:
                last_err = exc
                time.sleep(delay)

        try:
            path.write_text(text + '\n', encoding='utf-8')
            return
        except Exception:
            if last_err is not None:
                raise last_err
            raise
    finally:
        try:
            if tmp.exists():
                tmp.unlink()
        except Exception:
            pass


def atomic_append_jsonl(path: str | Path, obj: Dict[str, Any]) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('a', encoding='utf-8') as f:
        f.write(json.dumps(obj, ensure_ascii=False, default=str) + '\n')


def atomic_read_json(path: str | Path, default: Any = None) -> Any:
    try:
        p = Path(path)
        if not p.exists():
            return default
        return json.loads(p.read_text(encoding='utf-8'))
    except Exception:
        return default
