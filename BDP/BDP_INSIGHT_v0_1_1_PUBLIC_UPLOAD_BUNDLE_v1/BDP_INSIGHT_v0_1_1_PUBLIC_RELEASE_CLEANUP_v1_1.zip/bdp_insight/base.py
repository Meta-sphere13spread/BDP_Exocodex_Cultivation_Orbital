from __future__ import annotations

from dataclasses import dataclass
from types import SimpleNamespace
from typing import Any, Dict
from pathlib import Path
import time

# v0.4: lazy torch import. Importing torch at package import time can slow or
# hang lightweight debugger use cases. HF generation imports torch only when
# _generate_text() is actually called.
torch = None

from .capture_basic import BasicCaptureWriter
from .debug_control import DebugController
from .entitlement import RuntimeEntitlement, resolve_entitlement


@dataclass
class BaseRunResult:
    answer: str
    route: str = "BASE"
    closure_pass: bool = True
    latency_sec: float = 0.0
    problem_id: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return dict(
            answer=self.answer,
            route=self.route,
            closure_pass=self.closure_pass,
            latency_sec=self.latency_sec,
            problem_id=self.problem_id,
        )


class BaseModelDebugCore:
    """Free distribution wrapper for a raw HF-like model.

    Local capabilities:
      - basic static metadata capture
      - L1 prompt rewrite via file-backed command queue
      - debug state/events dashboard compatibility

    Not included locally:
      - L2/L3 surgery
      - Deep Insight metrics
    """

    def __init__(
        self,
        model: Any,
        tokenizer: Any,
        *,
        outdir: str = "results/base_mri_capture",
        run_dir: str = "results/base_debug_run",
        model_id: str = "base_model",
        paid_key: str | None = None,
        paid_mode: str | None = None,
        paid_enabled: bool | None = None,
        allow_local_import: bool = False,
    ):
        self.model = model
        self.tokenizer = tokenizer
        self.model_id = model_id or getattr(getattr(model, "config", None), "name_or_path", "base_model")
        self.outdir = str(Path(outdir).resolve())
        self.run_dir = str(Path(run_dir).resolve())
        self.enable_mri = True
        self.feature_flags = SimpleNamespace()
        self.pressure = SimpleNamespace(basis_weights={})
        self._pending_prompt_rewrite = ""
        self._debug_abort_requested = False
        self._hard_abort_persistent = False
        # v1.10: 다음 generate 중간 L1 rewrite 예약 상태.
        # 실제 L2/L3는 무료판에서 차단되지만, L1부터 mid-turn UX를 검증한다.
        self._l1_mid_rewrite_armed = False
        self._l1_mid_rewrite_after_tokens = 8
        # v1.12: runtime free/paid gate. No key => free. Key => paid path opens.
        self.entitlement: RuntimeEntitlement = resolve_entitlement(
            paid_key=paid_key,
            paid_mode=paid_mode,
            paid_enabled=paid_enabled,
            client_version="0.1.13.4-runtime",
            allow_local_import=allow_local_import,
        )
        self._pending_l2_token_surgery = []
        self._pending_l3_embed_surgery = []
        self.capture_writer = BasicCaptureWriter(outdir=self.outdir)
        self.debug_controller = DebugController(self.run_dir, run_id="base_model_debugger", entitlement=self.entitlement)

    def status(self) -> Dict[str, Any]:
        return {
            "ok": True,
            "mode": "base_model_debugger_paid" if self.entitlement.paid_enabled else "base_model_debugger_free",
            "model_id": self.model_id,
            "mri_outdir": self.outdir,
            "run_dir": self.run_dir,
            "enable_mri": self.enable_mri,
            "tier": self.entitlement.tier,
            "paid_enabled": self.entitlement.paid_enabled,
            "paid_mode": self.entitlement.paid_mode,
            "entitlement": self.entitlement.public_dict(),
            "free_features": ["static_basic_capture", "dashboard_state", "l1_prompt_rewrite"],
            "paid_features": ["l2_hodge_auto", "l2_hodge_output_intercept"],
            "copilot": False,
        }

    def debug_snapshot(self) -> Dict[str, Any]:
        return {"status": self.status()}

    def _device(self):
        try:
            return next(self.model.parameters()).device
        except Exception:
            return None

    def _ensure_torch(self):
        global torch
        if torch is None:
            try:
                import torch as _torch
            except Exception as exc:
                raise RuntimeError("torch is required for generation; install meta13-mri[hf]") from exc
            torch = _torch
        return torch


    def _wait_for_l1_mid_rewrite(self, *, phase: str, source: str, partial_preview: str, prompt_preview: str) -> None:
        """v1.10 mid-turn L1 gate.

        A short partial generation is already available. The runner now pauses
        before returning any answer to the user, so the dashboard can queue a
        rewrite_prompt command and then resume. If no rewrite is supplied, the
        original prompt is regenerated normally after resume.
        """
        controller = getattr(self, "debug_controller", None)
        if controller is None:
            return

        controller.pause_requested = True
        now = time.time()
        event = {
            "kind": "l1_mid_rewrite_enter",
            "phase": phase,
            "source": source,
            "partial_preview": partial_preview[:240],
            "prompt_preview": prompt_preview[:240],
            "ts": now,
            "tier": "free_l1",
        }
        controller.queue.append_event(event)
        state = controller._snapshot(self, "mid_generate_l1_wait", {
            "waiting_for": "l1_rewrite_or_resume",
            "partial_answer_preview": partial_preview[:240],
            "prompt_preview": prompt_preview[:240],
            "route": "L1_MID_REWRITE_WAIT",
        }, source)
        try:
            controller.queue.write_state(state)
        except Exception as exc:
            controller.queue.append_event({
                "kind": "state_write_skipped",
                "reason": type(exc).__name__,
                "error": str(exc),
                "phase": "l1_mid_rewrite_enter",
                "source": source,
                "ts": time.time(),
            })

        last_heartbeat = 0.0
        while True:
            time.sleep(0.2)
            now = time.time()
            try:
                snap = controller.poll_commands_only(
                    self,
                    "mid_generate_l1_wait",
                    {
                        "waiting_for": "l1_rewrite_or_resume",
                        "partial_answer_preview": partial_preview[:240],
                        "prompt_preview": prompt_preview[:240],
                        "route": "L1_MID_REWRITE_WAIT",
                    },
                    source,
                    write_state=False,
                    append_event=False,
                )
            except RuntimeError as exc:
                if "DebugAbortRequested" in str(exc):
                    controller.queue.append_event({
                        "kind": "l1_mid_rewrite_abort",
                        "phase": phase,
                        "source": source,
                        "ts": time.time(),
                    })
                raise

            if now - last_heartbeat >= 2.0:
                controller.queue.append_event({
                    "kind": "l1_mid_rewrite_wait",
                    "phase": phase,
                    "source": source,
                    "has_pending_rewrite": bool(getattr(self, "_pending_prompt_rewrite", "")),
                    "ts": now,
                })
                last_heartbeat = now

            if not snap.get("paused"):
                controller.queue.append_event({
                    "kind": "l1_mid_rewrite_exit",
                    "phase": phase,
                    "source": source,
                    "has_pending_rewrite": bool(getattr(self, "_pending_prompt_rewrite", "")),
                    "ts": time.time(),
                    "tier": "free_l1",
                })
                try:
                    exit_state = controller._snapshot(self, phase, {
                        "route": "L1_MID_REWRITE_RESUME",
                        "has_pending_rewrite": bool(getattr(self, "_pending_prompt_rewrite", "")),
                    }, source)
                    exit_state["paused"] = False
                    controller.queue.write_state(exit_state)
                except Exception as exc:
                    controller.queue.append_event({
                        "kind": "state_write_skipped",
                        "reason": type(exc).__name__,
                        "error": str(exc),
                        "phase": "l1_mid_rewrite_exit",
                        "source": source,
                        "ts": time.time(),
                    })
                return

    def _wait_if_paused(self, *, phase: str, source: str) -> None:
        """v1.9 next-turn freeze gate for MRISession/BaseModelDebugCore.run().

        The freeze wait loop only polls commands. It writes current_state.json
        once on freeze_enter and once on freeze_exit to avoid Windows file lock
        crashes while the dashboard is polling the same file.
        """
        controller = getattr(self, "debug_controller", None)
        if controller is None:
            return
        snap = controller.poll_commands_only(
            self,
            "freeze_precheck",
            {"freeze_phase": phase},
            source,
            write_state=True,
            append_event=False,
        )
        if not snap.get("paused"):
            return
        controller.queue.append_event({
            "kind": "freeze_enter",
            "phase": phase,
            "source": source,
            "ts": time.time(),
        })
        try:
            enter_state = dict(snap)
            enter_state.update({"phase": "freeze_wait", "paused": True})
            enter_extra = dict(enter_state.get("extra") or {})
            enter_extra.update({"waiting_for": "resume_or_abort", "freeze_phase": phase})
            enter_state["extra"] = enter_extra
            controller.queue.write_state(enter_state)
        except Exception as exc:
            controller.queue.append_event({
                "kind": "state_write_skipped",
                "reason": type(exc).__name__,
                "error": str(exc),
                "phase": "freeze_enter",
                "source": source,
                "ts": time.time(),
            })
        last_heartbeat = 0.0
        snap2 = snap
        while True:
            time.sleep(0.2)
            now = time.time()
            try:
                snap2 = controller.poll_commands_only(
                    self,
                    "freeze_wait",
                    {"waiting_for": "resume_or_abort", "freeze_phase": phase},
                    source,
                    write_state=False,
                    append_event=False,
                )
            except RuntimeError as exc:
                if "DebugAbortRequested" in str(exc):
                    controller.queue.append_event({
                        "kind": "freeze_abort",
                        "phase": phase,
                        "source": source,
                        "ts": time.time(),
                    })
                raise
            if now - last_heartbeat >= 2.0:
                controller.queue.append_event({
                    "kind": "freeze_wait",
                    "phase": phase,
                    "source": source,
                    "paused": bool(snap2.get("paused")),
                    "ts": now,
                })
                last_heartbeat = now
            if not snap2.get("paused"):
                controller.queue.append_event({
                    "kind": "freeze_exit",
                    "phase": phase,
                    "source": source,
                    "ts": time.time(),
                })
                try:
                    exit_state = dict(snap2)
                    exit_state.update({"phase": phase, "paused": False})
                    controller.queue.write_state(exit_state)
                except Exception as exc:
                    controller.queue.append_event({
                        "kind": "state_write_skipped",
                        "reason": type(exc).__name__,
                        "error": str(exc),
                        "phase": "freeze_exit",
                        "source": source,
                        "ts": time.time(),
                    })
                return



    def _route_with_paid(self, route: str, suffix: str) -> str:
        return route if suffix in route else f"{route}+{suffix}"

    def _apply_pending_l2_to_prompt(self, prompt: str, active_route: str, *, source: str) -> tuple[str, str]:
        """MRISession text path: apply paid L2 word replacement before tokenization."""
        pending = list(getattr(self, "_pending_l2_token_surgery", []) or [])
        self._pending_l2_token_surgery = []
        if not pending:
            return prompt, active_route
        if not self.entitlement.paid_enabled:
            for item in pending:
                self.debug_controller.queue.append_event({
                    "kind": "paid_surgery_blocked_late",
                    "function_id": item.get("function_id"),
                    "reason": "entitlement missing",
                    "tier": "free",
                    "ts": time.time(),
                })
            return prompt, active_route
        for item in pending:
            payload = dict(item.get("payload") or {})
            function_id = item.get("function_id", "l2.swap_token")
            changed = False
            meta = {}
            route_name = "L2_TOKEN_SURGERY"
            if function_id == "l2.hodge_auto" or str(item.get("op", "")).lower() in {"hodge_token_auto", "hodge_auto", "hodge_convert", "hodge_token_convert"}:
                from .paid_local_ops import hodge_auto_replace_text
                new_value = payload.get("new_word", payload.get("value", payload.get("replacement", "")))
                prompt2, changed, meta = hodge_auto_replace_text(
                    prompt,
                    new_value,
                    selector=str(payload.get("selector", payload.get("mode", "auto")) or "auto"),
                    target_regex=payload.get("target_regex"),
                )
                if changed:
                    prompt = prompt2
                    active_route = self._route_with_paid(active_route, "L2_HODGE_AUTO")
                    route_name = "L2_HODGE_AUTO"
            else:
                old = payload.get("old_word")
                new = payload.get("new_word")
                if old is not None and new is not None and str(old) in prompt:
                    prompt = prompt.replace(str(old), str(new), 1)
                    changed = True
                    active_route = self._route_with_paid(active_route, "L2_TOKEN_SURGERY")
                meta = {
                    "mode": "text_prompt_replace",
                    "old_word_preview": str(old)[:80],
                    "new_word_preview": str(new)[:80],
                }
            self.debug_controller.queue.append_event({
                "kind": "paid_surgery_applied" if changed else "paid_surgery_noop",
                "function_id": function_id,
                "route": route_name,
                "changed": changed,
                "meta": meta,
                "source": source,
                "tier": "paid",
                "actual_model_event": True,
                "preview_only": False,
                "ts": time.time(),
            })
        return prompt, active_route

    def _install_pending_l3_hooks(self, *, source: str) -> tuple[list, str]:
        pending = list(getattr(self, "_pending_l3_embed_surgery", []) or [])
        self._pending_l3_embed_surgery = []
        handles = []
        route_suffix = ""
        if not pending:
            return handles, route_suffix
        if not self.entitlement.paid_enabled:
            for item in pending:
                self.debug_controller.queue.append_event({
                    "kind": "paid_surgery_blocked_late",
                    "function_id": item.get("function_id"),
                    "reason": "entitlement missing",
                    "tier": "free",
                    "ts": time.time(),
                })
            return handles, route_suffix
        from .paid_local_ops import install_l3_embedding_hook
        for item in pending:
            handle, result = install_l3_embedding_hook(self.model, dict(item.get("payload") or {}))
            if handle is not None:
                handles.append(handle)
                route_suffix = "L3_EMBED_PERTURB"
            self.debug_controller.queue.append_event(result.event(function_id=item.get("function_id", "l3.embed_perturb"), source=source))
        return handles, route_suffix

    @staticmethod
    def _remove_paid_hooks(handles: list) -> None:
        for h in handles:
            try:
                h.remove()
            except Exception:
                pass

    def _generate_text(self, prompt: str, *, max_new_tokens: int = 64, temperature: float = 0.0) -> str:
        torch_mod = self._ensure_torch()
        inputs = self.tokenizer(prompt, return_tensors="pt", truncation=True, max_length=4096)
        device = self._device()
        if device is not None:
            inputs = {k: v.to(device) for k, v in inputs.items()}
        gen_kwargs = {"max_new_tokens": int(max_new_tokens), "do_sample": bool(temperature and temperature > 0)}
        if temperature and temperature > 0:
            gen_kwargs["temperature"] = float(temperature)
        with torch_mod.no_grad():
            out_ids = self.model.generate(**inputs, **gen_kwargs)
        prompt_len = int(inputs["input_ids"].shape[-1])
        new_ids = out_ids[0][prompt_len:]
        return self.tokenizer.decode(new_ids, skip_special_tokens=True).strip()

    def run(
        self,
        prompt: str,
        *,
        max_new_tokens: int = 64,
        temperature: float = 0.0,
        route: str = "BASE",
        capture: bool = True,
    ) -> Dict[str, Any]:
        self.debug_controller.poll_and_checkpoint(self, "before_generate", {"prompt_len": len(prompt)}, "base")
        self._wait_if_paused(phase="before_generate", source="base")
        active_route = route
        if self._pending_prompt_rewrite:
            prompt = str(self._pending_prompt_rewrite)
            self._pending_prompt_rewrite = ""
            active_route = "L1_REWRITE_BASE"
            self.debug_controller.queue.append_event(
                {"kind": "l1_prompt_rewrite_applied", "prompt_len": len(prompt), "ts": time.time(), "tier": "free_l1", "mode": "immediate"}
            )
        elif getattr(self, "_l1_mid_rewrite_armed", False):
            after_tokens = int(getattr(self, "_l1_mid_rewrite_after_tokens", 8) or 8)
            after_tokens = max(1, min(after_tokens, max_new_tokens, 64))
            self._l1_mid_rewrite_armed = False
            partial = self._generate_text(prompt, max_new_tokens=after_tokens, temperature=temperature)
            self._wait_for_l1_mid_rewrite(
                phase="mid_generate",
                source="base",
                partial_preview=partial,
                prompt_preview=prompt,
            )
            if self._pending_prompt_rewrite:
                prompt = str(self._pending_prompt_rewrite)
                self._pending_prompt_rewrite = ""
                active_route = "L1_MID_REWRITE_BASE"
                self.debug_controller.queue.append_event(
                    {"kind": "l1_mid_rewrite_applied", "prompt_len": len(prompt), "ts": time.time(), "tier": "free_l1"}
                )
            else:
                active_route = "L1_MID_REWRITE_NOOP_BASE"
                self.debug_controller.queue.append_event(
                    {"kind": "l1_mid_rewrite_noop", "ts": time.time(), "tier": "free_l1"}
                )
        prompt, active_route = self._apply_pending_l2_to_prompt(prompt, active_route, source="base")
        paid_hooks, paid_suffix = self._install_pending_l3_hooks(source="base")
        if paid_suffix:
            active_route = self._route_with_paid(active_route, paid_suffix)
        t0 = time.perf_counter()
        try:
            answer = self._generate_text(prompt, max_new_tokens=max_new_tokens, temperature=temperature)
        finally:
            self._remove_paid_hooks(paid_hooks)
        latency = time.perf_counter() - t0
        result = BaseRunResult(answer=answer, route=active_route, latency_sec=latency).to_dict()
        if capture and self.enable_mri:
            sid = self.capture_writer.write_run(prompt, result, model_id=self.model_id, route=active_route)
            result["capture_session_id"] = sid
        self.debug_controller.poll_and_checkpoint(
            self,
            "after_generate",
            {"answer_preview": answer[:120], "latency_sec": round(latency, 4), "route": active_route},
            "base",
        )
        return result
