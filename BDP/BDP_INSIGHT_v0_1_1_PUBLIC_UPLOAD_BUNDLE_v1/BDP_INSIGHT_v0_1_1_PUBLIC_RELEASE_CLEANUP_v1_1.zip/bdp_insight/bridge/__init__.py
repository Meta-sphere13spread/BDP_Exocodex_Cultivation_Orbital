"""BDP Insight bridge package — read-only adapters for external harnesses.

Each module here adapts a specific harness's event log into BDP Insight's
canonical InterventionEvent + 5 indicator output, WITHOUT modifying that
harness's runtime, capture path, or generate loop.

Currently shipped bridges:
    * m13 — Meta-13 v1.13.4 (`meta13_mri.dashboard_min`)

Bridges follow a strict policy:
    1. Read-only.  They never write to the harness's run/capture dirs.
    2. Never import anything that would force the harness's heavy deps
       (torch, transformers, accelerate, etc.) at module-load time.
    3. Always pass diffs through `_public_safe_*` style projections —
       raw payloads, score components, weights, candidate ranks, and any
       other forbidden keys are NEVER carried into BDP Insight outputs.
"""
