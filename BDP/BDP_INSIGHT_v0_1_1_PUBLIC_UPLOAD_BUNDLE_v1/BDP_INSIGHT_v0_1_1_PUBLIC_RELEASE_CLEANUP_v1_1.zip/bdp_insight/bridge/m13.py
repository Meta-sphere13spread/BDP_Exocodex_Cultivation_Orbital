"""Meta-13 v1.13.4 bridge — read-only observer for BDP Insight.

This module is the sole integration point between the Meta-13 v1.13.4
harness (`meta13_mri.dashboard_min`) and BDP Insight's 5 indicators.

It is intentionally **read-only**.  It never:
    - modifies the M13 harness's generate loop or attach_debugger
    - writes to the M13 run-dir / capture-dir
    - imports torch / transformers / accelerate
    - exposes raw payloads, score components, weights, candidate ranks,
      logits, hidden tensors, or any other forbidden internals

What it provides
----------------
1. ``load_m13_events(run_dir)`` — read the last N rows of M13's
   ``dynamic_debug/events.jsonl`` and return them as raw dicts.
2. ``m13_event_to_intervention_event(row)`` — convert one M13 row into
   a BDP Insight InterventionEvent.  Returns None for rows that aren't
   surgery-relevant (e.g. ``checkpoint``, ``freeze_*`` heartbeats).
3. ``register_panel(flask_app, run_dir, capture_dir)`` — registers two
   read-only endpoints + a tiny HTML panel that the dashboard's index
   page can include via an HTML comment marker.

Endpoints registered:
    GET /api/debug/bdp_insight/state    → 5 indicator outputs JSON
    GET /api/debug/bdp_insight/events   → normalised events JSON

Event-kind coverage (Q3 = A — all 5 in v1)
------------------------------------------
- ``rewrite_prompt`` / ``l1_prompt_rewrite_applied`` / ``l1_mid_rewrite_*``
    → L1 prompt rewrite
- ``paid_surgery_applied`` / ``paid_surgery_noop`` (function_id l2.token_*)
    → L2 token surgery
- ``paid_surgery_applied`` / ``paid_surgery_noop`` (function_id l2.hodge_*)
    → L2 Hodge auto surgery
- ``paid_output_intercept_applied`` (route ``L2_HODGE_OUTPUT_INTERCEPT``)
    → L2 output prefix intercept (canonical stale source)
- ``paid_surgery_applied`` / ``paid_surgery_noop`` (function_id l3.embed_*)
    → L3 embedding perturb
- ``blocked_command`` / ``paid_surgery_blocked_late``
    → blocked (status=blocked, actual_model_event=False)

Event categories that are intentionally IGNORED (return None):
    ``checkpoint``, ``freeze_enter``, ``freeze_wait``, ``freeze_exit``,
    ``freeze_abort``, ``state_write_skipped``, ``paid_command_accepted``,
    ``l1_prompt_rewrite_failed`` — these are runtime book-keeping, not
    interventions.  ``paid_command_accepted`` is intentionally skipped
    because it is followed by an applied/noop/blocked event with the
    actual outcome.

Debug markers (BDP_INSIGHT_DEBUG=1):
    [BDP_INSIGHT_M13 ...]    bridge events: load, normalize, register

This module is unit-testable without Flask installed; ``register_panel``
is the only Flask-dependent function.
"""
from __future__ import annotations

import json
import os
import sys
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from ..intervention_event import InterventionEvent, normalize_event
from ..indicators import (
    compute_surgery_impact,
    compute_dependency_shift,
    compute_stale_reasoning,
    compute_continuation_recond,
    compute_intervention_timeline,
)


# ──────────────────────────────────────────────────────────────────────
# Debug marker
# ──────────────────────────────────────────────────────────────────────

def _debug(marker: str, **kw: Any) -> None:
    if os.environ.get("BDP_INSIGHT_DEBUG", "").strip() not in ("1", "true", "yes"):
        return
    parts = [f"{k}={_short(v)}" for k, v in kw.items()]
    print(f"[BDP_INSIGHT_M13 {marker}] " + " ".join(parts), file=sys.stderr)


def _short(v: Any, limit: int = 60) -> str:
    s = repr(v)
    return s if len(s) <= limit else s[:limit] + "...]"


# ──────────────────────────────────────────────────────────────────────
# M13 v1.13.4 classification constants  — copied verbatim from
# meta13_mri/dashboard_min.py (lines 824–865) so the bridge produces
# identical family/status decisions to what the existing dashboard does.
# ──────────────────────────────────────────────────────────────────────

_M13_SURGERY_EVENT_KINDS = frozenset({
    # L1 (free)
    "rewrite_prompt",
    "l1_mid_rewrite_armed",
    "l1_mid_rewrite_disarmed",
    "l1_prompt_rewrite_applied",
    # L2/L3 (paid actual)
    "paid_surgery_applied",
    "paid_surgery_noop",
    "paid_command_accepted",
    "paid_surgery_blocked_late",
    "paid_output_intercept_applied",
    # blocked (free attempt)
    "blocked_command",
})

_M13_FAMILY_BY_OP = {
    "rewrite_prompt": "L1",
    "l1_mid_rewrite_armed": "L1",
    "l1_mid_rewrite_disarmed": "L1",
    "token_swap": "REMOVED_L2",
    "swap_token": "REMOVED_L2",
    "swap_basis": "REMOVED_L2",
    "hodge_token_auto": "L2",
    "hodge_auto": "L2",
    "hodge_convert": "L2",
    "hodge_token_convert": "L2",
    "hodge_output_intercept": "L2",
    "output_hodge_intercept": "L2",
    "hodge_mid_output": "L2",
    "hodge_output_auto": "L2",
    "embed_replace": "L3",
    "embed_perturb": "L3",
    "t456_graft": "L4",
    "edit_leaf": "L4",
    "inject_graft": "L4",
}

_M13_FAMILY_BY_FUNCTION_ID_PREFIX = {
    "l2.": "L2",
    "l3.": "L3",
    "l4.": "L4",
    "deep.": "L2",
}

# Event kinds that are book-keeping only — never produce an
# InterventionEvent for these.
_M13_IGNORED_KINDS = frozenset({
    "checkpoint",
    "freeze_enter", "freeze_wait", "freeze_exit", "freeze_abort",
    "state_write_skipped",
    "l1_prompt_rewrite_failed",
    "paid_command_accepted",  # always followed by applied/noop/blocked
})


def _classify_m13_family(ev: Dict[str, Any]) -> str:
    """Return one of L1/L2/L3/L4/unknown for a raw M13 row."""
    kind = str(ev.get("kind", ""))
    op = str(ev.get("op", "")).lower()
    fid = str(ev.get("function_id", "")).lower()
    if kind in {"rewrite_prompt", "l1_mid_rewrite_armed",
                "l1_mid_rewrite_disarmed", "l1_prompt_rewrite_applied"}:
        return "L1"
    if kind == "paid_output_intercept_applied":
        return "L2"
    if op in _M13_FAMILY_BY_OP:
        return _M13_FAMILY_BY_OP[op]
    for prefix, fam in _M13_FAMILY_BY_FUNCTION_ID_PREFIX.items():
        if fid.startswith(prefix):
            return fam
    return "unknown"


def _classify_m13_status(ev: Dict[str, Any]) -> str:
    """Map the M13 row to BDP Insight status (applied/blocked/noop/queued)."""
    kind = str(ev.get("kind", ""))
    if kind == "paid_surgery_applied":
        return "applied" if ev.get("changed", True) else "noop"
    if kind == "paid_surgery_noop":
        return "noop"
    if kind == "paid_output_intercept_applied":
        return "applied"
    if kind == "blocked_command" or kind == "paid_surgery_blocked_late":
        return "blocked"
    if kind in {"rewrite_prompt", "l1_prompt_rewrite_applied"}:
        return "applied"
    if kind == "l1_mid_rewrite_armed":
        return "queued"
    if kind == "l1_mid_rewrite_disarmed":
        return "cleared"
    return "unknown"


# ──────────────────────────────────────────────────────────────────────
# Public-safe diff extraction (mirrors dashboard_min._public_safe_*)
# ──────────────────────────────────────────────────────────────────────

def _public_safe_token_diff(ev: Dict[str, Any]) -> Tuple[str, str, str]:
    """Return (before_value, after_value, target_ref) trimmed to ≤ 80 chars."""
    meta = ev.get("meta") if isinstance(ev.get("meta"), dict) else {}
    cmd = ev.get("command_payload_public") if isinstance(ev.get("command_payload_public"), dict) else {}
    before = (meta.get("old_word_preview") or meta.get("old_text_preview")
              or cmd.get("old_word") or "")
    after = (meta.get("new_word_preview") or meta.get("new_text_preview")
             or meta.get("modified_partial_preview") or cmd.get("new_word") or "")
    pos = meta.get("char_position") or meta.get("position")
    target_ref = f"position[{pos}]" if pos is not None else "token"
    return str(before)[:80], str(after)[:80], target_ref


def _public_safe_l1_diff(ev: Dict[str, Any]) -> Tuple[str, str, str]:
    """L1 rewrite — there is usually only an after preview."""
    after = (str(ev.get("new_prompt_preview") or ev.get("prompt_preview") or "")
             [:160])
    return "", after, "prompt[full]"


def _public_safe_intercept_diff(ev: Dict[str, Any]) -> Tuple[str, str, str]:
    """Output intercept — the modified partial preview is the after value."""
    meta = ev.get("meta") if isinstance(ev.get("meta"), dict) else {}
    cmd = ev.get("command_payload_public") if isinstance(ev.get("command_payload_public"), dict) else {}
    after = str(meta.get("modified_partial_preview") or cmd.get("new_word") or "")[:180]
    target_ref = "output_prefix"
    return "", after, target_ref


def _public_safe_blocked_diff(ev: Dict[str, Any]) -> Tuple[str, str, str]:
    """Blocked — there is no successful change; expose the requested op only."""
    op = str(ev.get("op") or ev.get("function_id") or "")[:60]
    return "", "", f"requested[{op}]" if op else "requested"


# ──────────────────────────────────────────────────────────────────────
# Event-kind label (matches dashboard_min._build_last_surgery_summary)
# ──────────────────────────────────────────────────────────────────────

def _kind_label(family: str, op: str, function_id: str) -> str:
    op = (op or "").lower()
    function_id = (function_id or "").lower()
    if family == "L1":
        return "L1 Prompt Rewrite"
    if family == "L2":
        if "hodge" in op or "hodge" in function_id:
            return "L2 Hodge Auto Surgery"
        return "L2 Manual Token Swap (Removed)"
    if family == "L3":
        return "L3 Embedding Perturb"
    if family == "L4":
        return "L4 Graft (preview)"
    return "Unknown surgery"


def _intervention_type_for(ev: Dict[str, Any], family: str) -> str:
    """Return BDP-canonical intervention_type for the event."""
    kind = str(ev.get("kind", ""))
    op = str(ev.get("op") or "").lower()
    fid = str(ev.get("function_id") or "").lower()

    if kind == "paid_output_intercept_applied":
        return "hodge_output_intercept"
    if family == "L1":
        return "rewrite_prompt"
    if family == "L2":
        if "hodge" in op or "hodge" in fid:
            return "hodge_auto_surgery"
        return "hodge_token_auto"
    if family == "L3":
        return "embed_perturb_free"
    if family == "L4":
        return "graft_preview"
    if kind == "blocked_command":
        return op or "blocked_op"
    return kind or "unknown"


def _target_kind_for(ev: Dict[str, Any], family: str) -> str:
    kind = str(ev.get("kind", ""))
    if kind == "paid_output_intercept_applied":
        return "output_prefix"
    if family == "L1":
        return "prompt"
    if family == "L2":
        return "token"
    if family == "L3":
        return "embedding"
    if family == "L4":
        return "layer"
    if kind == "blocked_command":
        op = str(ev.get("op") or "").lower()
        if "embed" in op:
            return "embedding"
        if "prompt" in op or "rewrite" in op:
            return "prompt"
        return "token"
    return "token"


# ──────────────────────────────────────────────────────────────────────
# Conversion: M13 row → BDP InterventionEvent (or None if unconvertible)
# ──────────────────────────────────────────────────────────────────────

def m13_event_to_intervention_event(
    row: Dict[str, Any],
) -> Optional[InterventionEvent]:
    """Convert a single M13 events.jsonl row into an InterventionEvent.

    Returns None for book-keeping rows (checkpoints, freeze heartbeats, etc.).
    Never raises — malformed rows are skipped with a debug marker.
    """
    if not isinstance(row, dict):
        _debug("convert.skip", reason="non_dict")
        return None

    kind = str(row.get("kind", ""))
    if not kind or kind in _M13_IGNORED_KINDS:
        _debug("convert.skip", kind=kind, reason="ignored")
        return None

    family = _classify_m13_family(row)
    status = _classify_m13_status(row)

    # before / after extraction by family
    if kind == "paid_output_intercept_applied":
        before, after, target_ref = _public_safe_intercept_diff(row)
    elif family == "L1":
        before, after, target_ref = _public_safe_l1_diff(row)
    elif family in ("L2", "L3"):
        before, after, target_ref = _public_safe_token_diff(row)
    elif kind in ("blocked_command", "paid_surgery_blocked_late"):
        before, after, target_ref = _public_safe_blocked_diff(row)
    else:
        before, after, target_ref = "", "", "unknown"

    # before/after_output_preview reconstruction —
    # M13 v1.13.4 events.jsonl does not always carry both, so we leave
    # the BDP indicator outputs to read whatever IS present (note in the
    # final state will mark this as "Reconstructed from nearby events").
    before_output_preview = str(row.get("before_output_preview") or row.get("prompt_preview") or "")
    after_output_preview = str(
        row.get("after_output_preview")
        or row.get("answer_preview")
        or row.get("prompt_after_preview")
        or ""
    )
    # Special case: hodge_output_intercept gives us the modified partial
    # preview AS the after_output, and the meta.original_partial_preview
    # if present is the before_output.
    if kind == "paid_output_intercept_applied":
        meta = row.get("meta") if isinstance(row.get("meta"), dict) else {}
        if not after_output_preview:
            after_output_preview = str(meta.get("modified_partial_preview", ""))
        if not before_output_preview:
            before_output_preview = str(meta.get("original_partial_preview", ""))

    try:
        ev = InterventionEvent(
            source_tool="meta13_mri",
            intervention_type=_intervention_type_for(row, family),
            target_kind=_target_kind_for(row, family),
            target_ref=target_ref,
            before_value=before,
            after_value=after,
            before_output_preview=before_output_preview[:240],
            after_output_preview=after_output_preview[:240],
            status=status,
            actual_model_event=bool(row.get("actual_model_event", True)
                                    if status not in ("blocked", "queued")
                                    else False),
            ts=float(row.get("ts") or time.time()),
            note=(
                f"M13 event kind={kind}, family={family}. "
                f"Prompt/command/result trace is shown above when available."
            ),
        )
        _debug("convert.ok", kind=kind, family=family, status=status)
        return ev
    except Exception as exc:
        _debug("convert.failed", kind=kind, err=type(exc).__name__)
        return None


# ──────────────────────────────────────────────────────────────────────
# Reading M13's events.jsonl  (read-only, last N tail)
# ──────────────────────────────────────────────────────────────────────

def load_m13_events(
    run_dir: Path | str,
    *,
    limit: int = 200,
) -> List[Dict[str, Any]]:
    """Read the last `limit` rows of M13's events.jsonl, oldest-first.

    Returns an empty list if the file does not exist (e.g. the harness
    has not yet written its first event).  Bad lines are silently
    skipped.  This function never raises.
    """
    p = Path(run_dir).resolve() / "dynamic_debug" / "events.jsonl"
    if not p.is_file():
        _debug("load.no_file", path=str(p))
        return []
    rows: List[Dict[str, Any]] = []
    try:
        for line in p.read_text(encoding="utf-8", errors="replace") \
                     .splitlines()[-limit:]:
            line = line.strip()
            if not line:
                continue
            try:
                row = json.loads(line)
                if isinstance(row, dict):
                    rows.append(row)
            except Exception:
                continue
    except Exception as exc:
        _debug("load.read_failed", path=str(p), err=type(exc).__name__)
        return []
    _debug("load.ok", path=str(p), n=len(rows))
    return rows


def load_m13_state(run_dir: Path | str) -> Dict[str, Any]:
    """Read M13's current_state.json (debug surface).  Empty dict if absent."""
    p = Path(run_dir).resolve() / "dynamic_debug" / "current_state.json"
    if not p.is_file():
        return {}
    try:
        return json.loads(p.read_text(encoding="utf-8")) or {}
    except Exception as exc:
        _debug("state.read_failed", path=str(p), err=type(exc).__name__)
        return {}


# ──────────────────────────────────────────────────────────────────────
# State builder — what the BDP Insight panel actually consumes
# ──────────────────────────────────────────────────────────────────────

def build_bdp_insight_state(
    run_dir: Path | str,
    capture_dir: Optional[Path | str] = None,
) -> Dict[str, Any]:
    """Build the JSON payload the BDP Insight panel will render.

    Read-only: only reads ``run_dir/dynamic_debug/{events.jsonl,current_state.json}``.
    The capture_dir is accepted for API symmetry but not currently used.
    """
    rows = load_m13_events(run_dir, limit=200)
    m13_state = load_m13_state(run_dir)

    events: List[InterventionEvent] = []
    for row in rows:
        ev = m13_event_to_intervention_event(row)
        if ev is not None:
            events.append(ev)

    timeline = compute_intervention_timeline(events)

    if not events:
        latest_indicators = {
            "surgery_impact": None,
            "dependency_shift": None,
            "stale_reasoning": None,
            "continuation_recond": None,
        }
        latest_summary = None
    else:
        latest = events[-1]
        latest_indicators = {
            "surgery_impact":      compute_surgery_impact(latest),
            "dependency_shift":    compute_dependency_shift(latest),
            "stale_reasoning":     compute_stale_reasoning(latest),
            "continuation_recond": compute_continuation_recond(latest),
        }
        family = _classify_m13_family({"kind": latest.intervention_type})
        # InterventionEvent normalised above has source_tool=meta13_mri,
        # so re-inferring family requires the raw row's op — use the last raw row.
        last_row = next(
            (r for r in reversed(rows)
             if r.get("kind") not in _M13_IGNORED_KINDS),
            {},
        )
        last_family = _classify_m13_family(last_row)
        latest_summary = {
            "kind_label": _kind_label(
                last_family,
                last_row.get("op", ""),
                last_row.get("function_id", ""),
            ),
            "family": last_family,
            "status": _classify_m13_status(last_row),
            "applied_ago_sec": (
                max(0, int(time.time() - float(last_row.get("ts") or 0)))
                if last_row.get("ts") else None
            ),
            "actual_model_event": bool(last_row.get("actual_model_event", False)),
        }

    return {
        "ok": True,
        "tier": "free",
        "prototype": True,
        "source": "meta13_mri.v1.13.4",
        "run_dir": str(Path(run_dir).resolve()),
        "n_m13_rows": len(rows),
        "n_intervention_events": len(events),
        "latest_summary": latest_summary,
        "indicators": latest_indicators,
        "timeline": timeline,
        "m13_state_excerpt": {
            "phase": m13_state.get("phase"),
            "route": (m13_state.get("extra") or {}).get("route")
                     if isinstance(m13_state.get("extra"), dict) else None,
            "paused": m13_state.get("paused", False),
        },
    }


# ──────────────────────────────────────────────────────────────────────
# HTML panel — injected into M13's existing dashboard page
# ──────────────────────────────────────────────────────────────────────

_PANEL_HTML = """
<!-- BDP_INSIGHT_PANEL_BEGIN -->
<div id="bdp-insight-panel" style="
    margin: 14px auto; max-width: 1200px; padding: 0 14px;">
  <div style="background:#161618;border:1px solid #2a2a2e;border-radius:8px;
              padding:14px;color:#e8e8ec;
              font-family:'JetBrains Mono','Fira Code',monospace;">
    <div style="display:flex;justify-content:space-between;align-items:baseline;
                border-bottom:1px solid #2a2a2e;padding-bottom:8px;
                margin-bottom:10px;">
      <div>
        <span style="font-weight:600;font-size:13px;color:#4a9eff;">
          BDP Insight · MRI Signal Type 1
        </span>
        <span style="background:#4a3700;color:#ffd166;border:1px solid #634800;
                     padding:1px 7px;border-radius:3px;font-size:10px;
                     letter-spacing:0.4px;margin-left:6px;">PROTOTYPE</span>
        <span style="color:#8888a0;font-size:11px;margin-left:8px;">
          read-only observer · 5 indicators
        </span>
      </div>
      <div id="bdp-status" style="font-size:11px;color:#55556a;">Loading…</div>
    </div>

    <div style="display:grid;grid-template-columns:repeat(5,1fr);gap:8px;">
      <div class="bdp-card" data-card="impact">
        <div class="bdp-t">1 · Impact</div>
        <div class="bdp-v" data-v="label">—</div>
        <div class="bdp-n" data-v="note"></div>
      </div>
      <div class="bdp-card" data-card="dep">
        <div class="bdp-t">2 · Dep Shift</div>
        <div class="bdp-v" data-v="label">—</div>
        <div class="bdp-n" data-v="path"></div>
      </div>
      <div class="bdp-card" data-card="stale">
        <div class="bdp-t">3 · Stale Reasoning</div>
        <div class="bdp-v" data-v="label">—</div>
        <div class="bdp-n" data-v="warn"></div>
      </div>
      <div class="bdp-card" data-card="cont">
        <div class="bdp-t">4 · Continuation</div>
        <div class="bdp-v" data-v="label">—</div>
        <div class="bdp-n" data-v="state"></div>
      </div>
      <div class="bdp-card" data-card="tl">
        <div class="bdp-t">5 · Timeline</div>
        <div class="bdp-v" data-v="label">—</div>
        <div class="bdp-n" data-v="counts"></div>
      </div>
    </div>

    <div style="margin-top:8px;font-size:10px;color:#55556a;line-height:1.5;">
      Indicators describe <em>change</em>, not correctness.  Sourced
      read-only from <code style="color:#8888a0">events.jsonl</code>;
      this panel never modifies the harness.
    </div>
  </div>
</div>

<style>
.bdp-card{background:#1e1e21;border:1px solid #2a2a2e;border-radius:6px;
  padding:8px 10px;}
.bdp-card .bdp-t{font-size:9px;text-transform:uppercase;letter-spacing:0.08em;
  color:#55556a;margin-bottom:6px;}
.bdp-card .bdp-v{font-size:11px;color:#e8e8ec;line-height:1.4;
  word-break:break-word;}
.bdp-card .bdp-n{font-size:10px;color:#8888a0;margin-top:4px;}
.bdp-card.bdp-stale-yes .bdp-v{color:#ff8b8b;}
.bdp-card.bdp-stable .bdp-v{color:#88e09a;}
</style>

<script>
(function(){
  async function refreshBdp() {
    try {
      const r = await fetch('/api/debug/bdp_insight/state', {cache:'no-store'});
      if (!r.ok) {
        document.getElementById('bdp-status').textContent =
          'Error: HTTP ' + r.status;
        return;
      }
      const s = await r.json();
      const stat = document.getElementById('bdp-status');
      stat.textContent = s.n_intervention_events + ' events · '
        + (s.latest_summary ? s.latest_summary.kind_label : 'no surgery yet');

      function setCard(id, label, note, extraClass) {
        const el = document.querySelector('[data-card="'+id+'"]');
        if (!el) return;
        el.querySelector('[data-v="label"]').textContent = label || '—';
        el.classList.remove('bdp-stale-yes','bdp-stable');
        if (extraClass) el.classList.add(extraClass);
        const noteSlots = el.querySelectorAll('.bdp-n');
        if (noteSlots.length) noteSlots[0].textContent = note || '';
      }

      const i = s.indicators || {};
      setCard('impact',
        i.surgery_impact ? i.surgery_impact.label : 'idle',
        i.surgery_impact ? (i.surgery_impact.impact + ' · '
          + i.surgery_impact.stability) : '');
      setCard('dep',
        i.dependency_shift ? i.dependency_shift.label : 'idle',
        i.dependency_shift ? ('result_path=' + i.dependency_shift.result_path) : '');
      setCard('stale',
        i.stale_reasoning ? i.stale_reasoning.label : 'idle',
        i.stale_reasoning && i.stale_reasoning.warning ? '⚠ stale' : '',
        i.stale_reasoning && i.stale_reasoning.consistency === 'Stale'
          ? 'bdp-stale-yes'
          : (i.stale_reasoning && i.stale_reasoning.consistency === 'Stable'
             ? 'bdp-stable' : null));
      setCard('cont',
        i.continuation_recond ? i.continuation_recond.label : 'idle',
        i.continuation_recond ? i.continuation_recond.state : '');
      const tl = s.timeline || {};
      setCard('tl', tl.label || 'empty',
        tl.summary
          ? (tl.summary.n_total + ' total · '
             + tl.summary.n_applied + ' applied · '
             + tl.summary.n_blocked + ' blocked')
          : '');
    } catch (e) {
      document.getElementById('bdp-status').textContent = 'Error: ' + e;
    }
  }
  refreshBdp();
  setInterval(refreshBdp, 2000);
})();
</script>
<!-- BDP_INSIGHT_PANEL_END -->
"""


def get_panel_html() -> str:
    """Return the BDP Insight panel HTML — for callers that want to inject."""
    return _PANEL_HTML


# ──────────────────────────────────────────────────────────────────────
# Flask registration — called by meta13_mri.dashboard_min.create_app
# ──────────────────────────────────────────────────────────────────────

def register_panel(
    flask_app: Any,
    run_dir: Path | str,
    capture_dir: Optional[Path | str] = None,
) -> None:
    """Register BDP Insight read-only endpoints + HTML-injection hook.

    Call this **once** from inside ``create_app(...)`` in M13 v1.13.4's
    ``dashboard_min.py``, just before ``return app``.

    Endpoints registered:
        GET /api/debug/bdp_insight/state    → 5 indicator JSON
        GET /api/debug/bdp_insight/events   → normalized events JSON
        GET /api/debug/bdp_insight/panel    → bare HTML panel snippet
        GET /api/debug/bdp_insight/healthz  → liveness

    The panel HTML is also injected into the existing root response via
    an ``after_request`` hook that splices ``_PANEL_HTML`` into the
    rendered HTML just before ``</body>`` — so the user does NOT need
    to modify M13's ``_DASHBOARD_HTML`` template.
    """
    try:
        from flask import jsonify, Response, request
    except ImportError as exc:                               # pragma: no cover
        raise RuntimeError(
            "BDP Insight bridge requires Flask, which is already a hard "
            "dependency of meta13_mri.dashboard_min — check your install."
        ) from exc

    run_dir = Path(run_dir).resolve()
    if capture_dir is not None:
        capture_dir = Path(capture_dir).resolve()

    _debug("register.start",
           run_dir=str(run_dir),
           capture_dir=str(capture_dir) if capture_dir else None)

    @flask_app.route("/api/debug/bdp_insight/healthz", methods=["GET"])
    def _bdp_healthz() -> Any:
        return jsonify({
            "ok": True,
            "prototype": True,
            "source": "meta13_mri.v1.13.4",
            "run_dir": str(run_dir),
        })

    @flask_app.route("/api/debug/bdp_insight/state", methods=["GET"])
    def _bdp_state() -> Any:
        try:
            payload = build_bdp_insight_state(run_dir, capture_dir)
            return jsonify(payload)
        except Exception as exc:
            _debug("route.state.error", err=type(exc).__name__)
            return jsonify({"ok": False, "error": type(exc).__name__}), 500

    @flask_app.route("/api/debug/bdp_insight/events", methods=["GET"])
    def _bdp_events() -> Any:
        try:
            rows = load_m13_events(run_dir, limit=200)
            normalised = []
            for row in rows:
                ev = m13_event_to_intervention_event(row)
                if ev is not None:
                    normalised.append(ev.to_dict())
            return jsonify({
                "ok": True,
                "n_m13_rows": len(rows),
                "n_intervention_events": len(normalised),
                "events": normalised,
            })
        except Exception as exc:
            _debug("route.events.error", err=type(exc).__name__)
            return jsonify({"ok": False, "error": type(exc).__name__}), 500

    @flask_app.route("/api/debug/bdp_insight/panel", methods=["GET"])
    def _bdp_panel() -> Any:
        return Response(_PANEL_HTML, mimetype="text/html; charset=utf-8")

    # ── HTML injection hook ──
    # Splice the panel HTML into the existing M13 dashboard's index page
    # WITHOUT modifying _DASHBOARD_HTML.  The hook runs after_request and
    # only rewrites the body when:
    #   1. status is 200,
    #   2. content-type is HTML,
    #   3. response body has not already been spliced (idempotent).
    @flask_app.after_request
    def _bdp_inject_panel(response):
        try:
            if response.status_code != 200:
                return response
            # Only inject into the main dashboard HTML.  Other HTML routes
            # such as /api/debug/bdp_insight/panel remain untouched.
            if getattr(request, "path", "/") not in {"/", ""}:
                return response
            ct = (response.content_type or "").lower()
            if "text/html" not in ct:
                return response
            body = response.get_data(as_text=True)
            if "<!-- BDP_INSIGHT_PANEL_BEGIN -->" in body:
                return response
            if "</body>" not in body:
                return response
            new_body = body.replace("</body>", _PANEL_HTML + "</body>", 1)
            response.set_data(new_body)
            response.content_length = len(new_body.encode("utf-8"))
            _debug("inject.ok", path=str(getattr(
                __import__("flask").request, "path", "?")))
        except Exception as exc:
            _debug("inject.failed", err=type(exc).__name__)
        return response

    _debug("register.done")


__all__ = [
    "load_m13_events",
    "load_m13_state",
    "m13_event_to_intervention_event",
    "build_bdp_insight_state",
    "register_panel",
    "get_panel_html",
]
