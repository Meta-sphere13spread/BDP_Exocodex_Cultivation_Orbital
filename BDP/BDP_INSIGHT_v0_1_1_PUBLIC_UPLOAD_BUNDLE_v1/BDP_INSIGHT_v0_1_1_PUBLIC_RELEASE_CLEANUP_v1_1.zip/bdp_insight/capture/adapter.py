"""
mri_capture_adapter.py
======================
Converts capture_session.json (Meta-13 MRI bundle format)
into the trace dict format that meta13_mri_ms.py expects.

This is the schema bridge between:
  capture: conditions[].geometry.layers[] + lens.layers[] + generation.steps[]
  studio:  steps[].aggregations.{last, last4, last8}

Usage:
    from mri_capture_adapter import load_capture_as_trace, list_capture_sessions

    sessions = list_capture_sessions("results/mri_capture")
    trace = load_capture_as_trace(sessions[0]["session_dir"])
"""

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence


def list_capture_sessions(outdir: str) -> List[Dict[str, Any]]:
    """Read index.jsonl and return session list sorted by created_at desc."""
    idx_path = Path(outdir) / "index.jsonl"
    sessions = []
    if idx_path.exists():
        for line in idx_path.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                rec = json.loads(line)
                rec["session_dir"] = str(Path(outdir) / rec.get("session_id", ""))
                sessions.append(rec)
            except json.JSONDecodeError:
                continue
    else:
        # fallback: scan directories
        for d in sorted(Path(outdir).iterdir(), reverse=True):
            if d.is_dir() and (d / "manifest.json").exists():
                meta = {}
                idx_file = d / "capture_index.json"
                if idx_file.exists():
                    try:
                        meta = json.loads(idx_file.read_text(encoding="utf-8"))
                    except Exception:
                        pass
                meta["session_dir"] = str(d)
                meta.setdefault("session_id", d.name)
                sessions.append(meta)
    return sorted(sessions, key=lambda x: x.get("created_at", 0), reverse=True)


def load_capture_as_trace(session_dir: str) -> Dict[str, Any]:
    """Load a capture session and convert to mri_ms trace format."""
    sd = Path(session_dir)

    # Load capture_session.json
    sess_path = sd / "capture_session.json"
    if not sess_path.exists():
        return {"error": f"No capture_session.json in {session_dir}", "steps": []}

    with open(sess_path, "r", encoding="utf-8") as f:
        sess = json.load(f)

    # Load result_minimal for context
    result_minimal = {}
    rm_path = sd / "result_minimal.json"
    if rm_path.exists():
        try:
            result_minimal = json.loads(rm_path.read_text(encoding="utf-8"))
        except Exception:
            pass

    # Extract condition data
    conditions = sess.get("conditions", [])
    if not conditions:
        return {"error": "No conditions in session", "steps": []}

    cond = conditions[0]  # primary condition
    geo = cond.get("geometry") or {}
    lens_data = cond.get("lens") or {}
    flow = cond.get("flow") or {}
    gen = cond.get("generation") or {}

    geo_layers = geo.get("layers", []) if isinstance(geo, dict) else []
    lens_layers = lens_data.get("layers", []) if isinstance(lens_data, dict) else []
    gen_steps = gen.get("steps", []) if isinstance(gen, dict) else []

    # ─── Build header ───
    prompt_text = result_minimal.get("prompt_preview", "")
    answer_text = result_minimal.get("answer_preview", "")
    prompt_numbers = [int(x) for x in re.findall(r"-?\d{4,}", prompt_text)]
    answer_numbers = [int(x) for x in re.findall(r"-?\d{4,}", answer_text)]

    run_info = sess.get("run", {})

    header = {
        "session_id": sess.get("session_id", ""),
        "model_id": run_info.get("model_id", sess.get("model_id", "")),
        "route": run_info.get("route", result_minimal.get("route", "")),
        "source": sess.get("source", "main"),
        "trace_method": "capture_bundle",
        "prompt_preview": prompt_text,
        "answer_preview": answer_text,
        "prompt_numbers": prompt_numbers,
        "answer_numbers": answer_numbers,
        "n_layers": len(geo_layers),
        "n_generation_steps": len(gen_steps),
        "basis_before": run_info.get("basis_before", {}),
        "basis_after": run_info.get("basis_after", {}),
        "basis_delta": run_info.get("basis_delta", {}),
        "geometry_summary": {
            "cpi": geo.get("cpi"),
            "eds": geo.get("eds"),
            "cdi": geo.get("cdi"),
            "omega_peak_layer": geo.get("omega_peak_layer"),
            "work_final": geo.get("work_final"),
        },
        "capture_modes": sess.get("aux", {}).get("capture_modes", []),
    }

    # ─── Build steps from layers (forward pass view) ───
    # Each layer becomes a "step" with aggregations
    # This maps geometry+lens per layer → the step format mri_ms expects
    steps = []
    n_layers = max(len(geo_layers), len(lens_layers))

    for i in range(n_layers):
        g = geo_layers[i] if i < len(geo_layers) else {}
        l = lens_layers[i] if i < len(lens_layers) else {}

        # Flow node for this layer (if exists)
        flow_node = None
        if flow.get("nodes"):
            for n in flow["nodes"]:
                if isinstance(n, dict) and n.get("layer") == i:
                    flow_node = n
                    break

        # Build aggregation dict (mri_ms expects these metric names)
        agg = {
            "Entropy": l.get("entropy", g.get("spectral_entropy", 0)),
            "ID": g.get("id_value", 0),
            "PC1r": g.get("pc1r", 0),
            "Omega": g.get("omega", 0),
            "AGA": g.get("aga", 0),
            "Density": g.get("density", 0),
            "Orbital": g.get("orbital", 0),
            "Spectral Entropy": g.get("spectral_entropy", 0),
            "Effective Rank": g.get("effective_rank", 0),
            # Lens metrics
            "Logit Entropy": l.get("entropy", 0),
            "Pred Prob": l.get("pred_prob", 0),
            "Margin": l.get("margin", 0),
            # mri_ms standard names (mapped as best we can)
            "Lookback Distance": 0,  # not available in forward pass
            "Prompt Ratio": 0,
            "Top1 Source Weight": l.get("pred_prob", 0),
            "TopSourceMass": sum(p for _, p in (l.get("topk") or [])[:3]),
            "Prompt Touch": 0,
            "Answer Touch": 0,
            "Operator Touch": 0,
            "Formula Like": 0,
        }

        # Token info from lens or flow
        pred_token = l.get("pred_token", "")
        topk = l.get("topk", [])
        if flow_node:
            pred_token = flow_node.get("token_text", pred_token)
            topk = flow_node.get("pred_topk", topk)

        step = {
            "step_index": i,
            "generated_token": pred_token,
            "token_clean": pred_token.strip() if pred_token else f"L{i}",
            "layer": i,
            "in_corridor": g.get("in_corridor", 0),
            "event_label": g.get("event_label", ""),
            "aggregations": {
                "last": agg,
                "last4": agg,   # same data for forward pass (no depth slicing)
                "last8": agg,
            },
            "source_tokens": [{"token": t, "weight": w} for t, w in (topk or [])],
            "context_windows": [],
        }
        steps.append(step)

    # ─── Append generation steps if available ───
    for gs in gen_steps:
        gs_layers = gs.get("layers", [])
        gs_topk = gs.get("topk", [])

        # Build agg from generation step's layer data
        gs_agg = {}
        if gs_layers:
            last = gs_layers[-1] if gs_layers else {}
            last4 = gs_layers[-4:] if len(gs_layers) >= 4 else gs_layers
            last8 = gs_layers[-8:] if len(gs_layers) >= 8 else gs_layers

            def _avg_metric(layers, key):
                vals = [l.get(key, 0) for l in layers if isinstance(l, dict)]
                return sum(vals) / max(len(vals), 1)

            for mode_name, mode_layers in [("last", [last]), ("last4", last4), ("last8", last8)]:
                gs_agg[mode_name] = {
                    "Entropy": _avg_metric(mode_layers, "entropy"),
                    "Logit Entropy": _avg_metric(mode_layers, "entropy"),
                    "Pred Prob": _avg_metric(mode_layers, "pred_prob"),
                    "Margin": _avg_metric(mode_layers, "margin"),
                    "Top1 Source Weight": _avg_metric(mode_layers, "pred_prob"),
                    "TopSourceMass": sum(p for _, p in gs_topk[:3]) if gs_topk else 0,
                    # geometry not available per generation step
                    "ID": 0, "PC1r": 0, "Omega": 0,
                    "Lookback Distance": 0, "Prompt Ratio": 0,
                    "Prompt Touch": 0, "Answer Touch": 0,
                    "Operator Touch": 0, "Formula Like": 0,
                }
        else:
            _empty = {m: 0 for m in ["Entropy", "Logit Entropy", "Pred Prob", "Margin",
                                      "Top1 Source Weight", "TopSourceMass", "ID", "PC1r",
                                      "Omega", "Lookback Distance", "Prompt Ratio",
                                      "Prompt Touch", "Answer Touch", "Operator Touch", "Formula Like"]}
            gs_agg = {"last": _empty, "last4": _empty, "last8": _empty}

        token_text = gs.get("token_text", "")
        step_idx = len(steps)

        steps.append({
            "step_index": step_idx,
            "generated_token": token_text,
            "token_clean": token_text.strip() if token_text else f"G{gs.get('step_index', step_idx)}",
            "layer": -1,  # generation step, not a layer
            "is_generation_step": True,
            "gen_step_index": gs.get("step_index", step_idx),
            "aggregations": gs_agg,
            "source_tokens": [{"token": t, "weight": w} for t, w in (gs_topk or [])],
            "context_windows": [],
        })

    # ─── Assemble trace ───
    trace = {**header, "steps": steps}
    return trace


def capture_session_files(outdir: str) -> List[str]:
    """Return list of capture_session.json paths for mri_ms file selector."""
    results = []
    for d in sorted(Path(outdir).iterdir()):
        if d.is_dir():
            cs = d / "capture_session.json"
            if cs.exists():
                results.append(str(cs))
    return results


__all__ = ["load_capture_as_trace", "list_capture_sessions", "capture_session_files"]
