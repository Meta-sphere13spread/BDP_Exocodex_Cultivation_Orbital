from __future__ import annotations

from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Optional

# These two imports point to SMAP10_2's outer integration package, which
# is intentionally NOT bundled inside bdp_insight (heavy + outside the
# 5-indicator scope).  When the package is not available we degrade to
# a clear NotImplementedError rather than crashing on import.
try:
    from integrations.meta13_hooks import Meta13MRIHooks  # type: ignore
    from report_core.config import MRIConfig             # type: ignore
    _HAS_FULL_HOOKS = True
except ImportError:                                       # pragma: no cover
    Meta13MRIHooks = None      # type: ignore
    MRIConfig = None           # type: ignore
    _HAS_FULL_HOOKS = False


def _default_run_id(prefix: str = 'run') -> str:
    return f"{prefix}_{datetime.utcnow().strftime('%Y%m%dT%H%M%SZ')}"


def load_mri_config(config_path: Optional[str] = None, overrides: Optional[Dict[str, Any]] = None) -> "MRIConfig":
    if not _HAS_FULL_HOOKS:
        raise NotImplementedError(
            "bdp_insight.capture.bootstrap requires the SMAP10_2 'integrations' "
            "and 'report_core' packages, which are not bundled in the BDP Insight "
            "free wheel.  For the prototype 5-indicator path, use the lightweight "
            "capture.adapter / capture.session_writer instead."
        )
    cfg: MRIConfig
    if config_path:
        p = Path(config_path)
        if p.exists():
            cfg = MRIConfig.from_json_file(p)
        else:
            cfg = MRIConfig()
    else:
        local_json = Path('mri_config.json')
        if local_json.exists():
            cfg = MRIConfig.from_json_file(local_json)
        else:
            cfg = MRIConfig()
    if overrides:
        cfg = cfg.merge_override(overrides)
    return cfg


def attach_meta13_mri(engine, model_name: str = 'unknown', config_path: Optional[str] = None,
                      overrides: Optional[Dict[str, Any]] = None, run_id: Optional[str] = None):
    if not _HAS_FULL_HOOKS:
        raise NotImplementedError(
            "bdp_insight.capture.bootstrap.attach_meta13_mri requires the SMAP10_2 "
            "'integrations' package.  Use bdp_insight.attach.attach_debugger() for "
            "the prototype path."
        )
    cfg = load_mri_config(config_path=config_path, overrides=overrides)
    if not cfg.enabled:
        return None
    rid = run_id or _default_run_id('meta13')
    hooks = Meta13MRIHooks(
        base_dir=cfg.output_base_dir,
        run_id=rid,
        model_name=model_name,
        config=cfg,
    )
    if hasattr(engine, 'attach_mri_hooks'):
        engine.attach_mri_hooks(hooks, cfg)
    else:
        setattr(engine, '_mri_hooks', hooks)
        setattr(engine, '_mri_config', cfg)
        setattr(engine, 'enable_mri', True)
    return hooks
