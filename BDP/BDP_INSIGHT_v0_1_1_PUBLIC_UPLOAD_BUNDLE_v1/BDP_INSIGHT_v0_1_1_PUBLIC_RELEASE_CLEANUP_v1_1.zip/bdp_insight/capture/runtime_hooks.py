from __future__ import annotations

"""
runtime_hooks.py — local forward-hook utilities (capture + intervention)
========================================================================

Local forward-hook utilities for Meta-13 capture and intervention.

Important policy choice:
    - Uses per-module hooks, not global hooks.
    - Supports capture, corruption, and activation-addition on selected layers.
    - Keeps handles removable and state bounded to a session.
    - Adds best-effort full generation-step capture with graceful fallback.

Raw-tensor handling policy (BDP Insight v0.2 prototype)
--------------------------------------------------------
This module DOES hold raw torch tensors (hidden states, attentions, scores)
in memory during capture.  This is required to do its job.

These raw tensors:
    1. STAY in process memory only.  They are NEVER written verbatim to
       disk.  Disk persistence goes through `safe_jsonable(...)` (in
       `bdp_insight.capture.safe_json`) which serialises tensors as
       `{shape, dtype, device}` summaries — never raw values.
    2. ARE NEVER fed directly into an `InterventionEvent`.  The
       `FORBIDDEN_PAYLOAD_KEYS` set in `bdp_insight.intervention_event`
       blocks `hidden_tensor`, `logits`, `phi_value`, etc. at construction
       time.
    3. ARE NEVER serialised through the dashboard or studio — both surfaces
       only render indicator outputs (which are already public-safe by
       construction).
    4. The raw tensor → public-safe transition is enforced by an
       automated test (`tests/test_dashboard.py::TestDashboardRawTensorPolicy`)
       which posts a payload containing fake raw tensors and verifies they
       do not appear in any HTTP response.

Anything in this file that handles `tensor`, `hidden`, or `score` is
"local raw" — keep it that way.
"""

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

try:
    import torch
    import torch.nn.functional as F
    HAS_TORCH = True
except Exception:
    torch = None
    F = None
    HAS_TORCH = False


@dataclass
class HookCapture:
    layer: int
    tensor: Any
    stream: str = "residual"
    shape: Tuple[int, ...] = field(default_factory=tuple)


@dataclass
class InterventionSpec:
    condition_id: str = "plain"
    intervention_type: str = "plain"  # plain, corrupt, restore, actadd
    target_layer: Optional[int] = None
    target_token_pos: Optional[int] = None
    target_stream: str = "residual"
    noise_scale: float = 0.0
    add_vector: Any = None
    seed: int = 0


class ModelLayerLocator:
    def __init__(self, model: Any):
        self.model = model

    def get_layers(self) -> List[Any]:
        if self.model is None:
            return []
        # Gemma4-like wrapper (model.model.language_model.model.layers)
        _inner = getattr(getattr(self.model, "model", None), "language_model", None)
        if _inner is not None:
            _lm_model = getattr(_inner, "model", None)
            if _lm_model is not None and hasattr(_lm_model, "layers"):
                return list(_lm_model.layers)
        if hasattr(self.model, "model") and hasattr(self.model.model, "layers"):
            return list(self.model.model.layers)
        if hasattr(self.model, "transformer") and hasattr(self.model.transformer, "h"):
            return list(self.model.transformer.h)
        if hasattr(self.model, "layers"):
            return list(self.model.layers)
        return []

    def get_layer(self, layer_idx: int) -> Optional[Any]:
        layers = self.get_layers()
        if 0 <= layer_idx < len(layers):
            return layers[layer_idx]
        return None


class HookSession:
    def __init__(self, model: Any):
        self.model = model
        self.locator = ModelLayerLocator(model)
        self.handles: List[Any] = []
        self.captures: Dict[int, HookCapture] = {}
        self.applied_norms: Dict[int, float] = {}

    def clear(self) -> None:
        for h in self.handles:
            try:
                h.remove()
            except Exception:
                pass
        self.handles = []
        self.captures = {}
        self.applied_norms = {}

    def install_capture_all(self) -> None:
        if not HAS_TORCH:
            return
        self.clear()
        for lid, layer in enumerate(self.locator.get_layers()):
            def make_hook(layer_id: int):
                def hook_fn(module, args, output):
                    out = output[0] if isinstance(output, tuple) else output
                    if isinstance(out, torch.Tensor):
                        self.captures[layer_id] = HookCapture(
                            layer=layer_id,
                            tensor=out.detach().cpu(),
                            stream="residual",
                            shape=tuple(out.shape),
                        )
                    return output
                return hook_fn
            self.handles.append(layer.register_forward_hook(make_hook(lid)))

    def install_intervention(self, spec: InterventionSpec) -> None:
        if not HAS_TORCH or spec.target_layer is None:
            return
        layer = self.locator.get_layer(spec.target_layer)
        if layer is None:
            return

        if spec.seed:
            torch.manual_seed(int(spec.seed))
            if torch.cuda.is_available():
                torch.cuda.manual_seed_all(int(spec.seed))

        def hook_fn(module, args, output):
            out = output[0] if isinstance(output, tuple) else output
            if not isinstance(out, torch.Tensor):
                return output
            new_out = out

            if spec.intervention_type == "corrupt":
                noise = torch.randn_like(out) * float(spec.noise_scale)
                if spec.target_token_pos is None:
                    new_out = out + noise
                else:
                    new_out = out.clone()
                    pos = max(0, min(int(spec.target_token_pos), out.shape[1] - 1)) if out.ndim >= 3 else None
                    if pos is not None:
                        new_out[:, pos, :] = new_out[:, pos, :] + noise[:, pos, :]
                    else:
                        new_out = out + noise
                self.applied_norms[spec.target_layer] = float(noise.norm().item())
            elif spec.intervention_type == "actadd" and spec.add_vector is not None:
                add_vec = spec.add_vector
                if not isinstance(add_vec, torch.Tensor):
                    add_vec = torch.tensor(add_vec, device=out.device, dtype=out.dtype)
                while add_vec.ndim < out.ndim:
                    add_vec = add_vec.unsqueeze(0)
                if spec.target_token_pos is None:
                    new_out = out + add_vec
                else:
                    new_out = out.clone()
                    pos = max(0, min(int(spec.target_token_pos), out.shape[1] - 1)) if out.ndim >= 3 else None
                    if pos is not None:
                        new_out[:, pos, :] = new_out[:, pos, :] + add_vec[:, :1, :]
                    else:
                        new_out = out + add_vec
                self.applied_norms[spec.target_layer] = float((new_out - out).norm().item())
            else:
                return output

            if isinstance(output, tuple):
                return (new_out,) + tuple(output[1:])
            return new_out

        self.handles.append(layer.register_forward_hook(hook_fn))


class RuntimeTraceRunner:
    def __init__(self, model: Any, tokenizer: Any):
        self.model = model
        self.tokenizer = tokenizer
        self.locator = ModelLayerLocator(model)

    def _device(self):
        if self.model is None:
            return None
        try:
            return next(self.model.parameters()).device
        except Exception:
            return None

    def tokenize(self, prompt: str, max_length: int = 4096) -> Dict[str, Any]:
        if self.tokenizer is None:
            raise RuntimeError("Tokenizer is required for capture")
        inputs = self.tokenizer(prompt, return_tensors="pt", truncation=True, max_length=max_length)
        device = self._device()
        if device is not None:
            inputs = {k: v.to(device) for k, v in inputs.items()}
        return inputs

    def run_forward(
        self,
        prompt: str,
        capture_hidden: bool = True,
        capture_attn: bool = False,
        intervention: Optional[InterventionSpec] = None,
        max_length: int = 4096,
    ) -> Dict[str, Any]:
        if not HAS_TORCH or self.model is None:
            return {"hidden_by_layer": {}, "attentions": None, "output": None, "tokens": []}

        inputs = self.tokenize(prompt, max_length=max_length)
        token_ids = inputs["input_ids"][0].detach().cpu().tolist()
        token_texts = self.tokenizer.convert_ids_to_tokens(token_ids) if self.tokenizer is not None else [str(x) for x in token_ids]

        hook_session = HookSession(self.model)
        if capture_hidden:
            hook_session.install_capture_all()
        if intervention and intervention.intervention_type != "plain":
            hook_session.install_intervention(intervention)

        try:
            with torch.no_grad():
                out = self.model(
                    **inputs,
                    output_hidden_states=bool(capture_hidden),
                    output_attentions=bool(capture_attn),
                )
        finally:
            hook_session_handles = list(hook_session.handles)
            captures = dict(hook_session.captures)
            applied_norms = dict(hook_session.applied_norms)
            hook_session.clear()
            del hook_session_handles

        hidden_by_layer = {}
        if captures:
            for lid, cap in captures.items():
                hidden_by_layer[int(lid)] = cap.tensor
        elif hasattr(out, "hidden_states") and out.hidden_states is not None:
            for i, h in enumerate(out.hidden_states[1:]):
                if isinstance(h, torch.Tensor):
                    hidden_by_layer[i] = h.detach().cpu()

        attentions = None
        if hasattr(out, "attentions") and out.attentions is not None:
            attentions = [a.detach().cpu() for a in out.attentions]

        return {
            "hidden_by_layer": hidden_by_layer,
            "attentions": attentions,
            "output": out,
            "token_ids": token_ids,
            "token_texts": token_texts,
            "applied_norms": applied_norms,
        }

    def _extract_step_hidden(self, hidden_states: Any, storage_mode: str = "last_token") -> List[Dict[str, Any]]:
        steps: List[Dict[str, Any]] = []
        if hidden_states is None:
            return steps
        for step_idx, step_tuple in enumerate(hidden_states):
            if not isinstance(step_tuple, (tuple, list)):
                continue
            hidden_by_layer: Dict[int, Any] = {}
            for lid, h in enumerate(step_tuple[1:]):  # skip embeddings layer
                if not isinstance(h, torch.Tensor):
                    continue
                cpu_h = h.detach().cpu()
                if storage_mode == "last_token" and cpu_h.ndim == 3 and cpu_h.shape[1] >= 1:
                    cpu_h = cpu_h[:, -1:, :]
                hidden_by_layer[lid] = cpu_h
            steps.append({"step_index": step_idx, "hidden_by_layer": hidden_by_layer})
        return steps

    def run_generation_trace(
        self,
        prompt: str,
        max_new_tokens: int = 64,
        capture_hidden: bool = True,
        capture_attn: bool = False,
        intervention: Optional[InterventionSpec] = None,
        max_length: int = 4096,
        mode_requested: str = "full",
        allow_fallback: bool = True,
    ) -> Dict[str, Any]:
        result: Dict[str, Any] = {
            "attempted": True,
            "success": False,
            "mode_requested": mode_requested,
            "mode_used": "",
            "max_new_tokens": int(max_new_tokens),
            "steps": [],
            "generated_ids": [],
            "generated_text": "",
            "scores": [],
            "error_type": "",
            "error_message": "",
            "attentions": None,
        }
        if not HAS_TORCH or self.model is None or self.tokenizer is None:
            result.update({"error_type": "RuntimeUnavailable", "error_message": "Torch/model/tokenizer unavailable"})
            return result

        inputs = self.tokenize(prompt, max_length=max_length)
        input_len = int(inputs["input_ids"].shape[1])

        hook_session = HookSession(self.model)
        if intervention and intervention.intervention_type != "plain":
            hook_session.install_intervention(intervention)

        try:
            with torch.no_grad():
                gen = self.model.generate(
                    **inputs,
                    max_new_tokens=max_new_tokens,
                    return_dict_in_generate=True,
                    output_scores=True,
                    output_hidden_states=bool(capture_hidden),
                    output_attentions=bool(capture_attn),
                    do_sample=False,
                    use_cache=True,
                    pad_token_id=getattr(self.tokenizer, "pad_token_id", None) or getattr(self.tokenizer, "eos_token_id", None),
                    eos_token_id=getattr(self.tokenizer, "eos_token_id", None),
                    # ★ Cmap12.4 stuck loop 방어 (MRI capture 경로)
                    repetition_penalty=1.15,
                    no_repeat_ngram_size=4,
                )

            sequences = gen.sequences.detach().cpu()
            generated_ids = sequences[0, input_len:].tolist() if sequences.ndim == 2 else []
            generated_text = self.tokenizer.decode(generated_ids, skip_special_tokens=True) if generated_ids else ""
            score_steps = []
            if getattr(gen, "scores", None) is not None:
                for s in gen.scores:
                    score_steps.append(s.detach().cpu())

            storage_mode = "full" if mode_requested == "full" else "last_token"
            step_hidden = self._extract_step_hidden(getattr(gen, "hidden_states", None), storage_mode=storage_mode)
            if mode_requested == "full" and not step_hidden and allow_fallback:
                storage_mode = "last_token"
                step_hidden = self._extract_step_hidden(getattr(gen, "hidden_states", None), storage_mode=storage_mode)

            result.update({
                "success": True,
                "mode_used": storage_mode,
                "steps": step_hidden,
                "generated_ids": generated_ids,
                "generated_text": generated_text,
                "scores": score_steps,
                "attentions": [a for a in getattr(gen, "attentions", None) or []] if capture_attn else None,
                "applied_norms": dict(hook_session.applied_norms),
            })
            return result
        except Exception as e:
            result.update({"error_type": type(e).__name__, "error_message": str(e)})
            if allow_fallback and mode_requested == "full":
                try:
                    with torch.no_grad():
                        gen = self.model.generate(
                            **inputs,
                            max_new_tokens=max_new_tokens,
                            return_dict_in_generate=True,
                            output_scores=True,
                            output_hidden_states=True,
                            output_attentions=False,
                            do_sample=False,
                            use_cache=True,
                            pad_token_id=getattr(self.tokenizer, "pad_token_id", None) or getattr(self.tokenizer, "eos_token_id", None),
                            eos_token_id=getattr(self.tokenizer, "eos_token_id", None),
                            # ★ Cmap12.4 stuck loop 방어 (fallback 경로)
                            repetition_penalty=1.15,
                            no_repeat_ngram_size=4,
                        )
                    sequences = gen.sequences.detach().cpu()
                    generated_ids = sequences[0, input_len:].tolist() if sequences.ndim == 2 else []
                    generated_text = self.tokenizer.decode(generated_ids, skip_special_tokens=True) if generated_ids else ""
                    score_steps = [s.detach().cpu() for s in (getattr(gen, "scores", None) or [])]
                    step_hidden = self._extract_step_hidden(getattr(gen, "hidden_states", None), storage_mode="last_token")
                    result.update({
                        "success": True,
                        "mode_used": "fallback_last_token",
                        "steps": step_hidden,
                        "generated_ids": generated_ids,
                        "generated_text": generated_text,
                        "scores": score_steps,
                        "fallback_from_error": f"{type(e).__name__}: {e}",
                    })
                except Exception as e2:
                    result.update({
                        "error_type": type(e2).__name__,
                        "error_message": f"full_attempt_failed={type(e).__name__}: {e} | fallback_failed={type(e2).__name__}: {e2}",
                        "mode_used": "failed",
                    })
            return result
        finally:
            hook_session.clear()


def summarize_hidden_by_layer(hidden_by_layer: Dict[int, Any], max_layers: int = 6) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    if not HAS_TORCH:
        return rows
    for lid in sorted(list(hidden_by_layer.keys()))[:max_layers]:
        h = hidden_by_layer.get(lid)
        if not isinstance(h, torch.Tensor):
            continue
        rows.append({
            "layer": int(lid),
            "shape": list(h.shape),
            "norm": float(h.norm().item()) if h.numel() else 0.0,
            "mean_abs": float(h.abs().mean().item()) if h.numel() else 0.0,
            "max_abs": float(h.abs().max().item()) if h.numel() else 0.0,
        })
    return rows


def summarize_applied_norms(applied_norms: Dict[int, float]) -> Dict[str, Any]:
    if not applied_norms:
        return {"count": 0, "max_norm": 0.0, "layers": []}
    vals = {int(k): float(v) for k, v in applied_norms.items()}
    return {
        "count": len(vals),
        "max_norm": max(vals.values()) if vals else 0.0,
        "layers": sorted(vals.keys()),
        "norms": vals,
    }


__all__ = [
    "HookCapture",
    "InterventionSpec",
    "ModelLayerLocator",
    "HookSession",
    "RuntimeTraceRunner",
    "summarize_hidden_by_layer",
    "summarize_applied_norms",
]
