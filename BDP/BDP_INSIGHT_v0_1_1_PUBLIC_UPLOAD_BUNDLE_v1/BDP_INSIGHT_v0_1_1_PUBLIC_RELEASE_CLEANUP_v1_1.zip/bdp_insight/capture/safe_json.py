from __future__ import annotations

"""
capture_safe_json.py
====================
Safe JSON serializer for MRI capture.
Never crashes — degrades gracefully on any object type.
"""

import dataclasses
from pathlib import Path
from typing import Any


def safe_jsonable(obj: Any, max_repr: int = 1200) -> Any:
    """Recursively convert any object to JSON-safe form. Never raises."""
    if obj is None or isinstance(obj, (str, int, float, bool)):
        return obj

    if isinstance(obj, Path):
        return str(obj)

    if dataclasses.is_dataclass(obj) and not isinstance(obj, type):
        try:
            return safe_jsonable(dataclasses.asdict(obj), max_repr=max_repr)
        except Exception as e:
            return {
                "__type__": type(obj).__name__,
                "__dataclass_error__": f"{type(e).__name__}: {e}",
                "__repr__": repr(obj)[:max_repr],
            }

    if isinstance(obj, dict):
        out = {}
        for k, v in obj.items():
            try:
                out[str(k)] = safe_jsonable(v, max_repr=max_repr)
            except Exception as e:
                out[str(k)] = {
                    "__key_error__": f"{type(e).__name__}: {e}",
                    "__repr__": repr(v)[:max_repr],
                }
        return out

    if isinstance(obj, (list, tuple, set)):
        return [safe_jsonable(x, max_repr=max_repr) for x in obj]

    # tensor / numpy / torch-like
    shape = getattr(obj, "shape", None)
    if shape is not None:
        return {
            "__type__": type(obj).__name__,
            "shape": list(shape) if hasattr(shape, "__iter__") else str(shape),
            "dtype": str(getattr(obj, "dtype", None)),
            "device": str(getattr(obj, "device", None)),
        }

    # try to_dict but never trust it
    to_dict = getattr(obj, "to_dict", None)
    if callable(to_dict):
        try:
            return safe_jsonable(to_dict(), max_repr=max_repr)
        except Exception as e:
            return {
                "__type__": type(obj).__name__,
                "__to_dict_error__": f"{type(e).__name__}: {e}",
                "__repr__": repr(obj)[:max_repr],
            }

    # fallback to vars()
    try:
        return {
            "__type__": type(obj).__name__,
            "__vars__": {
                str(k): safe_jsonable(v, max_repr=max_repr)
                for k, v in vars(obj).items()
                if not str(k).startswith("_")
            },
        }
    except Exception:
        return {
            "__type__": type(obj).__name__,
            "__repr__": repr(obj)[:max_repr],
        }


__all__ = ["safe_jsonable"]
