from __future__ import annotations

"""
capture_session_writer.py
=========================
Forensic-grade session writer for MRI capture.
Core guarantee: session directory and manifest ALWAYS exist,
even if deep capture fails completely.

Req5: Each session emits capture_index.json (lightweight).
      Global index.jsonl is appended at finalize.
"""

import json
import time
import traceback
import uuid
from pathlib import Path
from typing import Any, Dict, Optional

from .safe_json import safe_jsonable


class CaptureSessionWriter:
    """Creates session dir immediately, writes stages incrementally, always finalizes."""

    def __init__(self, outdir: str | Path, route: str, source: str = "main"):
        self.outdir = Path(outdir)
        self.outdir.mkdir(parents=True, exist_ok=True)

        ts = time.strftime("%Y%m%d_%H%M%S")
        self.session_id = f"run_{ts}_{uuid.uuid4().hex[:6]}"
        self.session_dir = self.outdir / self.session_id
        self.session_dir.mkdir(parents=True, exist_ok=True)

        self.route = route
        self.source = source

        self.manifest: Dict[str, Any] = {
            "session_id": self.session_id,
            "route": route,
            "source": source,
            "status": "started",
            "created_at": time.time(),
            "stage_files": [],
            "errors": [],
        }
        self._write_json("manifest.json", self.manifest)

        # Req5: lightweight index metadata (populated by caller before finalize)
        self._index_extra: Dict[str, Any] = {}

    def _write_json(self, name: str, payload: Any) -> str:
        path = self.session_dir / name
        try:
            path.write_text(
                json.dumps(safe_jsonable(payload), ensure_ascii=False, indent=2),
                encoding="utf-8",
            )
        except Exception as e:
            path.write_text(
                json.dumps({"__write_error__": f"{type(e).__name__}: {e}"}),
                encoding="utf-8",
            )
        return str(path)

    def write_stage(self, name: str, payload: Any) -> str:
        filename = f"{name}.json"
        p = self._write_json(filename, payload)
        self.manifest["stage_files"].append(filename)
        self._write_json("manifest.json", self.manifest)
        return p

    def write_error(self, stage: str, exc: Exception, extra: Optional[Dict[str, Any]] = None):
        item = {
            "stage": stage,
            "error_type": type(exc).__name__,
            "error": str(exc),
            "traceback": traceback.format_exc(),
            "extra": safe_jsonable(extra or {}),
            "ts": time.time(),
        }
        self.manifest["errors"].append(item)
        self._write_json(f"error_{stage}.json", item)
        self._write_json("manifest.json", self.manifest)

    def set_index_meta(self, meta: Dict[str, Any]):
        """Set lightweight index metadata before finalize."""
        self._index_extra.update(meta)

    def finalize(self, status: str = "ok", extra: Optional[Dict[str, Any]] = None) -> str:
        self.manifest["status"] = status
        self.manifest["finalized_at"] = time.time()
        if extra:
            self.manifest.update(safe_jsonable(extra))
        self._write_json("manifest.json", self.manifest)

        # Req5: per-session capture_index.json
        index_record = {
            "session_id": self.session_id,
            "created_at": self.manifest["created_at"],
            "finalized_at": self.manifest["finalized_at"],
            "source": self.source,
            "route": self.route,
            "status": status,
            "stage_files": self.manifest["stage_files"],
            "n_errors": len(self.manifest["errors"]),
        }
        index_record.update(safe_jsonable(self._index_extra))

        # file sizes
        sizes = {}
        for sf in self.manifest["stage_files"]:
            fp = self.session_dir / sf
            if fp.exists():
                sizes[sf] = fp.stat().st_size
        index_record["file_sizes"] = sizes

        self._write_json("capture_index.json", index_record)

        # Req5: append to global index.jsonl
        try:
            jsonl_path = self.outdir / "index.jsonl"
            line = json.dumps(safe_jsonable(index_record), ensure_ascii=False) + "\n"
            with open(jsonl_path, "a", encoding="utf-8") as f:
                f.write(line)
        except Exception:
            pass  # non-critical

        return str(self.session_dir)


__all__ = ["CaptureSessionWriter"]
