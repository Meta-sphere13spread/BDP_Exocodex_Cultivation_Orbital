from __future__ import annotations
import time, uuid, json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict
from .atomic import atomic_append_jsonl, atomic_write_json


def _safe_jsonable(x: Any) -> Any:
    try:
        json.dumps(x)
        return x
    except Exception:
        if isinstance(x, dict): return {str(k): _safe_jsonable(v) for k, v in x.items()}
        if isinstance(x, (list, tuple)): return [_safe_jsonable(v) for v in x]
        return str(x)


@dataclass
class BasicCaptureWriter:
    """Free-tier static capture writer.

    Per user policy (2026-05-03): OBDA / IRS-DCE / geometry / lens are
    PUBLIC (already published as research artefacts).  Only the dynamic
    intervention algorithms (L2 / L3 surgery, Lens-protected internals)
    remain paid.  Therefore:
      - hidden states (last-token per layer): captured if `result` provides them
      - geometry / OBDA / lens / effective_rank: not blocked, included if present
      - L2/L3 intervention algorithms: still paid (server-side)
    """
    outdir: str = 'results/base_mri_capture'
    source: str = 'base_model'

    def write_run(self, prompt: str, result: Dict[str, Any], *, model_id: str = 'base_model', route: str = 'BASE') -> str:
        root = Path(self.outdir)
        root.mkdir(parents=True, exist_ok=True)
        sid = 'run_' + time.strftime('%Y%m%d_%H%M%S') + '_' + uuid.uuid4().hex[:8]
        d = root / sid
        d.mkdir(parents=True, exist_ok=True)

        # Optional fields (present iff capture pipeline produced them) ----
        hidden_states = result.get('hidden_states_per_layer')   # list[list[float]] or list[ndarray-like]
        geometry      = result.get('geometry')                  # CPI/EDS/CDI/AGA dict if computed
        obda          = result.get('obda')                      # OBDA scalars if computed
        lens          = result.get('lens_attractor')            # lens attractor if computed

        index = {
            'session_id': sid,
            'ts': time.time(),
            'source': self.source,
            'tier': 'free',
            'model_id': model_id,
            'route': route,
            'status': 'ok',
            # capture_scope reflects what was actually written this run
            'capture_scope': [k for k, v in [
                ('prompt_preview',   True),
                ('answer_preview',   True),
                ('latency_sec',      True),
                ('run_metadata',     True),
                ('hidden_states',    hidden_states is not None),
                ('geometry',         geometry is not None),
                ('obda',             obda is not None),
                ('lens_attractor',   lens is not None),
            ] if v],
            # paid scope shrunk: only L2/L3 intervention algorithms remain paid
            'excluded_paid_scope': ['l2_l3_intervention_algorithm'],
            'prompt_len': len(prompt or ''),
            'answer_len': len(str(result.get('answer', ''))),
        }
        result_minimal = {
            'prompt_preview': (prompt or '')[:240],
            'answer_preview': str(result.get('answer', ''))[:240],
            'route': route,
            'latency_sec': result.get('latency_sec', 0.0),
            'model_id': model_id,
            'tier': 'free',
            'debug': {
                'ok': True,
                'failure_reason': '',
                'paid_features_omitted': hidden_states is None and geometry is None,
            },
        }
        # Public-safe additions (only if captured) ------------------------
        if hidden_states is not None:
            result_minimal['hidden_states_per_layer'] = hidden_states
        if geometry is not None:
            result_minimal['geometry'] = geometry
        if obda is not None:
            result_minimal['obda'] = obda
        if lens is not None:
            result_minimal['lens_attractor'] = lens

        manifest = {'ok': True, 'session_id': sid, 'files': ['capture_index.json', 'result_minimal.json'], 'created_at': index['ts']}
        atomic_write_json(d / 'capture_index.json', index)
        atomic_write_json(d / 'result_minimal.json', _safe_jsonable(result_minimal))
        atomic_write_json(d / 'manifest.json', manifest)
        atomic_append_jsonl(root / 'index.jsonl', index)
        return sid
