"""Command-line entry points for BDP-insight.

The CLI is intentionally a thin wrapper around the public Python API.  It keeps
client-side credentials explicit and never asks for provider-side secret.
"""
from __future__ import annotations

from pathlib import Path
from typing import Optional
import argparse
import getpass
import json
import os
import sys
import urllib.request

from .api import (
    BDPHodgeConfig,
    attach_hodge_debugger,
    check_rapidapi_config,
    generate_text,
    queue_hodge_output_intervention,
)
from .launchers import start_dynamic_dashboard, start_static_studio


DEFAULT_URL = "https://bdp-insight-l2.p.rapidapi.com/v1/hodge/convert"
DEFAULT_HOST = "bdp-insight-l2.p.rapidapi.com"


def _yes(value: str) -> bool:
    return str(value or "").strip().lower() in {"y", "yes"}


def _prompt(text: str, default: str = "", secret: bool = False) -> str:
    suffix = f" [{default}]" if default else ""
    hint = ""
    if ("URL" in text or "Host" in text) and default:
        hint = "  (press Enter to use default; do not type y/n here)"
    raw = getpass.getpass(text + suffix + hint + ": ") if secret else input(text + suffix + hint + ": ")
    raw = raw.strip()

    # Common interactive mistake: user types y/n at URL/Host prompt because
    # they are expecting the dashboard question.  Treat this as "use default"
    # instead of accepting y/v1/hodge/convert as a broken URL.
    if ("URL" in text or "Host" in text) and raw.lower() in {"y", "yes", "n", "no"} and default:
        print(f"[BDP] {text}: got {raw!r}; using default {default!r}. Dashboard questions come later.")
        return default

    return raw if raw else default


def prompt_config() -> BDPHodgeConfig:
    print("BDP-insight L2 HodgeConverter v0.1.1")
    print("Paste customer-side RapidAPI values only. Do NOT paste provider-side secret.")
    print("At the URL/Host prompts, press Enter to use defaults or paste values from the Code Snippet.")
    print("The y/N dashboard questions appear after API config is accepted.\n")

    url = _prompt("RapidAPI URL", os.getenv("BDP_RAPIDAPI_URL", DEFAULT_URL))
    host = _prompt("RapidAPI Host", os.getenv("BDP_RAPIDAPI_HOST", DEFAULT_HOST))
    key_default = os.getenv("BDP_RAPIDAPI_KEY", "")
    key = _prompt("RapidAPI Key", key_default, secret=True)

    cfg = BDPHodgeConfig(rapidapi_url=url, rapidapi_host=host, rapidapi_key=key, debug=True)
    summary = check_rapidapi_config(cfg)
    print("[config]", summary)
    if not summary.get("ok"):
        raise SystemExit(
            "RapidAPI config is incomplete. rapidapi_url must be a full https://.../v1/hodge/convert URL, "
            "rapidapi_host must be the X-RapidAPI-Host value, and rapidapi_key must be your X-RapidAPI-Key."
        )
    return cfg


def smoke_main(argv: Optional[list[str]] = None) -> int:
    ap = argparse.ArgumentParser(description="BDP-insight API Hub / Modal smoke test")
    ap.add_argument("--url", default=os.getenv("BDP_RAPIDAPI_URL", DEFAULT_URL))
    ap.add_argument("--host", default=os.getenv("BDP_RAPIDAPI_HOST", DEFAULT_HOST))
    ap.add_argument("--key", default=os.getenv("BDP_RAPIDAPI_KEY", ""))
    ap.add_argument("--text", default="2 + 4 = 6")
    ap.add_argument("--replacement", default="9")
    ap.add_argument("--target-regex", default="2")
    args = ap.parse_args(argv)

    key = args.key or getpass.getpass("RapidAPI Key: ").strip()
    body = {
        "text": args.text,
        "replacement": args.replacement,
        "target_regex": args.target_regex,
        "mode": "output",
    }
    req = urllib.request.Request(
        args.url,
        data=json.dumps(body, ensure_ascii=False).encode("utf-8"),
        headers={
            "Content-Type": "application/json; charset=utf-8",
            "X-RapidAPI-Key": key,
            "X-RapidAPI-Host": args.host,
        },
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=60) as resp:
        print(resp.read().decode("utf-8"))
    return 0


def dashboard_main(argv: Optional[list[str]] = None) -> int:
    ap = argparse.ArgumentParser(description="Start BDP-insight dynamic dashboard")
    ap.add_argument("--run-dir", default="results/bdp_hodge_run")
    ap.add_argument("--capture-dir", default="results/bdp_hodge_capture")
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--port", type=int, default=7860)
    ap.add_argument("--no-open", action="store_true")
    args = ap.parse_args(argv)
    launched = start_dynamic_dashboard(
        run_dir=args.run_dir,
        capture_dir=args.capture_dir,
        host=args.host,
        port=args.port,
        open_url=not args.no_open,
    )
    print(f"Dynamic dashboard: {launched.url}")
    print("Press Ctrl+C to stop.")
    try:
        launched.process.wait() if launched.process else None
    except KeyboardInterrupt:
        launched.terminate()
    return 0


def static_main(argv: Optional[list[str]] = None) -> int:
    ap = argparse.ArgumentParser(description="Start BDP-insight Streamlit Studio")
    ap.add_argument("--events-path", default="results/bdp_hodge_run/dynamic_debug/events.jsonl")
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--port", type=int, default=8501)
    ap.add_argument("--no-open", action="store_true")
    args = ap.parse_args(argv)
    try:
        launched = start_static_studio(
            events_path=args.events_path,
            host=args.host,
            port=args.port,
            open_url=not args.no_open,
        )
    except RuntimeError as exc:
        print(f"[BDP] {exc}")
        return 2
    print(f"Static Studio: {launched.url}")
    print("Press Ctrl+C to stop.")
    try:
        launched.process.wait() if launched.process else None
    except KeyboardInterrupt:
        launched.terminate()
    return 0


def chat_main(argv: Optional[list[str]] = None) -> int:
    ap = argparse.ArgumentParser(description="Interactive BDP-insight chat example")
    ap.add_argument("--model", default=os.getenv("BDP_MODEL_ID", "Qwen/Qwen2.5-0.5B-Instruct"))
    ap.add_argument("--run-dir", default="results/bdp_hodge_run")
    ap.add_argument("--capture-dir", default="results/bdp_hodge_capture")
    ap.add_argument("--max-tokens", type=int, default=int(os.getenv("BDP_CHAT_MAX_TOKENS", "128")))
    ap.add_argument("--no-prompt-config", action="store_true")
    ap.add_argument("--no-capture", action="store_true", help="Disable hidden-state capture. Static Studio IRS-DCE needs capture enabled.")
    ap.add_argument("--dynamic-dashboard", action="store_true")
    ap.add_argument("--static-studio", action="store_true")
    args = ap.parse_args(argv)

    cfg = prompt_config() if not args.no_prompt_config else BDPHodgeConfig(
        rapidapi_url=os.getenv("BDP_RAPIDAPI_URL", DEFAULT_URL),
        rapidapi_host=os.getenv("BDP_RAPIDAPI_HOST", DEFAULT_HOST),
        rapidapi_key=os.getenv("BDP_RAPIDAPI_KEY", ""),
        debug=True,
    )
    try:
        cfg.apply_env()
    except ValueError as exc:
        print(f"[BDP] invalid RapidAPI config: {exc}")
        return 2

    if not args.dynamic_dashboard:
        args.dynamic_dashboard = _yes(input("Launch dynamic dashboard? [y/N]: "))
    if not args.static_studio:
        args.static_studio = _yes(input("Launch static Studio? [y/N]: "))

    launched = []
    if args.dynamic_dashboard:
        d = start_dynamic_dashboard(run_dir=args.run_dir, capture_dir=args.capture_dir)
        launched.append(d)
        print(f"Dynamic dashboard: {d.url}")

    if args.static_studio:
        events_path = str(Path(args.run_dir) / "dynamic_debug" / "events.jsonl")
        try:
            s = start_static_studio(events_path=events_path)
            launched.append(s)
            print(f"Static Studio: {s.url}")
        except RuntimeError as exc:
            print(f"[BDP] static Studio skipped: {exc}")

    print("[BDP] loading Hugging Face model...")
    try:
        import torch
        from transformers import AutoModelForCausalLM, AutoTokenizer
    except ImportError:
        print("[BDP] Missing dependencies. Install with: pip install bdp-insight[hf]")
        return 2

    tokenizer = AutoTokenizer.from_pretrained(args.model, trust_remote_code=True)
    if getattr(tokenizer, "pad_token_id", None) is None:
        tokenizer.pad_token_id = getattr(tokenizer, "eos_token_id", None)
    model = AutoModelForCausalLM.from_pretrained(
        args.model,
        torch_dtype=torch.float32,
        trust_remote_code=True,
    ).eval()

    model = attach_hodge_debugger(
        model=model,
        tokenizer=tokenizer,
        config=cfg,
        model_id=args.model,
        run_dir=args.run_dir,
        outdir=args.capture_dir,
        enable_capture=not args.no_capture,
    )

    print("\nChat started.")
    print("Commands:")
    print("  /hodge NEW_WORD TARGET_REGEX [WAIT] [CONT]")
    print("  /max N")
    print("  /quit")
    if not args.no_capture:
        print("[BDP] capture enabled: Static Studio IRS-DCE can use result_minimal.json hidden_states_per_layer.")
    else:
        print("[BDP] capture disabled: Static Studio IRS-DCE will show no hidden-state capture run.")
    max_tokens = int(args.max_tokens)

    while True:
        try:
            prompt = input("\nyou> ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\n[BDP] bye")
            break
        if not prompt:
            continue
        if prompt.lower() in {"/q", "/quit", "/exit"}:
            break
        if prompt.lower().startswith("/max"):
            parts = prompt.split()
            if len(parts) >= 2:
                try:
                    max_tokens = int(parts[1])
                    print(f"[BDP] max_new_tokens={max_tokens}")
                except Exception as exc:
                    print(f"[BDP] invalid /max: {exc}")
            else:
                print(f"[BDP] max_new_tokens={max_tokens}")
            continue
        if prompt.lower().startswith("/hodge"):
            parts = prompt.split(maxsplit=4)
            if len(parts) < 3:
                print("usage: /hodge NEW_WORD TARGET_REGEX [WAIT] [CONT]")
                continue
            new_word = parts[1]
            target_regex = parts[2]
            wait_tokens = int(parts[3]) if len(parts) >= 4 else 8
            cont_tokens = int(parts[4]) if len(parts) >= 5 else 32
            queue_hodge_output_intervention(
                run_dir=args.run_dir,
                new_word=new_word,
                target_regex=target_regex,
                wait_tokens=wait_tokens,
                continuation_tokens=cont_tokens,
            )
            print(f"[BDP] queued Hodge: {target_regex} -> {new_word}, wait={wait_tokens}, cont={cont_tokens}")
            continue

        print(generate_text(model=model, tokenizer=tokenizer, prompt=prompt, max_new_tokens=max_tokens))

    for proc in launched:
        proc.terminate()
    return 0


if __name__ == "__main__":
    raise SystemExit(chat_main())
