from __future__ import annotations
import json, time, uuid
from pathlib import Path
from typing import Any, Dict, List, Tuple
from .atomic import atomic_append_jsonl, atomic_read_json, atomic_write_json


class CommandQueue:
    """Small file-backed command queue for the free dynamic debugger.

    Free tier commands intentionally supported here:
      - rewrite_prompt: L1 prompt/text replacement
      - pause/resume/snapshot/abort: local debugging controls

    Paid L2/L3 commands are not silently executed in the free client. They are
    recorded as billing_required events so the caller can route them through the
    PremiumDebuggerClient/API.
    """

    def __init__(self, run_dir: str | Path):
        self.run_dir = Path(run_dir)
        self.root = self.run_dir / 'dynamic_debug'
        self.root.mkdir(parents=True, exist_ok=True)
        self.commands_path = self.root / 'commands.jsonl'
        self.state_path = self.root / 'current_state.json'
        self.events_path = self.root / 'events.jsonl'

    def push_command(self, op: str, **payload: Any) -> Dict[str, Any]:
        cmd = {
            'id': f'cmd_{uuid.uuid4().hex[:12]}',
            'ts': time.time(),
            'op': str(op),
            'payload': payload,
        }
        atomic_append_jsonl(self.commands_path, cmd)
        return cmd

    def read_commands_since(self, cursor: int = 0) -> Tuple[List[Dict[str, Any]], int]:
        if not self.commands_path.exists():
            return [], cursor
        try:
            lines = self.commands_path.read_text(encoding='utf-8').splitlines()
        except Exception:
            return [], cursor
        rows: List[Dict[str, Any]] = []
        for line in lines[cursor:]:
            try:
                rows.append(json.loads(line))
            except Exception as exc:
                self.append_event({'kind': 'command_parse_error', 'error': str(exc), 'raw': line[:300], 'ts': time.time()})
        return rows, len(lines)

    def write_state(self, state: Dict[str, Any]) -> None:
        atomic_write_json(self.state_path, state)

    def read_state(self) -> Dict[str, Any]:
        return atomic_read_json(self.state_path, default={}) or {}

    def append_event(self, event: Dict[str, Any]) -> None:
        atomic_append_jsonl(self.events_path, event)
