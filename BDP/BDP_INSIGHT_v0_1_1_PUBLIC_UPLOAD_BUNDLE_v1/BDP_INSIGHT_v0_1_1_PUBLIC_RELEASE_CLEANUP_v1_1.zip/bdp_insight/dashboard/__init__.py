"""BDP Insight prototype dashboard.

Flask-based minimal surface showing the 5 intervention indicators live.

This is intentionally small — it is the "최소단위로 보여주는 장치" piece.
Heavy historical/static analysis goes in the Streamlit `studio/`, not here.
"""
from __future__ import annotations

from .flask_app import create_app, run_dev

__all__ = ["create_app", "run_dev"]
