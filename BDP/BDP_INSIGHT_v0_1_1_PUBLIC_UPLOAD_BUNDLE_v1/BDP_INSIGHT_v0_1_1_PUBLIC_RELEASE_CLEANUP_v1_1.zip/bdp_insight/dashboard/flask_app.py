"""BDP Insight — minimal Flask prototype dashboard.

Shows the 5 intervention indicators live, with a clear "Prototype" label.

Endpoints:
    GET  /                     HTML page (renders the indicators)
    GET  /state                JSON: latest state (current + 5 indicators)
    POST /events               JSON: register an intervention event
                               body: {"event": {...InterventionEvent dict...}}
    POST /events/clear         clear the in-memory event buffer
    GET  /healthz              liveness

Why so small:
    The dashboard is the **prototype proof** that token-level surgery is real
    and that the 5 indicators read it.  Heavy historical analysis belongs in
    the Streamlit `studio/` — this Flask app stays under ~350 lines.

Debug markers:
    BDP_INSIGHT_DASH_*  (env BDP_INSIGHT_DEBUG=1)
"""
from __future__ import annotations

import json
import os
import sys
import time
from typing import Any, Dict, List, Optional

try:
    from flask import Flask, jsonify, request, Response
except ImportError as exc:  # pragma: no cover
    raise RuntimeError(
        "Flask is required for the prototype dashboard. "
        "Install with: pip install bdp-insight[dashboard]"
    ) from exc

from .. import __version__, __release_phase__
from ..intervention_event import InterventionEvent, normalize_event
from ..indicators import (
    compute_surgery_impact,
    compute_dependency_shift,
    compute_stale_reasoning,
    compute_continuation_recond,
    compute_intervention_timeline,
)


# ──────────────────────────────────────────────────────────────────────
# Debug marker
# ──────────────────────────────────────────────────────────────────────

def _debug(marker: str, **kw: Any) -> None:
    if os.environ.get("BDP_INSIGHT_DEBUG", "").strip() not in ("1", "true", "yes"):
        return
    parts = [f"{k}={_short(v)}" for k, v in kw.items()]
    print(f"[BDP_INSIGHT_DASH {marker}] " + " ".join(parts), file=sys.stderr)


def _short(v: Any, limit: int = 60) -> str:
    s = repr(v)
    return s if len(s) <= limit else s[:limit] + "...]"


# ──────────────────────────────────────────────────────────────────────
# In-memory event buffer (per-process; for prototype only)
# ──────────────────────────────────────────────────────────────────────

class _EventBuffer:
    """Tiny in-memory ring of InterventionEvents.

    Real deployments would back this with capture/session_writer.py and
    rotate to events.jsonl files.  For the prototype we keep it in RAM so
    the Flask app starts with zero filesystem assumptions.
    """
    def __init__(self, max_items: int = 200) -> None:
        self._buf: List[InterventionEvent] = []
        self._max = max_items

    def append(self, ev: InterventionEvent) -> None:
        self._buf.append(ev)
        if len(self._buf) > self._max:
            # 가장 오래된 것부터 drop (queue semantics)
            drop = len(self._buf) - self._max
            self._buf = self._buf[drop:]
        _debug("buffer.append", n=len(self._buf))

    def all(self) -> List[InterventionEvent]:
        return list(self._buf)

    def latest(self) -> Optional[InterventionEvent]:
        return self._buf[-1] if self._buf else None

    def clear(self) -> int:
        n = len(self._buf)
        self._buf.clear()
        _debug("buffer.clear", n=n)
        return n


# ──────────────────────────────────────────────────────────────────────
# HTML page (single string — prototype-grade, no external CSS/JS)
# ──────────────────────────────────────────────────────────────────────

_INDEX_HTML = """<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>BDP Insight · Prototype</title>
<style>
  body {
    font-family: -apple-system, "Segoe UI", "Helvetica Neue", Arial, sans-serif;
    background: #0e0f12; color: #d8dde2; margin: 0; padding: 20px 28px;
  }
  .topbar {
    display: flex; justify-content: space-between; align-items: baseline;
    border-bottom: 1px solid #2a2d33; padding-bottom: 10px; margin-bottom: 16px;
  }
  .topbar .name { font-weight: 600; font-size: 16px; color: #e9eef3; }
  .topbar .ver  { color: #8a93a0; font-size: 12px; }
  .badge {
    display: inline-block; padding: 1px 7px; margin-left: 6px;
    border-radius: 3px; font-size: 11px; letter-spacing: 0.4px;
    background: #4a3700; color: #ffd166; border: 1px solid #634800;
  }
  .card {
    background: #16181d; border: 1px solid #262a32; border-radius: 6px;
    padding: 12px 14px; margin-bottom: 12px;
  }
  .card h3 {
    margin: 0 0 6px 0; font-size: 13px; color: #95a3b3; font-weight: 500;
    letter-spacing: 0.3px;
  }
  .card .label { font-size: 14px; color: #e9eef3; }
  .card .note  { font-size: 12px; color: #8a93a0; margin-top: 4px; }
  .pill {
    display: inline-block; padding: 1px 7px; border-radius: 9px;
    font-size: 11px; margin-right: 4px; border: 1px solid #2e3138;
    background: #1c1f25; color: #a8b3bf;
  }
  .pill.high   { background: #3b1d1d; color: #ff8b8b; border-color: #5a2828; }
  .pill.mod    { background: #3b3119; color: #ffd166; border-color: #5a4828; }
  .pill.low    { background: #1d3b22; color: #88e09a; border-color: #285a30; }
  .pill.stale  { background: #3b1d1d; color: #ff8b8b; border-color: #5a2828; }
  .pill.stable { background: #1d3b22; color: #88e09a; border-color: #285a30; }
  .footer {
    color: #6a727f; font-size: 11px; margin-top: 28px; line-height: 1.6;
    border-top: 1px solid #2a2d33; padding-top: 10px;
  }
  pre.timeline {
    background: #0a0b0e; border: 1px solid #1f2228; border-radius: 4px;
    padding: 10px; font-size: 11px; color: #a8b3bf; max-height: 180px;
    overflow: auto; margin: 6px 0 0 0;
  }
  .empty { color: #6a727f; font-style: italic; }
</style>
</head>
<body>
  <div class="topbar">
    <div>
      <span class="name">BDP Insight · Surgery Suite</span>
      <span class="badge">PROTOTYPE</span>
      <span class="ver">v__VERSION__ · L1 / L2 / L3 token surgery</span>
    </div>
    <div id="status" class="ver">Loading…</div>
  </div>

  <div class="card" id="card-impact"><h3>1 · Surgery Impact Map</h3>
    <div class="label empty">no surgery yet</div></div>
  <div class="card" id="card-dep"><h3>2 · Token Dependency Shift</h3>
    <div class="label empty">no surgery yet</div></div>
  <div class="card" id="card-stale"><h3>3 · Stale Reasoning Detector</h3>
    <div class="label empty">no surgery yet</div></div>
  <div class="card" id="card-cont"><h3>4 · Continuation Reconditioning</h3>
    <div class="label empty">no surgery yet</div></div>
  <div class="card" id="card-tl"><h3>5 · Intervention Timeline</h3>
    <div class="label empty">empty</div>
    <pre class="timeline" id="tl-list"></pre></div>

  <div class="footer">
    This is a working prototype showing token-level surgery is real on a base /
    HF model.  The five indicators above describe <em>change</em> — not
    correctness.  Final interpretation is left to the user.<br>
    For full historical inspection, use the Streamlit Studio (separate process).
  </div>

<script>
async function refresh() {
  try {
    const r = await fetch('/state'); const s = await r.json();
    const stat = document.getElementById('status');
    stat.textContent = s.idle ? 'Idle. ' : 'Live. ';
    stat.textContent += '(' + s.summary.n_total + ' events, '
      + s.summary.n_applied + ' applied, ' + s.summary.n_blocked + ' blocked)';

    function pill(v, kind) {
      const cls = (kind || '') + ' ' + (v || '').toLowerCase().replace(/[^a-z]/g,'');
      return '<span class="pill ' + cls + '">' + (v || '') + '</span>';
    }

    if (s.surgery_impact) {
      const i = s.surgery_impact;
      document.querySelector('#card-impact .label').innerHTML =
        i.label + '<br>' + pill(i.impact) + pill(i.affected_stage) + pill(i.stability);
      document.querySelector('#card-impact').insertAdjacentHTML('beforeend', '');
      let n = document.querySelector('#card-impact .note');
      if (!n) { document.querySelector('#card-impact').insertAdjacentHTML('beforeend','<div class="note"></div>'); n = document.querySelector('#card-impact .note'); }
      n.textContent = i.note || '';
    }
    if (s.dependency_shift) {
      const i = s.dependency_shift;
      document.querySelector('#card-dep .label').innerHTML =
        i.label + '<br>' + pill(i.shift) + pill(i.result_path);
    }
    if (s.stale_reasoning) {
      const i = s.stale_reasoning;
      const cls = i.consistency === 'Stale' ? 'stale' : 'stable';
      document.querySelector('#card-stale .label').innerHTML =
        i.label + ' ' + (i.warning ? '⚠' : '') + '<br>' + pill(i.consistency, cls);
    }
    if (s.continuation_recond) {
      const i = s.continuation_recond;
      document.querySelector('#card-cont .label').innerHTML = i.label;
    }
    if (s.timeline) {
      const i = s.timeline;
      document.querySelector('#card-tl .label').textContent = i.label;
      const lines = (i.items || []).map(it =>
        ('  ' + (it.kind_label || '?')).padEnd(36)
        + ('family=' + it.family).padEnd(15)
        + ('status=' + it.status).padEnd(18)
        + (it.ago_sec != null ? '(' + it.ago_sec + 's ago)' : '')
      ).join('\\n');
      document.getElementById('tl-list').textContent = lines || '(empty)';
    }
  } catch (e) {
    document.getElementById('status').textContent = 'Connection error: ' + e;
  }
}
refresh(); setInterval(refresh, 1500);
</script>
</body>
</html>
"""


# ──────────────────────────────────────────────────────────────────────
# Flask app factory
# ──────────────────────────────────────────────────────────────────────

def create_app(buffer: Optional[_EventBuffer] = None) -> Flask:
    """Build a Flask app with the in-memory event buffer.

    The buffer can be shared with `attach.py` so that real model events
    get appended into the same ring that the dashboard reads from.

    Endpoints intentionally small — easy to extend, easy to read.
    """
    app = Flask(__name__)
    app.config["JSON_SORT_KEYS"] = False
    buf = buffer or _EventBuffer()
    app.extensions["bdp_insight_buffer"] = buf

    # ── HTML page ────────────────────────────────────────────────
    @app.route("/", methods=["GET"])
    def index() -> Response:
        html = _INDEX_HTML.replace("__VERSION__", __version__)
        _debug("route.index")
        return Response(html, mimetype="text/html; charset=utf-8")

    # ── State (5 indicators) ────────────────────────────────────
    @app.route("/state", methods=["GET"])
    def state() -> Response:
        events = buf.all()
        latest = buf.latest()
        if latest is None:
            payload = _empty_state()
        else:
            payload = _build_state(latest, events)
        _debug("route.state", n_events=len(events), idle=(latest is None))
        return jsonify(payload)

    # ── Register an intervention event ──────────────────────────
    @app.route("/events", methods=["POST"])
    def post_events() -> Response:
        try:
            body = request.get_json(force=True, silent=False)
        except Exception as exc:
            _debug("route.events.bad_json", err=type(exc).__name__)
            return jsonify({"ok": False, "error": "invalid_json"}), 400
        if not isinstance(body, dict):
            return jsonify({"ok": False, "error": "body_must_be_object"}), 400

        raw = body.get("event") or body  # 호환성: {event:{...}} 또는 {...} 그대로
        try:
            ev = normalize_event(raw)
        except Exception as exc:
            _debug("route.events.normalize_failed", err=type(exc).__name__)
            return jsonify({"ok": False, "error": "normalize_failed"}), 400

        buf.append(ev)
        _debug("route.events.ok",
               source=ev.source_tool, kind=ev.target_kind, status=ev.status)
        return jsonify({"ok": True, "n_total": len(buf.all())})

    # ── Clear the buffer ────────────────────────────────────────
    @app.route("/events/clear", methods=["POST"])
    def clear_events() -> Response:
        n = buf.clear()
        return jsonify({"ok": True, "cleared": n})

    # ── Liveness ────────────────────────────────────────────────
    @app.route("/healthz", methods=["GET"])
    def healthz() -> Response:
        return jsonify({
            "ok": True,
            "package": "bdp_insight",
            "version": __version__,
            "phase": __release_phase__,
            "prototype": True,
            "n_events": len(buf.all()),
        })

    return app


# ──────────────────────────────────────────────────────────────────────
# Helpers
# ──────────────────────────────────────────────────────────────────────

def _empty_state() -> Dict[str, Any]:
    return {
        "idle": True,
        "version": __version__,
        "prototype": True,
        "surgery_impact": None,
        "dependency_shift": None,
        "stale_reasoning": None,
        "continuation_recond": None,
        "timeline": compute_intervention_timeline([]),
        "summary": {"n_total": 0, "n_applied": 0, "n_blocked": 0, "by_family": {}},
    }


def _build_state(
    latest: InterventionEvent,
    all_events: List[InterventionEvent],
) -> Dict[str, Any]:
    timeline = compute_intervention_timeline(all_events)
    return {
        "idle": False,
        "version": __version__,
        "prototype": True,
        "surgery_impact": compute_surgery_impact(latest),
        "dependency_shift": compute_dependency_shift(latest),
        "stale_reasoning": compute_stale_reasoning(latest),
        "continuation_recond": compute_continuation_recond(latest),
        "timeline": timeline,
        "summary": timeline["summary"],
    }


# ──────────────────────────────────────────────────────────────────────
# Convenience runner — for quick local prototype
# ──────────────────────────────────────────────────────────────────────

def run_dev(host: str = "127.0.0.1", port: int = 8765) -> None:
    """Run the dev Flask server (single process).  Prototype only."""
    app = create_app()
    print(
        f"[BDP_INSIGHT v{__version__} · PROTOTYPE] "
        f"dashboard listening on http://{host}:{port}",
        file=sys.stderr,
    )
    app.run(host=host, port=port, debug=False, use_reloader=False)


if __name__ == "__main__":
    run_dev()
