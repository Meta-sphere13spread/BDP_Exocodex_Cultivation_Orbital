"""entitlement.py — runtime free/paid gate for Meta-13 MRI v1.13.4.

Design goal
-----------
One distribution can run as either free or paid:

- no key  -> free behavior, L2/L3 commands are blocked
- key set -> paid runtime path opens locally now, and can later call the
             SaaS lease path for encrypted/signed native function delivery

No prompt/log/tensor payload is uploaded here.  The key is only a capability
switch and, in future lease mode, an entitlement credential.
"""
from __future__ import annotations

from dataclasses import dataclass
import os
from typing import Optional


_KEY_ENV_NAMES = (
    "META13_PAID_KEY",
    "META13_API_KEY",
    "META13_ENTITLEMENT_TOKEN",
)

_FALSE_VALUES = {"", "0", "false", "no", "off", "none", "null", "free"}
_PLACEHOLDER_VALUES = {"changeme", "replace-me", "your-key", "dummy", "example"}


@dataclass(frozen=True)
class RuntimeEntitlement:
    """Resolved runtime capability flags."""

    tier: str = "free"
    paid_enabled: bool = False
    paid_mode: str = "free"  # free | local_import | lease_stub | lease_remote | modal_remote
    key_source: str = "missing"
    api_base: str = "https://api.meta13.example"
    client_version: str = "0.1.13.4-runtime"

    @property
    def has_key(self) -> bool:
        return self.key_source not in {"missing", "disabled", "invalid_placeholder"}

    def public_dict(self) -> dict:
        return {
            "tier": self.tier,
            "paid_enabled": self.paid_enabled,
            "paid_mode": self.paid_mode,
            "key_source": self.key_source,
            "api_base": self.api_base,
            "client_version": self.client_version,
            "key_present": self.has_key,
        }


def _first_key(explicit_key: Optional[str] = None) -> tuple[str, str]:
    if explicit_key is not None:
        return str(explicit_key).strip(), "argument"
    for name in _KEY_ENV_NAMES:
        v = os.getenv(name)
        if v is not None:
            return str(v).strip(), name
    return "", "missing"


def _truthy_flag(name: str) -> Optional[bool]:
    v = os.getenv(name)
    if v is None:
        return None
    s = str(v).strip().lower()
    if s in _FALSE_VALUES:
        return False
    return True


def resolve_entitlement(
    *,
    paid_key: Optional[str] = None,
    paid_mode: Optional[str] = None,
    paid_enabled: Optional[bool] = None,
    api_base: Optional[str] = None,
    client_version: str = "0.1.13.4-runtime",
    allow_local_import: bool = False,
) -> RuntimeEntitlement:
    """Resolve runtime tier.

    The important invariant is: key missing => free.  ``paid_enabled=True`` is
    not enough by itself; a non-placeholder key must exist.
    """
    key, key_source = _first_key(paid_key)
    key_norm = key.strip().lower()

    env_enable = _truthy_flag("META13_ENABLE_PAID")
    if paid_enabled is None:
        paid_enabled = env_enable

    requested_mode = (
        paid_mode
        or os.getenv("META13_PAID_MODE")
        or os.getenv("META13_PREMIUM_MODE")
        or "lease_remote"
    )
    requested_mode = str(requested_mode).strip().lower().replace("-", "_")
    if requested_mode not in {"local_import", "lease_stub", "lease_remote", "modal_remote"}:
        requested_mode = "lease_remote"

    # v1.13.4: local_import is dev-only.  Production defaults to lease_remote.
    if requested_mode == "local_import":
        env_dev = os.getenv("META13_DEV_LOCAL_RUNTIME", "").strip().lower() in {"1", "true", "yes", "on"}
        if not (allow_local_import or env_dev):
            requested_mode = "lease_remote"

    base = api_base or os.getenv("META13_API_BASE") or "https://api.meta13.example"

    if key_norm in _FALSE_VALUES:
        return RuntimeEntitlement(
            tier="free",
            paid_enabled=False,
            paid_mode="free",
            key_source="missing" if key_source == "missing" else "disabled",
            api_base=base,
            client_version=client_version,
        )
    if key_norm in _PLACEHOLDER_VALUES:
        return RuntimeEntitlement(
            tier="free",
            paid_enabled=False,
            paid_mode="free",
            key_source="invalid_placeholder",
            api_base=base,
            client_version=client_version,
        )

    # Key exists.  Unless explicitly disabled, paid opens.
    if paid_enabled is False:
        return RuntimeEntitlement(
            tier="free",
            paid_enabled=False,
            paid_mode="free",
            key_source="disabled",
            api_base=base,
            client_version=client_version,
        )

    return RuntimeEntitlement(
        tier="paid",
        paid_enabled=True,
        paid_mode=requested_mode,
        key_source=key_source,
        api_base=base,
        client_version=client_version,
    )


__all__ = ["RuntimeEntitlement", "resolve_entitlement"]
