"""
ephemeral_blob.py — 사용 후 자동 제로화 blob 래퍼
===================================================

설계 원칙:
  - .so blob 은 호출 시에만 존재하고 사용 후 즉시 파괴
  - 소유(저장/캐시)는 구조적으로 불가능하게
  - bytes 로 꺼낼 수 없고, SoLoader 컨텍스트에서만 소비 가능
  - 크래시 시 __del__ 로 가능한 범위 내 자동 클리어

사용 예:
    # 직접 bytes 꺼내기 불가
    blob = EphemeralBlob(raw)
    raw_bytes = bytes(blob)   # ← AttributeError 발생 (의도적)

    # SoLoader 만 소비 가능
    with blob.consume("deep.obda_phi") as lib:
        result = lib.call("run", ...)
    # 이후 blob.consumed == True, 재사용 불가

DEBUG: 생성/소비/제로화 각 단계 로그 출력.
"""
from __future__ import annotations

import ctypes
import gc
import logging
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .so_loader import SoLoader

logger = logging.getLogger("meta13.ephemeral_blob")


class EphemeralBlob:
    """
    난독화 .so raw bytes 를 감싸는 일회용 컨테이너.

    - bytes() / decode() / list() 등으로 꺼낼 수 없음
    - consume() 으로 SoLoader 컨텍스트에서 1회만 소비 가능
    - 소비 또는 GC 시 내부 bytearray 제로화
    """

    __slots__ = ("_buf", "_op", "consumed", "_size")

    def __init__(self, raw: bytes, op: str = "unknown"):
        if not isinstance(raw, (bytes, bytearray)):
            raise TypeError("EphemeralBlob requires bytes")
        self._buf: bytearray = bytearray(raw)
        self._op  = op
        self._size = len(self._buf)
        self.consumed = False
        # raw 참조 즉시 해제
        del raw
        gc.collect()
        logger.debug("[ephemeral_blob] created op=%s size=%d", self._op, self._size)

    # ── 직접 꺼내기 차단 ─────────────────────────────────────────────
    def __bytes__(self):
        raise AttributeError(
            "EphemeralBlob cannot be converted to bytes directly. "
            "Use .consume(op) context manager to execute once."
        )

    def __repr__(self):
        state = "consumed" if self.consumed else f"live size={self._size}"
        return f"<EphemeralBlob op={self._op!r} {state}>"

    # ── 1회 소비 ─────────────────────────────────────────────────────
    def consume(self, op: str = None) -> "SoLoader":
        """
        SoLoader 컨텍스트 반환. 1회만 가능.
        with blob.consume("deep.obda_phi") as lib:
            lib.call("run", ...)
        """
        from .so_loader import SoLoader  # 순환 임포트 방지

        if self.consumed:
            raise RuntimeError(
                f"EphemeralBlob for op={self._op!r} already consumed. "
                "Re-fetch from server for each call."
            )
        self.consumed = True
        raw = bytes(self._buf)
        self._zero()
        logger.info("[ephemeral_blob] consumed op=%s → SoLoader", op or self._op)
        return SoLoader(op or self._op, raw, _from_ephemeral=True)

    # ── 제로화 ───────────────────────────────────────────────────────
    def _zero(self):
        """bytearray 내용을 0으로 덮어쓴 뒤 해제."""
        if self._buf:
            ctypes.memset(
                (ctypes.c_char * len(self._buf)).from_buffer(self._buf), 0, len(self._buf)
            )
            self._buf = bytearray()
            gc.collect()
            logger.debug("[ephemeral_blob] zeroed op=%s size=%d", self._op, self._size)

    def __del__(self):
        if getattr(self, "_buf", None):
            self._zero()
