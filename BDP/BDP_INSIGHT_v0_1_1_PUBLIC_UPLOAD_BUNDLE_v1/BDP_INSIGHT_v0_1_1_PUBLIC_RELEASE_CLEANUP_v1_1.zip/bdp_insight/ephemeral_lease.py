"""
ephemeral_lease.py — pay-per-call premium function lease wrapper (v0.4)
============================================================================

Purpose
-------
Premium functions are not owned by the client package and are not returned as
raw bytes. A lease is a one-shot execution handle around an EphemeralBlob.

Design constraints
------------------
- no user prompt / model state / trace / snapshot is uploaded
- no raw bytes are exposed through the public API
- every lease is single-consumption by construction
- no persistent cache path is provided
- failures carry explicit failure_reason strings for debugging

Limits
------
Python is not a trusted execution environment. A local administrator with a
kernel debugger can inspect process memory. This module prevents accidental
persistence and removes the normal raw-bytes / temp-file ownership path; it is
not a mathematical guarantee against a hostile local machine.
"""
from __future__ import annotations

import logging
import uuid
from dataclasses import dataclass, field
from typing import Any, Optional

from .ephemeral_blob import EphemeralBlob

logger = logging.getLogger("meta13.ephemeral_lease")


class LeaseConsumed(RuntimeError):
    """Raised when a one-shot premium function lease is reused."""


class LeaseMaterialAccessBlocked(AttributeError):
    """Raised when code attempts to extract raw lease material."""


@dataclass(slots=True)
class EphemeralFunctionLease:
    """
    One-shot premium function handle.

    The object intentionally does not expose `.data`, `.bytes`, `.path`, or
    `.save()` helpers. The safe path is:

        lease = client.lease_function("deep.obda_phi")
        result = lease.execute("run", ...local args...)

    or, for low-level ctypes use:

        with lease.consume() as lib:
            lib.call("run", ...)
    """

    op: str
    _blob: EphemeralBlob = field(repr=False)
    lease_id: str = field(default_factory=lambda: uuid.uuid4().hex)
    source: str = "remote_ephemeral"
    consumed: bool = False

    def __repr__(self) -> str:
        state = "consumed" if self.consumed else "ready"
        return f"<EphemeralFunctionLease op={self.op!r} id={self.lease_id[:8]} {state}>"

    # ── raw material extraction is blocked ────────────────────────────────
    def __bytes__(self) -> bytes:
        raise LeaseMaterialAccessBlocked(
            "EphemeralFunctionLease cannot be converted to bytes. "
            "Use execute() or consume() once."
        )

    def __iter__(self):
        raise LeaseMaterialAccessBlocked("EphemeralFunctionLease is not iterable.")

    def __len__(self) -> int:
        raise LeaseMaterialAccessBlocked("EphemeralFunctionLease length is intentionally hidden.")

    def __getstate__(self):
        raise LeaseMaterialAccessBlocked("EphemeralFunctionLease cannot be pickled or serialized.")

    def save(self, *_args, **_kwargs):
        raise LeaseMaterialAccessBlocked("Saving leased function material is not supported.")

    # ── one-shot consumption ───────────────────────────────────────────────
    def consume(self):
        """Return a SoLoader context manager. This can be called exactly once."""
        if self.consumed:
            raise LeaseConsumed(
                f"Lease for op={self.op!r} was already consumed. "
                "Create a new paid lease for each call."
            )
        self.consumed = True
        logger.info("[ephemeral_lease] consume op=%s lease_id=%s", self.op, self.lease_id)
        return self._blob.consume(self.op)

    def execute(self, fn_name: str = "run", *args: Any, **kwargs: Any) -> Any:
        """
        Load, call, and clear the premium function in one step.

        All arguments are local process values. They are not sent to the
        delivery endpoint by this method.
        """
        with self.consume() as lib:
            return lib.call(fn_name, *args, **kwargs)

    # alias for older code that used `with blob.consume() as lib:` style
    def open(self):
        return self.consume()
