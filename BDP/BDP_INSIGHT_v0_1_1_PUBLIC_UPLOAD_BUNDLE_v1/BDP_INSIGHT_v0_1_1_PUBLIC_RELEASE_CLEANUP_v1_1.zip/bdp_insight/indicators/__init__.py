"""BDP Insight indicators (5).

All functions take a single InterventionEvent (or list[InterventionEvent])
and return a JSON-serialisable dict with sober natural-language labels.

None of these expose raw numerical scores, weight matrices, candidate ranks,
selector internals, or canonical exact floats.  Output is always:
    - a label (e.g. "Detected", "Stale", "Reconditioned")
    - a bucket (e.g. "Low / Moderate / High")
    - optionally a small graph with edge_strength bucket only

Indicators are pure functions — no I/O, no global state.  This keeps them
testable and embeddable inside other dashboards.
"""
from __future__ import annotations

from .surgery_impact import compute_surgery_impact
from .dependency_shift import compute_dependency_shift
from .stale_reasoning import compute_stale_reasoning
from .continuation_recond import compute_continuation_recond
from .intervention_timeline import compute_intervention_timeline


__all__ = [
    "compute_surgery_impact",
    "compute_dependency_shift",
    "compute_stale_reasoning",
    "compute_continuation_recond",
    "compute_intervention_timeline",
]
