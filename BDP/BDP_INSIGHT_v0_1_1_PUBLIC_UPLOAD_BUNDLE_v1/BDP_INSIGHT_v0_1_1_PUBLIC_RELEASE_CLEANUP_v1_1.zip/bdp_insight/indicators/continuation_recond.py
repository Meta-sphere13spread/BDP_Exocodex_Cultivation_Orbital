"""Indicator 4 — Continuation Reconditioning State.

After an output intercept (e.g. L2 Hodge `output_intercept` or any other
mid-generation rewrite of a partial output), the question is:
    Did the model condition its continuation on the NEW prefix,
    or did it ignore the rewrite and keep generating as if from the OLD?

Output (always public-safe):
    {
        "label": "Continuation: Reconditioned" |
                 "Continuation: Partially reconditioned" |
                 "Continuation: Stale" |
                 "Continuation: No hit" |
                 "Continuation: Not applicable",
        "state": "Reconditioned" | "Partially reconditioned" | "Stale" |
                 "No hit" | "Not applicable",
        "note":  "<short observational sentence>",
        "evidence": {
            "edited_prefix": "<short>",
            "after_output_preview_starts_with_new_prefix": bool,
        },
        "public_safe": True,
    }

Approach:
    Two signals from the InterventionEvent:
        1. Does after_output_preview START WITH the new prefix?
           (= Yes → reached the model)
        2. Does the OLD prefix still appear in after_output?
           (= Yes → only partially reconditioned)
    Combined:
        - new_prefix at start, old not in tail → Reconditioned
        - new_prefix at start, old still in tail → Partially reconditioned
        - new_prefix not at start, old still there → Stale
        - new_prefix nowhere → No hit
        - intervention not output_intercept → Not applicable

Phrasing rule:  We never say "the output is wrong" — only whether the
continuation visibly took the rewrite into account.  Whether that is good
or bad is the user's call.
"""
from __future__ import annotations

import os
import sys
from typing import Any, Dict, Optional

from ..intervention_event import InterventionEvent


def _debug(marker: str, **kw: Any) -> None:
    if os.environ.get("BDP_INSIGHT_DEBUG", "").strip() not in ("1", "true", "yes"):
        return
    parts = [f"{k}={_short(v)}" for k, v in kw.items()]
    print(f"[BDP_INSIGHT_I4 {marker}] " + " ".join(parts), file=sys.stderr)


def _short(v: Any, limit: int = 50) -> str:
    s = repr(v)
    return s if len(s) <= limit else s[:limit] + "...]"


# ──────────────────────────────────────────────────────────────────────
# Detect "is this an output intercept?" — broad to allow custom tools
# ──────────────────────────────────────────────────────────────────────

_OUTPUT_INTERCEPT_HINTS = (
    "output_intercept",
    "output_hodge_intercept",
    "hodge_output_intercept",
    "after_tokens",
    "mid_output",
    "continuation_rewrite",
    "prefix_rewrite",
    "rewrite_prefix",
)


def _is_output_intercept_event(event: InterventionEvent) -> bool:
    """Best-effort detect.  False → indicator returns 'Not applicable'."""
    it = (event.intervention_type or "").lower()
    if any(h in it for h in _OUTPUT_INTERCEPT_HINTS):
        return True
    if event.target_kind == "output_prefix":
        return True
    return False


# ──────────────────────────────────────────────────────────────────────
# Public API
# ──────────────────────────────────────────────────────────────────────

def compute_continuation_recond(event: InterventionEvent) -> Dict[str, Any]:
    """Return a Continuation Reconditioning record for one InterventionEvent."""
    if event is None or not isinstance(event, InterventionEvent):
        _debug("compute.bad_input", t=type(event).__name__)
        return _empty(
            "Continuation: Not applicable",
            "Not applicable",
            "No intervention event available.",
        )

    if not _is_output_intercept_event(event):
        _debug("compute.not_output_intercept",
               itype=event.intervention_type, kind=event.target_kind)
        return _empty(
            "Continuation: Not applicable",
            "Not applicable",
            "Intervention is not an output intercept.",
            edited_prefix=event.after_value or "",
        )

    new_prefix = (event.after_value or "").strip()
    old_prefix = (event.before_value or "").strip()
    after_out = (event.after_output_preview or "").strip()

    if not new_prefix or not after_out:
        _debug("compute.missing_field",
               has_new_prefix=bool(new_prefix), has_after=bool(after_out))
        return _empty(
            "Continuation: No hit",
            "No hit",
            "New prefix or after-output preview is missing; cannot detect reconditioning.",
            edited_prefix=new_prefix,
        )

    after_starts_with_new = after_out.startswith(new_prefix) or (
        # 일부 토크나이저가 prefix 앞에 공백/특수토큰을 붙이는 경우 완화
        new_prefix in after_out[: len(new_prefix) + 4]
    )
    old_in_after = bool(old_prefix) and old_prefix in after_out
    new_in_after_anywhere = new_prefix in after_out

    _debug("compute.scan",
           starts_with_new=after_starts_with_new,
           old_in_after=old_in_after,
           new_anywhere=new_in_after_anywhere)

    # ── 1) 새 prefix 가 처음에 정착 + 옛 prefix 더 안 나옴 → Reconditioned
    if after_starts_with_new and not old_in_after:
        return _record(
            "Reconditioned",
            "After-output starts with the new prefix and the old prefix no longer appears.",
            edited_prefix=new_prefix,
            starts_with_new=True,
        )

    # ── 2) 새 prefix 정착 but 옛 prefix 가 후속에 또 나타남 → 부분 재조건화
    if after_starts_with_new and old_in_after:
        return _record(
            "Partially reconditioned",
            "After-output starts with the new prefix but still references the old prefix later.",
            edited_prefix=new_prefix,
            starts_with_new=True,
        )

    # ── 3) 새 prefix 가 어디든 등장하지만 시작 아님 → Stale
    if new_in_after_anywhere and old_in_after:
        return _record(
            "Stale",
            "Old prefix still anchors the continuation; new prefix appears only mid-text.",
            edited_prefix=new_prefix,
            starts_with_new=False,
        )

    # ── 4) 새 prefix 가 등장은 함 but 옛은 안 나옴, 시작도 아님 → 약 Stale
    if new_in_after_anywhere and not old_in_after:
        return _record(
            "Partially reconditioned",
            "New prefix appears in the continuation but does not anchor the start.",
            edited_prefix=new_prefix,
            starts_with_new=False,
        )

    # ── 5) 새 prefix 가 아예 없음 → No hit
    return _record(
        "No hit",
        "New prefix is not visible in the after-output preview.",
        edited_prefix=new_prefix,
        starts_with_new=False,
    )


# ──────────────────────────────────────────────────────────────────────
# Output helpers
# ──────────────────────────────────────────────────────────────────────

def _record(
    state: str,
    note: str,
    *,
    edited_prefix: str,
    starts_with_new: bool,
) -> Dict[str, Any]:
    return {
        "label": f"Continuation: {state}",
        "state": state,
        "note": note,
        "evidence": {
            "edited_prefix": edited_prefix[:80],
            "after_output_preview_starts_with_new_prefix": starts_with_new,
        },
        "public_safe": True,
    }


def _empty(
    label: str,
    state: str,
    note: str,
    *,
    edited_prefix: str = "",
) -> Dict[str, Any]:
    return {
        "label": label,
        "state": state,
        "note": note,
        "evidence": {
            "edited_prefix": edited_prefix[:80],
            "after_output_preview_starts_with_new_prefix": False,
        },
        "public_safe": True,
    }
