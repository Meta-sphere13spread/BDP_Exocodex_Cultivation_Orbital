"""Indicator 2 — Token Dependency Shift Graph.

Compares the before/after token chains of an InterventionEvent and produces
a small graph that says, in plain English, whether the dependency between
tokens shifted, where the anchor changed, and how reliable the resulting
path looks.

This is OBSERVATIONAL.  We do not claim "the model used token X to produce
Y".  We say "the token chain that produced Y now starts from a different
anchor than before".

Output (always public-safe):
    {
        "label":          "Dependency shifted at 'mat' → 'chair'",
        "shift":          "Detected" | "Not detected",
        "changed_anchor": "<short>",
        "result_path":    "Recomputed" | "Partially stale" | "Unstable" | "Unknown",
        "graph": {
            "nodes": [{"id", "label", "side": "before"|"after"|"common"}, ...],
            "edges": [{"src", "dst", "strength_bucket": "weak"|"moderate"|"strong"}, ...]
        },
        "note": "...",
        "public_safe": True,
    }

Tokenisation note (prototype):
    We use a simple word/punctuation regex split.  This is intentional —
    the indicator is meant to read **string-level** drift in a way that is
    consistent across tokenizers (BPE / SentencePiece / WordPiece).  It is
    NOT a substitute for the model's true subword tokens.  When integrating
    with a real tokenizer (Phase 2 attach), the caller can override
    `tokenize_fn` to feed actual model tokens.
"""
from __future__ import annotations

import os
import re
import sys
from typing import Any, Callable, Dict, List, Optional, Sequence

from ..intervention_event import InterventionEvent


# ──────────────────────────────────────────────────────────────────────
# Debug
# ──────────────────────────────────────────────────────────────────────

def _debug(marker: str, **kw: Any) -> None:
    if os.environ.get("BDP_INSIGHT_DEBUG", "").strip() not in ("1", "true", "yes"):
        return
    parts = [f"{k}={_short(v)}" for k, v in kw.items()]
    print(f"[BDP_INSIGHT_I2 {marker}] " + " ".join(parts), file=sys.stderr)


def _short(v: Any, limit: int = 50) -> str:
    s = repr(v)
    return s if len(s) <= limit else s[:limit] + "...]"


# ──────────────────────────────────────────────────────────────────────
# Default tokeniser (string-level, tokenizer-agnostic)
# ──────────────────────────────────────────────────────────────────────

# 단어 + 숫자 + 부호로 분리 (한글/영문/숫자/$op_chars 모두 보존)
_DEFAULT_TOKEN_RE = re.compile(r"\w+|[^\w\s]", flags=re.UNICODE)


def _default_tokenize(text: str) -> List[str]:
    if not text:
        return []
    return _DEFAULT_TOKEN_RE.findall(text)


# ──────────────────────────────────────────────────────────────────────
# Diff — minimal LCS-style anchor finder (no external dep)
# ──────────────────────────────────────────────────────────────────────

def _find_first_diff_index(a: Sequence[str], b: Sequence[str]) -> int:
    """Return the first index at which a and b differ.  -1 if identical."""
    n = min(len(a), len(b))
    for i in range(n):
        if a[i] != b[i]:
            return i
    if len(a) != len(b):
        return n
    return -1


def _find_last_common_index(a: Sequence[str], b: Sequence[str]) -> int:
    """Return the largest k such that a[-k:] == b[-k:].  0 if no common tail."""
    k = 0
    la, lb = len(a), len(b)
    while k < la and k < lb and a[-(k + 1)] == b[-(k + 1)]:
        k += 1
    return k


def _classify_result_path(
    before_tokens: Sequence[str],
    after_tokens: Sequence[str],
    diff_start: int,
) -> str:
    """How clean is the after-chain?

    - Recomputed:      after diverges sharply, no shared tail with before
    - Partially stale: after eventually converges back to before's tail
    - Unstable:        after has multiple disjoint segments
    - Unknown:         not enough signal
    """
    if not before_tokens or not after_tokens:
        _debug("result_path.empty_chain")
        return "Unknown"
    if diff_start < 0:
        _debug("result_path.identical")
        return "Recomputed"  # 같으면 사실상 변화 없는 거지만 stable 한 path
    common_tail = _find_last_common_index(
        before_tokens[diff_start:], after_tokens[diff_start:]
    )
    after_len = len(after_tokens) - diff_start
    if after_len <= 0:
        _debug("result_path.no_after_after_diff")
        return "Unknown"
    tail_ratio = common_tail / float(after_len)
    if tail_ratio >= 0.6:
        _debug("result_path.high_tail_overlap", bucket="≥0.6")
        return "Partially stale"
    if tail_ratio >= 0.2:
        _debug("result_path.partial_tail_overlap", bucket="0.2~0.6")
        return "Partially stale"
    if len(after_tokens) > 0 and len(before_tokens) > 0:
        # 후속이 완전히 새로 짜였으면 Recomputed
        _debug("result_path.low_tail_overlap", bucket="<0.2")
        return "Recomputed"
    _debug("result_path.unknown_fallback")
    return "Unknown"


# ──────────────────────────────────────────────────────────────────────
# Strength bucket (count-based, no weights)
# ──────────────────────────────────────────────────────────────────────

def _strength_bucket(count: int) -> str:
    if count >= 5:
        return "strong"
    if count >= 2:
        return "moderate"
    return "weak"


# ──────────────────────────────────────────────────────────────────────
# Graph builder
# ──────────────────────────────────────────────────────────────────────

def _build_graph(
    before_tokens: Sequence[str],
    after_tokens: Sequence[str],
    diff_start: int,
    max_nodes: int = 20,
) -> Dict[str, Any]:
    """Tiny graph: common prefix + diverging branches + (optional) common tail.

    Capped at max_nodes to keep dashboard rendering cheap.  Strength is a
    coarse bucket only — never an exact weight.
    """
    nodes: List[Dict[str, Any]] = []
    edges: List[Dict[str, Any]] = []
    seen_ids: set = set()

    def _add_node(node_id: str, label: str, side: str) -> None:
        if node_id in seen_ids:
            return
        if len(nodes) >= max_nodes:
            return
        seen_ids.add(node_id)
        nodes.append({"id": node_id, "label": label[:40], "side": side})

    # Common prefix
    common_prefix_n = max(0, diff_start) if diff_start > 0 else 0
    prev_id: Optional[str] = None
    for i in range(common_prefix_n):
        nid = f"c{i}"
        _add_node(nid, before_tokens[i], "common")
        if prev_id is not None:
            edges.append({
                "src": prev_id, "dst": nid,
                "strength_bucket": _strength_bucket(common_prefix_n),
            })
        prev_id = nid

    # Branch — before
    branch_before_root = prev_id
    branch_before_count = max(0, len(before_tokens) - common_prefix_n)
    prev_b = branch_before_root
    for i in range(min(branch_before_count, max_nodes // 2)):
        nid = f"b{i}"
        _add_node(nid, before_tokens[common_prefix_n + i], "before")
        if prev_b is not None:
            edges.append({
                "src": prev_b, "dst": nid,
                "strength_bucket": _strength_bucket(branch_before_count),
            })
        prev_b = nid

    # Branch — after
    branch_after_root = branch_before_root
    branch_after_count = max(0, len(after_tokens) - common_prefix_n)
    prev_a = branch_after_root
    for i in range(min(branch_after_count, max_nodes // 2)):
        nid = f"a{i}"
        _add_node(nid, after_tokens[common_prefix_n + i], "after")
        if prev_a is not None:
            edges.append({
                "src": prev_a, "dst": nid,
                "strength_bucket": _strength_bucket(branch_after_count),
            })
        prev_a = nid

    _debug("graph.built", n_nodes=len(nodes), n_edges=len(edges))
    return {"nodes": nodes, "edges": edges}


# ──────────────────────────────────────────────────────────────────────
# Public API
# ──────────────────────────────────────────────────────────────────────

def compute_dependency_shift(
    event: InterventionEvent,
    *,
    tokenize_fn: Optional[Callable[[str], List[str]]] = None,
) -> Dict[str, Any]:
    """Return a Token Dependency Shift record for one InterventionEvent.

    Args:
        event: A single InterventionEvent.
        tokenize_fn: Optional override for the string tokeniser.  Phase 2
            (attach) can pass the real model's tokenizer here so the graph
            uses BPE/SP units instead of the simple regex.
    """
    if event is None or not isinstance(event, InterventionEvent):
        _debug("compute.bad_input", t=type(event).__name__)
        return {
            "label": "no event",
            "shift": "Not detected",
            "changed_anchor": "",
            "result_path": "Unknown",
            "graph": {"nodes": [], "edges": []},
            "note": "No intervention event available.",
            "public_safe": True,
        }

    before_text = event.before_output_preview or event.before_value or ""
    after_text = event.after_output_preview or event.after_value or ""
    tok = tokenize_fn or _default_tokenize

    try:
        before_tokens = tok(before_text)
        after_tokens = tok(after_text)
    except Exception as exc:
        _debug("compute.tokenize_failed", err=type(exc).__name__)
        return {
            "label": "tokenization failed",
            "shift": "Not detected",
            "changed_anchor": "",
            "result_path": "Unknown",
            "graph": {"nodes": [], "edges": []},
            "note": "Could not tokenise the before/after preview.",
            "public_safe": True,
        }

    diff_start = _find_first_diff_index(before_tokens, after_tokens)
    if diff_start < 0:
        # Token chain identical at preview level — but the InterventionEvent
        # itself may still have changed an anchor (e.g. before_value/after_value
        # differ even though the previewed continuation is the same).
        anchor = ""
        if event.before_value and event.after_value and event.before_value != event.after_value:
            anchor = f"{event.before_value} → {event.after_value}"
            shift = "Detected"
            note = "Anchor edited but visible continuation looks unchanged."
        else:
            shift = "Not detected"
            note = "Before/after token chains are identical at preview level."
        graph = _build_graph(before_tokens, after_tokens, len(before_tokens))
        _debug("compute.no_diff", anchor=anchor)
        return {
            "label": (
                "Dependency: unchanged"
                if shift == "Not detected"
                else f"Anchor edit: {anchor}"
            ),
            "shift": shift,
            "changed_anchor": anchor,
            "result_path": "Recomputed" if shift == "Not detected" else "Partially stale",
            "graph": graph,
            "note": note,
            "public_safe": True,
        }

    changed_before = before_tokens[diff_start] if diff_start < len(before_tokens) else ""
    changed_after = after_tokens[diff_start] if diff_start < len(after_tokens) else ""
    changed_anchor = f"{changed_before} → {changed_after}".strip(" →")

    result_path = _classify_result_path(before_tokens, after_tokens, diff_start)
    graph = _build_graph(before_tokens, after_tokens, diff_start)

    label = f"Dependency shifted at '{changed_before}' → '{changed_after}'"
    if event.intervention_type:
        label = f"{event.intervention_type}: {label}"

    note_map = {
        "Recomputed": "After-chain looks freshly computed from the new anchor.",
        "Partially stale": "After-chain partially returns to the previous tail — recompute may be incomplete.",
        "Unstable": "After-chain diverges without a stable shape.",
        "Unknown": "Not enough preview text to judge the after-chain.",
    }

    out = {
        "label": label,
        "shift": "Detected",
        "changed_anchor": changed_anchor,
        "result_path": result_path,
        "graph": graph,
        "note": note_map.get(result_path, ""),
        "public_safe": True,
    }
    _debug("compute.ok",
           shift="Detected", anchor=changed_anchor, result_path=result_path)
    return out
