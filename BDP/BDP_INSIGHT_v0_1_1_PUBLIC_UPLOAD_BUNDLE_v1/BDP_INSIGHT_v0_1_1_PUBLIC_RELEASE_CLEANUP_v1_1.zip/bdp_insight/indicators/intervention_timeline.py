"""Indicator 5 — Intervention Timeline.

Reads a list of InterventionEvents (or already-normalised dicts) and
returns an ordered timeline that the dashboard / studio can render as a
horizontal track of dots.

This is the SIMPLEST of the five indicators — no inference, just sorted
projection — but it is also the most useful for live demos because it
shows "what happened, when, and was it actually applied".

Output (always public-safe):
    {
        "label":   "Timeline: 4 events, last 'L2 HodgeConverter' applied 3s ago",
        "items": [
            {
                "ts":          1714668000.0,
                "ago_sec":     12,
                "family":      "L1" | "L2" | "L3" | "L4" | "external" | "unknown",
                "status":      "applied" | "noop" | "blocked" | "queued" |
                              "blocked_late" | "cleared" | "unknown",
                "kind_label":  "L2 HodgeConverter" | "Prompt rewrite" |
                              "External activation patch" | ...,
                "source_tool": "...",
                "before":      "<short>",
                "after":       "<short>",
                "actual_model_event": bool,
            },
            ...
        ],
        "newest": <items[0] | None>,
        "summary": {
            "n_total": int,
            "n_applied": int,
            "n_blocked": int,
            "by_family": {"L1": n, "L2": n, ...},
        },
        "public_safe": True,
    }

Cherry-picked from v1.13.4 dashboard_min._classify_family /
_classify_status / _build_last_surgery_summary patterns.
"""
from __future__ import annotations

import os
import sys
import time
from typing import Any, Dict, Iterable, List, Optional, Sequence, Union

from ..intervention_event import InterventionEvent, normalize_event


# ──────────────────────────────────────────────────────────────────────
# Debug
# ──────────────────────────────────────────────────────────────────────

def _debug(marker: str, **kw: Any) -> None:
    if os.environ.get("BDP_INSIGHT_DEBUG", "").strip() not in ("1", "true", "yes"):
        return
    parts = [f"{k}={_short(v)}" for k, v in kw.items()]
    print(f"[BDP_INSIGHT_I5 {marker}] " + " ".join(parts), file=sys.stderr)


def _short(v: Any, limit: int = 50) -> str:
    s = repr(v)
    return s if len(s) <= limit else s[:limit] + "...]"


# ──────────────────────────────────────────────────────────────────────
# Family / kind label mapping (cherry-picked from v1.13.4)
# ──────────────────────────────────────────────────────────────────────

_FAMILY_BY_TYPE_FRAGMENT = (
    ("rewrite_prompt", "L1"),
    ("l1_mid", "L1"),
    ("prompt_rewrite", "L1"),
        ("hodge_auto", "L2"),
    ("hodge_token", "L2"),
    ("hodge_output", "L2"),
    ("output_intercept", "L2"),
    ("embed_perturb", "L3"),
    ("embed_replace", "L3"),
    ("embedding", "L3"),
    ("residual_edit", "L3"),
    ("residual_patch", "L3"),
    ("activation_patch", "L3"),
    ("graft", "L4"),
    ("inject_graft", "L4"),
    ("edit_leaf", "L4"),
)

# 외부 도구는 'external' 로 묶음
_EXTERNAL_SOURCE_FRAGMENTS = (
    "nnsight", "transformerlens", "captum", "lit_", "bertviz",
    "tensorboard", "external",
)


def _classify_family(event: InterventionEvent) -> str:
    """Map to L1 / L2 / L3 / L4 / external / unknown."""
    src = (event.source_tool or "").lower()
    if any(frag in src for frag in _EXTERNAL_SOURCE_FRAGMENTS):
        return "external"
    it = (event.intervention_type or "").lower()
    for frag, fam in _FAMILY_BY_TYPE_FRAGMENT:
        if frag in it:
            return fam
    # target_kind 으로 폴백
    tk = event.target_kind or ""
    if tk == "prompt":
        return "L1"
    if tk == "token":
        return "L2"
    if tk in ("embedding", "residual", "layer", "head", "mlp", "attention"):
        return "L3"
    return "unknown"


def _kind_label(family: str, event: InterventionEvent) -> str:
    """Sober English short label for the timeline dot."""
    src = event.source_tool or ""
    it = event.intervention_type or ""
    if family == "external":
        # "External activation patch (nnsight)"
        return f"External {it or 'edit'} ({src or 'unknown'})"
    if family == "L1":
        return "L1 Prompt Rewrite"
    if family == "L2":
        if "hodge" in it.lower():
            return "L2 Hodge Auto Surgery"
        if "output" in it.lower():
            return "L2 Output Intercept"
        return "L2 HodgeConverter"
    if family == "L3":
        return "L3 Embedding Perturb"
    if family == "L4":
        return "L4 Graft (preview)"
    return "Unknown intervention"


# ──────────────────────────────────────────────────────────────────────
# Public API
# ──────────────────────────────────────────────────────────────────────

EventLike = Union[InterventionEvent, Dict[str, Any]]


def _coerce_event(e: EventLike) -> Optional[InterventionEvent]:
    if isinstance(e, InterventionEvent):
        return e
    if isinstance(e, dict):
        try:
            return normalize_event(e)
        except Exception as exc:
            _debug("coerce.normalize_failed", err=type(exc).__name__)
            return None
    _debug("coerce.unsupported_type", t=type(e).__name__)
    return None


def compute_intervention_timeline(
    events: Sequence[EventLike],
    *,
    now: Optional[float] = None,
    max_items: int = 50,
) -> Dict[str, Any]:
    """Project a list of intervention events into a sorted timeline."""
    if events is None:
        events = []
    items: List[Dict[str, Any]] = []
    by_family: Dict[str, int] = {}
    n_applied = 0
    n_blocked = 0
    now_ts = float(now) if now is not None else time.time()

    coerced: List[InterventionEvent] = []
    for e in events:
        ev = _coerce_event(e)
        if ev is not None:
            coerced.append(ev)

    _debug("compute.received", n_in=len(events), n_coerced=len(coerced))

    # 시간 내림차순 (최신 먼저)
    coerced.sort(key=lambda x: x.ts, reverse=True)
    coerced = coerced[:max_items]

    for ev in coerced:
        family = _classify_family(ev)
        kind_label = _kind_label(family, ev)
        ago = max(0, int(now_ts - ev.ts)) if ev.ts > 0 else None

        items.append({
            "ts": ev.ts,
            "ago_sec": ago,
            "family": family,
            "status": ev.status,
            "kind_label": kind_label,
            "source_tool": ev.source_tool or "",
            "before": (ev.before_value or "")[:60],
            "after": (ev.after_value or "")[:60],
            "actual_model_event": bool(ev.actual_model_event),
        })

        by_family[family] = by_family.get(family, 0) + 1
        if ev.status == "applied":
            n_applied += 1
        elif ev.status in ("blocked", "blocked_late"):
            n_blocked += 1

    summary = {
        "n_total": len(items),
        "n_applied": n_applied,
        "n_blocked": n_blocked,
        "by_family": by_family,
    }

    newest = items[0] if items else None
    if newest is None:
        label = "Timeline: empty"
    else:
        ago = newest.get("ago_sec")
        ago_str = (
            f"{ago}s ago" if ago is not None and ago < 60
            else (f"{ago // 60}m ago" if ago is not None else "")
        )
        label = (
            f"Timeline: {len(items)} events, last "
            f"'{newest['kind_label']}' {newest['status']} {ago_str}".strip()
        )

    out = {
        "label": label,
        "items": items,
        "newest": newest,
        "summary": summary,
        "public_safe": True,
    }
    _debug("compute.ok", n=len(items), applied=n_applied, blocked=n_blocked)
    return out
