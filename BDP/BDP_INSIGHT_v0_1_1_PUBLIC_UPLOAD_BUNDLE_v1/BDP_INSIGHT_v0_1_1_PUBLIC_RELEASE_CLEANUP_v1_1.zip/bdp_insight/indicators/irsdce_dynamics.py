"""IRS-DCE / Phase Stagnation dynamics indicators.

Ported from the user's published research code:

    - PR_s.py            (CPI / EDS / CDI / AGA / BCI suite)
    - IRS-DCE_AUC.py     (omega / work / ID / PC1r profiles + AUC)

These are research artefacts the user has already published — they are
intentionally PUBLIC-FREE per the 2026-05-03 policy decision.  Only the
dynamic intervention algorithms (L2/L3 surgery) remain paid.

What this module does NOT contain:
    - model loading / hidden-state extraction (`extract_from_model`).
      That belongs in M13's capture pipeline; we only consume capture
      output here.
    - matplotlib / 3D plotting.  Plot-side code lives in
      `bdp_insight/studio/tabs/tab_irsdce_dynamics.py` so this module
      stays numpy-only and unit-testable without GUI deps.

What this module DOES contain:
    13 measurement functions matching PR_s / IRS-DCE_AUC line-by-line
    behaviour, plus an `analyze_capture_run(run_dir)` wrapper that reads
    a M13 capture run's `result_minimal.json["hidden_states_per_layer"]`
    and produces the full IRS-DCE dynamics report dict.

Public-safe contract:
    All scalar outputs (CPI / CDI / BCI / AGA peak / Δ_ID / AUC / etc.)
    are research metrics already published.  No paid algorithm leaks
    through this module.

Debug markers (BDP_INSIGHT_DEBUG=1):
    [BDP_INSIGHT_IRSDCE ...]   compute, analyze, no_data
"""
from __future__ import annotations

import os
import sys
from typing import Any, Dict, List, Optional, Tuple

import numpy as np


EPS = 1e-12
SKIP = 4   # skip first SKIP layers when looking for spike/valley (matches PR_s default)


# ──────────────────────────────────────────────────────────────────────
# Debug
# ──────────────────────────────────────────────────────────────────────

def _debug(marker: str, **kw: Any) -> None:
    if os.environ.get("BDP_INSIGHT_DEBUG", "").strip() not in ("1", "true", "yes"):
        return
    parts = [f"{k}={v!r}" for k, v in kw.items()]
    print(f"[BDP_INSIGHT_IRSDCE {marker}] " + " ".join(parts), file=sys.stderr)


# ══════════════════════════════════════════════════════════════════════
# Section 1 — primitive geometry (shared by PR_s and IRS-DCE_AUC)
# ══════════════════════════════════════════════════════════════════════

def pca_eigvals(X: np.ndarray) -> np.ndarray:
    """Eigenvalues of (X X^T) / (n-1).  Matches PR_s/IRS-DCE behaviour."""
    X = np.asarray(X, dtype=np.float64)
    n = max(1, X.shape[0] - 1)
    G = (X @ X.T) / n
    eig = np.linalg.eigvalsh(G)[::-1]
    eig[eig < 0.0] = 0.0
    return eig


def participation_ratio(eigvals: np.ndarray, eps: float = EPS) -> float:
    """ID (Intrinsic Dimension) = (Σλ)² / Σλ².  Matches PR_s/IRS-DCE."""
    s1 = np.sum(eigvals) + eps
    s2 = np.sum(eigvals ** 2) + eps
    return float((s1 * s1) / s2)


def stringiness_pc1_ratio(X: np.ndarray) -> float:
    """PC1 ratio = λ1 / Σλ.  PR_s/IRS-DCE alias for 'PC1r'."""
    Xc = X - X.mean(axis=0, keepdims=True)
    eig = pca_eigvals(Xc)
    if eig.size == 0:
        return float("nan")
    return float(eig[0] / (np.sum(eig) + EPS))


def omega_tensor(v_prev: np.ndarray, v_cur: np.ndarray, eps: float = EPS) -> float:
    """Ω(v_prev → v_cur) = ||v_cur ⊥ v_prev|| / ||v_prev||."""
    p = (np.dot(v_cur, v_prev) / (np.dot(v_prev, v_prev) + eps)) * v_prev
    ortho = v_cur - p
    return float(np.linalg.norm(ortho) / (np.linalg.norm(v_prev) + eps))


def work_from_omegas(omegas: np.ndarray, gamma: float = 1.0) -> np.ndarray:
    """Cumulative work along trajectory: cumsum(log1p(γ · max(0, Ω)))."""
    return np.cumsum(np.log1p(gamma * np.maximum(0.0, np.asarray(omegas))))


# ══════════════════════════════════════════════════════════════════════
# Section 2 — per-layer profile extractor (shared input shape: list of
# token-by-token activation matrices, one per layer)
# ══════════════════════════════════════════════════════════════════════

def get_id_pc1_omega_profiles(
    A_case: List[np.ndarray],
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Return (ID, PC1r, Ω) per layer for one case.

    A_case: list of activation arrays, one per layer.  Each is shape
            (n_tokens, hidden_dim).
    """
    L = len(A_case)
    id_p = np.zeros(L)
    pc1_p = np.zeros(L)
    omega = np.zeros(L)
    for l, X in enumerate(A_case):
        Xc = X - X.mean(axis=0, keepdims=True)
        eig = pca_eigvals(Xc)
        id_p[l]  = participation_ratio(eig)
        pc1_p[l] = stringiness_pc1_ratio(X)
        if l == 0:
            omega[l] = 0.0
        else:
            v_prev = X[-1] if X.shape[0] > 0 else np.zeros(X.shape[-1])
            v_cur_arr = A_case[l-1]
            v_cur = v_cur_arr[-1] if v_cur_arr.shape[0] > 0 else np.zeros(v_cur_arr.shape[-1])
            omega[l] = omega_tensor(v_cur, v_prev)
    return id_p, pc1_p, omega


def find_spike_layer(id_p: np.ndarray, skip: int = SKIP) -> int:
    """Layer of max ID after skipping first `skip` layers."""
    if id_p.size <= skip:
        return int(np.argmax(id_p))
    return int(np.argmax(id_p[skip:]) + skip)


def find_valley_layer(id_p: np.ndarray, skip: int = SKIP) -> int:
    """Layer of min ID after skipping first `skip` layers."""
    if id_p.size <= skip:
        return int(np.argmin(id_p))
    return int(np.argmin(id_p[skip:]) + skip)


# ══════════════════════════════════════════════════════════════════════
# Section 3 — Phase Stagnation case-level metrics (PR_s)
# ══════════════════════════════════════════════════════════════════════

def compute_local_density(
    id_p: np.ndarray,
    pc1_p: np.ndarray,
    radius_frac: float = 0.15,
) -> np.ndarray:
    """Per-layer local point-cloud density in (ID, PC1r) space."""
    pts = np.stack([id_p, pc1_p], axis=1)
    L = pts.shape[0]
    # bounding box-relative radius
    span = max(np.ptp(pts[:, 0]), np.ptp(pts[:, 1]), EPS)
    r = span * radius_frac
    out = np.zeros(L)
    for i in range(L):
        d = np.linalg.norm(pts - pts[i], axis=1)
        out[i] = float(np.sum(d < r) - 1)  # exclude self
    # normalise
    if out.max() > 0:
        out = out / out.max()
    return out


def compute_orbital_score(id_p: np.ndarray, pc1_p: np.ndarray) -> np.ndarray:
    """Per-layer orbital score = curvature × reversal count.

    A simplified implementation matching PR_s's published intent:
    layers with high curvature AND nearby reversals score high.
    """
    L = len(id_p)
    if L < 3:
        return np.zeros(L)
    pts = np.stack([id_p, pc1_p], axis=1)
    # Discrete curvature ~ angle between consecutive segments
    out = np.zeros(L)
    for i in range(1, L - 1):
        v1 = pts[i] - pts[i-1]
        v2 = pts[i+1] - pts[i]
        n1 = np.linalg.norm(v1) + EPS
        n2 = np.linalg.norm(v2) + EPS
        cos = np.clip(np.dot(v1, v2) / (n1 * n2), -1.0, 1.0)
        # turn intensity: 1 - cos ∈ [0, 2]
        out[i] = (1.0 - cos) / 2.0
    if out.max() > 0:
        out = out / out.max()
    return out


def compute_aga(
    density: np.ndarray,
    orbital: np.ndarray,
    omega: np.ndarray,
) -> np.ndarray:
    """AGA = Density × Orbital × Ω, normalised to [0, 1]."""
    raw = density * orbital * omega
    if raw.max() > 0:
        raw = raw / raw.max()
    return raw


def compute_cpi(aga: np.ndarray, threshold: float = 0.35) -> Dict[str, Any]:
    """CPI — longest run of layers with AGA > threshold, normalised by L."""
    L = len(aga)
    if L == 0:
        return {"cpi": 0.0, "longest_run": 0, "L": 0, "start": None, "end": None}
    above = aga > threshold
    longest = 0
    cur = 0
    best_start = -1
    best_end = -1
    cur_start = -1
    for i, ok in enumerate(above):
        if ok:
            if cur == 0:
                cur_start = i
            cur += 1
            if cur > longest:
                longest = cur
                best_start = cur_start
                best_end = i
        else:
            cur = 0
    return {
        "cpi": float(longest / L),
        "longest_run": int(longest),
        "L": int(L),
        "start": int(best_start) if best_start >= 0 else None,
        "end":   int(best_end) if best_end >= 0 else None,
    }


def compute_eds_profile(id_p: np.ndarray, pc1_p: np.ndarray) -> np.ndarray:
    """EDS[l] = ΔID[l] × (−ΔPC1r[l]).  Per-layer escape direction score."""
    delta_id = np.diff(id_p, prepend=id_p[0] if id_p.size else 0.0)
    delta_pc1 = np.diff(pc1_p, prepend=pc1_p[0] if pc1_p.size else 0.0)
    return delta_id * (-delta_pc1)


def eds_window_mean(eds_profile: np.ndarray, start: int, end: int) -> float:
    """Mean EDS in [start, end] (inclusive)."""
    if eds_profile.size == 0 or start is None or end is None:
        return 0.0
    s = max(0, int(start))
    e = min(eds_profile.size - 1, int(end))
    if s > e:
        return 0.0
    return float(np.mean(eds_profile[s:e+1]))


def compute_cdi(
    aga: np.ndarray,
    id_p: np.ndarray,
    pc1_p: np.ndarray,
    omega: np.ndarray,
    threshold: float = 0.35,
    post_win: int = 5,
) -> Dict[str, Any]:
    """CDI = Contradiction Dissolution Index.

    Verifies the canonical IRS-DCE order:
       CPI_start  → Ω_peak  → EDS > 0 (post-spike)

    If the order holds, CDI = CPI × EDS_post_spike.  Otherwise CDI = 0.
    """
    cpi_info = compute_cpi(aga, threshold=threshold)
    if cpi_info["start"] is None:
        return {"cdi": 0.0, "order_ok": False, "reason": "no CPI run",
                **cpi_info}

    cpi_start = cpi_info["start"]
    omega_peak = int(np.argmax(omega)) if omega.size else -1
    spike = find_spike_layer(id_p)

    # Order check: cpi_start ≤ omega_peak ≤ spike  (allow ties)
    order_ok = (cpi_start <= omega_peak <= spike)
    if not order_ok:
        return {"cdi": 0.0, "order_ok": False,
                "reason": f"order broken: cpi_start={cpi_start}, "
                          f"ω_peak={omega_peak}, spike={spike}",
                "cpi_start": int(cpi_start),
                "omega_peak": int(omega_peak),
                "spike_layer": int(spike),
                **{k: v for k, v in cpi_info.items() if k != "cpi"}}

    eds = compute_eds_profile(id_p, pc1_p)
    eds_post = eds_window_mean(eds, spike, min(spike + post_win, len(eds) - 1))
    cdi_val = cpi_info["cpi"] * max(0.0, eds_post)

    return {
        "cdi": float(cdi_val),
        "order_ok": True,
        "cpi": float(cpi_info["cpi"]),
        "eds_post_spike": float(eds_post),
        "cpi_start": int(cpi_start),
        "omega_peak": int(omega_peak),
        "spike_layer": int(spike),
    }


# ══════════════════════════════════════════════════════════════════════
# Section 4 — Batch Coherence Index (BCI) — PR_s
# ══════════════════════════════════════════════════════════════════════

def compute_bci_circle(
    all_id_flat: np.ndarray,
    all_pc1_flat: np.ndarray,
) -> Dict[str, Any]:
    """BCI_circle — how tightly the (ID, PC1r) cloud aligns to a 1/4 circle."""
    id_arr = np.asarray(all_id_flat, dtype=np.float64)
    pc1_arr = np.asarray(all_pc1_flat, dtype=np.float64)
    if id_arr.size == 0 or pc1_arr.size == 0:
        return {"bci_circle": 0.0, "n": 0, "cv_r": float("inf")}
    # Normalise both to [0, 1]
    id_n = (id_arr - id_arr.min()) / (np.ptp(id_arr) + EPS)
    pc1_n = (pc1_arr - pc1_arr.min()) / (np.ptp(pc1_arr) + EPS)
    # Distance from the (1, 1) corner
    dx = id_n - 1.0
    dy = pc1_n - 1.0
    r = np.sqrt(dx * dx + dy * dy)
    if r.mean() < EPS:
        return {"bci_circle": 1.0, "n": int(id_arr.size), "cv_r": 0.0}
    cv = float(r.std() / (r.mean() + EPS))
    bci = 1.0 / (1.0 + cv)
    return {"bci_circle": float(bci), "n": int(id_arr.size), "cv_r": cv}


def _entropy_curve(x: np.ndarray, a: float, b: float, c: float) -> np.ndarray:
    """f(x) = a · x · ln(x) + b · x + c."""
    x_safe = np.clip(np.asarray(x), EPS, None)
    return a * x_safe * np.log(x_safe) + b * x_safe + c


def compute_bci_entropy(
    all_id_flat: np.ndarray,
    all_pc1_flat: np.ndarray,
    n_null: int = 100,
) -> Dict[str, Any]:
    """BCI_entropy — R² of f(x) = ax·ln(x) + bx + c fit, with null-shuffle p-value."""
    from scipy.optimize import curve_fit  # lazy import — scipy is optional

    id_arr = np.asarray(all_id_flat, dtype=np.float64)
    pc1_arr = np.asarray(all_pc1_flat, dtype=np.float64)
    if id_arr.size < 5:
        return {"r2": 0.0, "p_value": 1.0, "n": int(id_arr.size),
                "params": None, "note": "too few points"}

    # Sort by id to get x→y mapping
    order = np.argsort(id_arr)
    x = id_arr[order]
    y = pc1_arr[order]
    try:
        popt, _ = curve_fit(_entropy_curve, x, y, p0=[1.0, 0.0, 0.0],
                            maxfev=2000)
        y_pred = _entropy_curve(x, *popt)
        ss_res = np.sum((y - y_pred) ** 2)
        ss_tot = np.sum((y - y.mean()) ** 2) + EPS
        r2 = float(1.0 - ss_res / ss_tot)
    except Exception as exc:
        _debug("bci_entropy.fit_failed", err=type(exc).__name__)
        return {"r2": 0.0, "p_value": 1.0, "n": int(id_arr.size),
                "params": None, "note": "fit failed"}

    # Null-shuffle p-value
    n_better = 0
    for _ in range(int(n_null)):
        y_shuf = np.random.permutation(y)
        try:
            popt_n, _ = curve_fit(_entropy_curve, x, y_shuf,
                                  p0=[1.0, 0.0, 0.0], maxfev=2000)
            y_pred_n = _entropy_curve(x, *popt_n)
            r2_n = 1.0 - np.sum((y_shuf - y_pred_n) ** 2) / (
                np.sum((y_shuf - y_shuf.mean()) ** 2) + EPS
            )
            if r2_n >= r2:
                n_better += 1
        except Exception:
            n_better += 1   # conservative
    p_value = float((n_better + 1) / (n_null + 1))

    return {
        "r2":      float(r2),
        "p_value": p_value,
        "n":       int(id_arr.size),
        "params":  {"a": float(popt[0]), "b": float(popt[1]), "c": float(popt[2])},
        "significant": bool(p_value < 0.05),
    }


# ══════════════════════════════════════════════════════════════════════
# Section 5 — IRS-DCE AUC (relative dimension jump area)
# ══════════════════════════════════════════════════════════════════════

def analyze_case(
    A_case: List[np.ndarray],
    *,
    gamma: float = 1.0,
) -> Dict[str, Any]:
    """One-case full IRS-DCE analysis.

    Ports `analyze_case` from IRS-DCE_AUC.py.

    Returns: ID/PC1r/Ω profiles + cumulative work + AUC(Δ_ID).
    """
    id_p, pc1_p, omega = get_id_pc1_omega_profiles(A_case)
    work = work_from_omegas(omega, gamma=gamma)

    # Δ_ID = id_p relative to baseline (first non-skipped layer)
    base_id = float(id_p[SKIP]) if id_p.size > SKIP else float(id_p[0]) if id_p.size else 0.0
    delta_id = id_p - base_id
    # AUC(Δ_ID > 0) — area where ID exceeded baseline
    auc_pos = float(np.sum(np.maximum(0.0, delta_id)))
    auc_neg = float(np.sum(np.maximum(0.0, -delta_id)))
    auc_net = float(np.sum(delta_id))

    return {
        "id_profile":      id_p.tolist(),
        "pc1r_profile":    pc1_p.tolist(),
        "omega_profile":   omega.tolist(),
        "work_cumulative": work.tolist(),
        "delta_id":        delta_id.tolist(),
        "auc_delta_id_pos": auc_pos,
        "auc_delta_id_neg": auc_neg,
        "auc_delta_id_net": auc_net,
        "n_layers":        int(id_p.size),
        "spike_layer":     int(find_spike_layer(id_p)),
        "valley_layer":    int(find_valley_layer(id_p)),
    }


# ══════════════════════════════════════════════════════════════════════
# Section 6 — bucket / health summary (public-safe rollup)
# ══════════════════════════════════════════════════════════════════════

def _bucket_cpi(cpi: float) -> str:
    if cpi >= 0.40: return "Heavy stagnation"
    if cpi >= 0.20: return "Mild stagnation"
    if cpi >= 0.05: return "Touched"
    return "Free flow"


def _bucket_cdi(cdi: float, order_ok: bool) -> str:
    if not order_ok:                  return "Order broken"
    if cdi >= 0.30:                   return "Strong dissolution"
    if cdi >= 0.10:                   return "Partial dissolution"
    if cdi >  0.0:                    return "Weak dissolution"
    return "No dissolution"


# ══════════════════════════════════════════════════════════════════════
# Section 7 — capture-run integration wrapper
# ══════════════════════════════════════════════════════════════════════

def analyze_capture_run(
    capture_run_dir: str,
    *,
    threshold: float = 0.35,
) -> Optional[Dict[str, Any]]:
    """Read M13 capture run and produce full IRS-DCE dynamics report.

    Reads `<capture_run_dir>/result_minimal.json` and looks for
    `hidden_states_per_layer`.  If absent, returns None (paid features
    omitted by capture pipeline).  If present, runs the full PR_s +
    IRS-DCE_AUC pipeline.
    """
    import json
    from pathlib import Path

    run = Path(capture_run_dir)
    rm_path = run / "result_minimal.json"
    if not rm_path.is_file():
        _debug("analyze.no_result_minimal", path=str(rm_path))
        return None
    try:
        rm = json.loads(rm_path.read_text(encoding="utf-8"))
    except Exception as exc:
        _debug("analyze.read_failed", err=type(exc).__name__)
        return None

    hs = rm.get("hidden_states_per_layer")
    if not hs:
        _debug("analyze.no_hidden_states", run=run.name)
        return None

    # Convert to numpy.  hs is list[layer] of list[token][hidden] OR
    # list[layer] of list[hidden] (single-token = last token).
    try:
        A_case: List[np.ndarray] = []
        for lyr in hs:
            arr = np.asarray(lyr, dtype=np.float64)
            if arr.ndim == 1:
                arr = arr[np.newaxis, :]   # treat as 1 token
            A_case.append(arr)
    except Exception as exc:
        _debug("analyze.shape_failed", err=type(exc).__name__)
        return None

    id_p, pc1_p, omega = get_id_pc1_omega_profiles(A_case)
    density = compute_local_density(id_p, pc1_p)
    orbital = compute_orbital_score(id_p, pc1_p)
    aga = compute_aga(density, orbital, omega)
    cpi = compute_cpi(aga, threshold=threshold)
    eds_prof = compute_eds_profile(id_p, pc1_p)
    cdi = compute_cdi(aga, id_p, pc1_p, omega, threshold=threshold)

    # Single-case AUC summary (IRS-DCE_AUC style)
    case = analyze_case(A_case)

    # Bucket roll-up (UI-friendly)
    summary = {
        "cpi_bucket":       _bucket_cpi(cpi["cpi"]),
        "cdi_bucket":       _bucket_cdi(cdi["cdi"], cdi.get("order_ok", False)),
        "spike_layer":      int(case["spike_layer"]),
        "valley_layer":     int(case["valley_layer"]),
        "auc_delta_id_pos": float(case["auc_delta_id_pos"]),
        "n_layers":         int(case["n_layers"]),
    }

    out = {
        "ok":          True,
        "run_id":      run.name,
        "id_profile":  id_p.tolist(),
        "pc1r_profile": pc1_p.tolist(),
        "omega_profile": omega.tolist(),
        "density":     density.tolist(),
        "orbital":     orbital.tolist(),
        "aga":         aga.tolist(),
        "eds_profile": eds_prof.tolist(),
        "cpi":         cpi,
        "cdi":         cdi,
        "auc":         {
            "pos": case["auc_delta_id_pos"],
            "neg": case["auc_delta_id_neg"],
            "net": case["auc_delta_id_net"],
        },
        "work_cumulative": case["work_cumulative"],
        "delta_id":     case["delta_id"],
        "summary":     summary,
        "n_layers":    int(case["n_layers"]),
    }
    _debug("analyze.ok",
           run=run.name,
           layers=case["n_layers"],
           cpi=summary["cpi_bucket"],
           cdi=summary["cdi_bucket"])
    return out


# ──────────────────────────────────────────────────────────────────────
# Module exports
# ──────────────────────────────────────────────────────────────────────

__all__ = [
    # primitives
    "pca_eigvals", "participation_ratio", "stringiness_pc1_ratio",
    "omega_tensor", "work_from_omegas",
    # profiles
    "get_id_pc1_omega_profiles", "find_spike_layer", "find_valley_layer",
    # case-level metrics
    "compute_local_density", "compute_orbital_score", "compute_aga",
    "compute_cpi", "compute_eds_profile", "eds_window_mean", "compute_cdi",
    # batch
    "compute_bci_circle", "compute_bci_entropy",
    # IRS-DCE_AUC
    "analyze_case",
    # capture integration
    "analyze_capture_run",
]
