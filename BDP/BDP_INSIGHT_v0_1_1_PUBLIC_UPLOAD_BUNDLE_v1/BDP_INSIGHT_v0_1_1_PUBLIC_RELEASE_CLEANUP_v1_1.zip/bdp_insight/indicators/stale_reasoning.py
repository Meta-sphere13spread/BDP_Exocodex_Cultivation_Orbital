"""Indicator 3 — Stale Reasoning Detector.

Detects the specific failure pattern where an intermediate value was edited
but the downstream continuation still anchors on the OLD intermediate.

Canonical example (from project transcripts):
    Before: "3 + 4 = 7, then add 5 → 12"
    After:  "3 + 4 = 99, then add 5 → 12"     <- stale: should be 104

The signal is NOT just "old anchor still appears in after-output".  In the
arithmetic example the old anchor `7` does NOT appear in the after-output
("3 + 4 = 99, then add 5 = 12") — the actual signal is that the **downstream
tail** (`then add 5 = 12`) is byte-identical to the before-output.  In
other words: the intermediate was edited locally, but the rest of the
chain was reused from the old run instead of being recomputed.

Output (always public-safe):
    {
        "label":       "Reasoning consistency: Stale" | "... : Stable",
        "consistency": "Stable" | "Stale" | "Unknown",
        "warning":     bool,
        "note":        "<short observational sentence>",
        "evidence": {
            "edited_anchor":         "<short>",
            "stale_tail_preview":    "<short>",   # the chunk that did not recompute
        },
        "public_safe": True,
    }

This is OBSERVATIONAL.  We say "downstream did not recompute on the new
anchor".  We do NOT say "the model is wrong".  Many harnesses, system
prompts, and chat templates produce this on purpose, and the user is the
one who decides whether it is a real bug.

Algorithm (prototype):
    1. Find the divergence point between before_output and after_output
       (longest common prefix, character-level).
    2. From that divergence point onward, walk forward until you find a
       common substring of meaningful length (≥ 4 chars or ≥ 2 tokens).
    3. If after the divergence the after-tail SHARES a long suffix with
       before-tail → stale (downstream reused the old chain).
    4. If before-tail and after-tail diverge entirely → recomputed.
    5. If no after-output → Unknown.

Limits (prototype):
    - Pure string heuristic.  Tokeniser-agnostic.
    - The threshold (4 chars / 2 tokens) is intentionally conservative;
      false positives are worse than false negatives here.
    - When the new anchor never appears in after-output, we report
      "Unknown" rather than "Stable" — the edit may not have reached the
      visible continuation at all.
"""
from __future__ import annotations

import os
import re
import sys
from typing import Any, Dict, Optional, Tuple

from ..intervention_event import InterventionEvent


# ──────────────────────────────────────────────────────────────────────
# Debug
# ──────────────────────────────────────────────────────────────────────

def _debug(marker: str, **kw: Any) -> None:
    if os.environ.get("BDP_INSIGHT_DEBUG", "").strip() not in ("1", "true", "yes"):
        return
    parts = [f"{k}={_short(v)}" for k, v in kw.items()]
    print(f"[BDP_INSIGHT_I3 {marker}] " + " ".join(parts), file=sys.stderr)


def _short(v: Any, limit: int = 50) -> str:
    s = repr(v)
    return s if len(s) <= limit else s[:limit] + "...]"


# Tail-overlap thresholds (prototype, conservative)
_MIN_STALE_TAIL_CHARS = 4
_MIN_STALE_TAIL_TOKENS = 2


# ──────────────────────────────────────────────────────────────────────
# String / token helpers
# ──────────────────────────────────────────────────────────────────────

_TOKEN_RE = re.compile(r"\w+|[^\w\s]", flags=re.UNICODE)


def _normalize_anchor(s: Optional[str]) -> str:
    if not s:
        return ""
    return s.strip().strip("'\"`.,:;!?()[]{}")


def _common_prefix_len(a: str, b: str) -> int:
    n = min(len(a), len(b))
    i = 0
    while i < n and a[i] == b[i]:
        i += 1
    return i


def _common_suffix_len(a: str, b: str) -> int:
    n = min(len(a), len(b))
    i = 0
    while i < n and a[-(i + 1)] == b[-(i + 1)]:
        i += 1
    return i


def _token_count(s: str) -> int:
    return len(_TOKEN_RE.findall(s)) if s else 0


def _stale_tail_signal(
    before_output: str,
    after_output: str,
) -> Tuple[bool, str]:
    """Detect whether after-output reused the after-divergence tail of before-output.

    Returns (is_stale, stale_tail_preview).
    """
    if not before_output or not after_output:
        return False, ""

    pref = _common_prefix_len(before_output, after_output)
    # divergence 부터 양쪽 tail
    tail_before = before_output[pref:]
    tail_after = after_output[pref:]
    if not tail_before or not tail_after:
        # one side empty → 한쪽이 잘렸을 뿐, stale 신호 아님
        _debug("tail.empty_side",
               len_b=len(tail_before), len_a=len(tail_after))
        return False, ""

    # tail_before 와 tail_after 의 공통 suffix
    common_suffix = _common_suffix_len(tail_before, tail_after)
    if common_suffix < _MIN_STALE_TAIL_CHARS:
        _debug("tail.short_suffix", n=common_suffix)
        return False, ""

    # 토큰 수도 충분해야 (단순 문장부호 끝맺음 같은 노이즈 배제)
    suffix_str = tail_before[-common_suffix:]
    if _token_count(suffix_str) < _MIN_STALE_TAIL_TOKENS:
        _debug("tail.too_few_tokens", n_chars=common_suffix,
               n_tokens=_token_count(suffix_str))
        return False, ""

    _debug("tail.stale_detected", n_chars=common_suffix,
           preview=suffix_str[:30])
    return True, suffix_str[:80]


def _new_anchor_visible(after_output: str, after_anchor: str) -> bool:
    if not after_anchor or not after_output:
        return False
    return after_anchor in after_output


# ──────────────────────────────────────────────────────────────────────
# Public API
# ──────────────────────────────────────────────────────────────────────

def compute_stale_reasoning(event: InterventionEvent) -> Dict[str, Any]:
    """Return a Stale Reasoning record for one InterventionEvent.

    Returns a sober "Stale / Stable / Unknown" label plus a one-line note.
    Never flips to "Wrong" or "Correct" — those are interpretation calls.
    """
    if event is None or not isinstance(event, InterventionEvent):
        _debug("compute.bad_input", t=type(event).__name__)
        return _record(
            "Unknown",
            False,
            "No intervention event available.",
            edited_anchor="",
            stale_tail_preview="",
        )

    before_anchor = _normalize_anchor(event.before_value)
    after_anchor = _normalize_anchor(event.after_value)
    before_output = (event.before_output_preview or "").strip()
    after_output = (event.after_output_preview or "").strip()

    edited_anchor_str = (
        f"{before_anchor} → {after_anchor}".strip(" →")
        if (before_anchor or after_anchor) else ""
    )

    if not after_output:
        _debug("compute.missing_after_output")
        return _record(
            "Unknown",
            False,
            "After-output preview is missing; cannot judge downstream.",
            edited_anchor=edited_anchor_str,
            stale_tail_preview="",
        )

    # 새 anchor 가 후속에 등장 안 함 → 적용 미흡, 판단 보류
    if after_anchor and not _new_anchor_visible(after_output, after_anchor):
        _debug("compute.new_anchor_missing")
        return _record(
            "Unknown",
            False,
            f"New anchor '{after_anchor}' is not visible in the after-output. "
            f"Edit may not have reached the visible continuation.",
            edited_anchor=edited_anchor_str,
            stale_tail_preview="",
        )

    # before_output 도 있어야 tail-overlap 비교 가능
    if not before_output:
        _debug("compute.missing_before_output")
        # 새 anchor 는 보이지만 before-output 비교 불가
        return _record(
            "Unknown",
            False,
            "Before-output preview is missing; cannot compare downstream tails.",
            edited_anchor=edited_anchor_str,
            stale_tail_preview="",
        )

    is_stale, stale_tail = _stale_tail_signal(before_output, after_output)

    if is_stale:
        _debug("compute.stale", tail=stale_tail[:30])
        # 숫자 anchor 케이스면 더 구체적인 note
        if before_anchor and after_anchor and (
            before_anchor.lstrip("-").replace(".", "", 1).isdigit()
            and after_anchor.lstrip("-").replace(".", "", 1).isdigit()
        ):
            note = (
                f"Intermediate edited from '{before_anchor}' to '{after_anchor}', "
                f"but the downstream chain reused the old continuation: "
                f"'{stale_tail[:60]}'."
            )
        else:
            note = (
                f"Anchor edited, but the downstream chain reused part of the old "
                f"continuation: '{stale_tail[:60]}'."
            )
        return _record(
            "Stale",
            True,
            note,
            edited_anchor=edited_anchor_str,
            stale_tail_preview=stale_tail,
        )

    # 새 anchor 정착 + tail 도 새로 짜였음 → Stable
    _debug("compute.stable")
    return _record(
        "Stable",
        False,
        f"Continuation uses the new anchor and the downstream chain looks recomputed.",
        edited_anchor=edited_anchor_str,
        stale_tail_preview="",
    )


# ──────────────────────────────────────────────────────────────────────
# Output helper
# ──────────────────────────────────────────────────────────────────────

def _record(
    consistency: str,
    warning: bool,
    note: str,
    *,
    edited_anchor: str,
    stale_tail_preview: str,
) -> Dict[str, Any]:
    return {
        "label": f"Reasoning consistency: {consistency}",
        "consistency": consistency,
        "warning": warning,
        "note": note,
        "evidence": {
            "edited_anchor": edited_anchor[:80],
            "stale_tail_preview": stale_tail_preview[:80],
        },
        "public_safe": True,
    }

