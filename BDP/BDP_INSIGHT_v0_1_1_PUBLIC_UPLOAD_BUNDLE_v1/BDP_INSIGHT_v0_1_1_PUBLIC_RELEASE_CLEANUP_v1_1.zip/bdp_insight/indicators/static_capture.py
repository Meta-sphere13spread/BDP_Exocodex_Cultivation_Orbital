"""Static capture indicators — ported from SMAP10_2 tab_ai_analysis.

SMAP10_2's tab_ai_analysis bundled session geometry, OBDA orthogonality,
lens attractor, and generation summary into a single read-only context.
The same summary is useful in BDP Insight's static studio without
requiring any live capture: if a capture run wrote `result_minimal.json`,
we can read it after the fact and show the user where layer-level
events / sigma ratio collapses / lens attractors landed.

Sources expected (any may be absent — indicators degrade gracefully):

    <capture_dir>/index.jsonl
    <capture_dir>/<run_id>/capture_index.json
    <capture_dir>/<run_id>/result_minimal.json
    <capture_dir>/<run_id>/manifest.json

We never call torch / model / tokenizer here. We only read JSON.

Public-safe contract:
    Output dicts only contain:
      - integers (layer indices, counts)
      - rounded floats (3 decimals max, no exact scores)
      - bucketed labels (Low/Mid/High, Stable/Drifting/Broken)
      - short string previews (≤ 200 chars)
    NEVER hidden tensors, logits, raw scores, weights, or candidate ranks.

Debug markers (BDP_INSIGHT_DEBUG=1):
    [BDP_INSIGHT_STATIC ...]    load, summarise, no_data
"""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional


# ──────────────────────────────────────────────────────────────────────
# Debug
# ──────────────────────────────────────────────────────────────────────

def _debug(marker: str, **kw: Any) -> None:
    if os.environ.get("BDP_INSIGHT_DEBUG", "").strip() not in ("1", "true", "yes"):
        return
    parts = [f"{k}={v!r}" for k, v in kw.items()]
    print(f"[BDP_INSIGHT_STATIC {marker}] " + " ".join(parts), file=sys.stderr)


# ──────────────────────────────────────────────────────────────────────
# Bucket helpers
# ──────────────────────────────────────────────────────────────────────

def _bucket_sigma_ratio(value: Optional[float]) -> str:
    """OBDA sigma_ratio bucket — orthogonality state."""
    if value is None:
        return "Unknown"
    try:
        v = float(value)
    except (TypeError, ValueError):
        return "Unknown"
    if v >= 0.85:
        return "Stable"
    if v >= 0.55:
        return "Drifting"
    return "Broken"


def _bucket_cpi(value: Optional[float]) -> str:
    """CPI (constraint propagation index) bucket."""
    if value is None:
        return "Unknown"
    try:
        v = float(value)
    except (TypeError, ValueError):
        return "Unknown"
    if v >= 0.7:
        return "High"
    if v >= 0.4:
        return "Mid"
    return "Low"


def _round(value: Any, ndigits: int = 3) -> Optional[float]:
    """Round only if value is a finite number; otherwise return None."""
    try:
        f = float(value)
    except (TypeError, ValueError):
        return None
    if f != f or f in (float("inf"), float("-inf")):
        return None
    return round(f, ndigits)


# ──────────────────────────────────────────────────────────────────────
# Read capture session JSON safely
# ──────────────────────────────────────────────────────────────────────

def _read_json(p: Path) -> Optional[Dict[str, Any]]:
    if not p.is_file():
        return None
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception as exc:
        _debug("read_json.failed", path=str(p), err=type(exc).__name__)
        return None


def list_capture_runs(capture_dir: Path | str) -> List[Dict[str, Any]]:
    """List runs found under capture_dir, newest-first.

    Returns dicts of: {run_id, path, has_result_minimal, has_manifest, mtime}.
    Empty list if capture_dir doesn't exist or has no runs.
    """
    cap = Path(capture_dir)
    if not cap.is_dir():
        _debug("list_runs.no_dir", path=str(cap))
        return []
    runs: List[Dict[str, Any]] = []
    for entry in cap.iterdir():
        if not entry.is_dir():
            continue
        if not (entry.name.startswith("run_") or entry.name.startswith("vscode_")):
            # only keep run-shaped subdirs
            continue
        rm = entry / "result_minimal.json"
        mf = entry / "manifest.json"
        ci = entry / "capture_index.json"
        runs.append({
            "run_id": entry.name,
            "path": str(entry.resolve()),
            "has_result_minimal": rm.is_file(),
            "has_manifest": mf.is_file(),
            "has_capture_index": ci.is_file(),
            "mtime": entry.stat().st_mtime,
        })
    runs.sort(key=lambda r: r["mtime"], reverse=True)
    _debug("list_runs.ok", n=len(runs))
    return runs


# ──────────────────────────────────────────────────────────────────────
# Indicator 6 — Geometry & OBDA Summary
# ──────────────────────────────────────────────────────────────────────

def compute_capture_summary(
    capture_run_dir: Path | str,
) -> Optional[Dict[str, Any]]:
    """Read one capture run and produce a static summary.

    Returns None if the run dir doesn't have any of the source files.
    """
    run = Path(capture_run_dir)
    rm = _read_json(run / "result_minimal.json")
    if rm is None:
        _debug("summary.no_result_minimal", path=str(run))
        return None

    conditions = rm.get("conditions") or [{}]
    c0 = conditions[0] if conditions else {}
    aux = c0.get("aux") or {}
    geom = c0.get("geometry") or {}
    gen = c0.get("generation") or {}
    run_meta = rm.get("run") or {}

    # ── Geometry scalars (rounded, public-safe) ──
    geometry = {
        "cpi":              _round(geom.get("cpi")),
        "cpi_start":        _round(geom.get("cpi_start")),
        "eds":              _round(geom.get("eds")),
        "cdi":              _round(geom.get("cdi")),
        "omega_peak_layer": geom.get("omega_peak_layer"),
        "work_final":       _round(geom.get("work_final")),
        "auc_delta_id":     _round(geom.get("auc_delta_id")),
        "cpi_bucket":       _bucket_cpi(geom.get("cpi")),
    }

    # ── Layer-level events (only event_label != null) ──
    event_layers: List[Dict[str, Any]] = []
    for lyr in (geom.get("layers") or []):
        label = lyr.get("event_label")
        if label:
            event_layers.append({
                "L":     lyr.get("layer"),
                "event": str(label)[:60],
            })
    event_layers = event_layers[:20]  # cap

    # ── Lens attractor (if present) ──
    lens_attractor = aux.get("lens_attractor") or {}
    lens_summary = {
        "token":       str(lens_attractor.get("token", ""))[:40],
        "first_layer": lens_attractor.get("first_seen_layer"),
        "stability":   _round(lens_attractor.get("stability_score")),
    } if lens_attractor else None

    # ── OBDA orthogonality summary ──
    obda_traj = aux.get("obda_trajectory") or {}
    sigma_list = obda_traj.get("sigma_ratios") or []
    obda_summary: Optional[Dict[str, Any]]
    if sigma_list:
        sigma_min = min(sigma_list)
        sigma_max = max(sigma_list)
        obda_summary = {
            "n_layers":        obda_traj.get("n_layers") or len(sigma_list),
            "sigma_min":       _round(sigma_min),
            "sigma_max":       _round(sigma_max),
            "sigma_min_layer": (sigma_list.index(sigma_min)
                                if sigma_min in sigma_list else None),
            "break_layers":    list(aux.get("orthogonality_break_layers", []))[:10],
            "state":           _bucket_sigma_ratio(sigma_min),
        }
    else:
        obda_summary = None

    # ── Generation outcome summary ──
    gen_summary = {
        "n_steps":   gen.get("n_steps"),
        "success":   gen.get("success"),
        "mode_used": str(gen.get("mode_used", ""))[:30],
        "preview":   str(gen.get("generated_text_preview", ""))[:200],
    } if gen else None

    # ── Top-level label (one-line for tab header) ──
    parts: List[str] = []
    if obda_summary:
        parts.append(f"OBDA {obda_summary['state']}")
    if event_layers:
        parts.append(f"{len(event_layers)} layer events")
    if lens_summary and lens_summary.get("token"):
        parts.append(f"lens=`{lens_summary['token']}`")
    label = "Capture summary: " + (
        ", ".join(parts) if parts else "available"
    )

    out = {
        "ok":           True,
        "label":        label,
        "run_id":       run.name,
        "run_meta":     {
            "model":     str(run_meta.get("model", ""))[:60],
            "started_at": run_meta.get("started_at"),
            "duration_sec": _round(run_meta.get("duration_sec")),
        },
        "geometry":     geometry,
        "event_layers": event_layers,
        "lens":         lens_summary,
        "obda":         obda_summary,
        "generation":   gen_summary,
        "n_conditions": len(conditions),
    }
    _debug("summary.ok",
           run_id=run.name,
           obda=obda_summary["state"] if obda_summary else None,
           events=len(event_layers))
    return out


def compute_capture_runs_summary(
    capture_dir: Path | str,
    *,
    limit: int = 20,
) -> Dict[str, Any]:
    """List runs + compute a small summary for each (newest-first).

    The full per-run summary requires reading result_minimal.json which
    can be slow for large benches; we DO compute it here but cap to
    `limit` recent runs.  The studio app re-fetches a single run's
    detailed summary on demand when the user picks one.
    """
    runs = list_capture_runs(capture_dir)
    summaries: List[Dict[str, Any]] = []
    for r in runs[:limit]:
        if not r["has_result_minimal"]:
            summaries.append({
                "run_id":   r["run_id"],
                "ok":       False,
                "label":    "(no result_minimal.json)",
                "mtime":    r["mtime"],
            })
            continue
        s = compute_capture_summary(r["path"])
        if s is None:
            summaries.append({
                "run_id":   r["run_id"],
                "ok":       False,
                "label":    "(read failed)",
                "mtime":    r["mtime"],
            })
        else:
            s["mtime"] = r["mtime"]
            summaries.append(s)

    return {
        "ok":         True,
        "n_runs":     len(runs),
        "n_returned": len(summaries),
        "runs":       summaries,
    }


# ──────────────────────────────────────────────────────────────────────
# Indicator 7 — Notebook viewer (tab_notebook_viewer port, pure static)
# ──────────────────────────────────────────────────────────────────────

def list_problem_notebooks(notebook_dir: Path | str) -> List[Dict[str, Any]]:
    """List problem notebook files under a directory (recursive .json).

    Pure file-based; no model / tokenizer needed.  Returns:
        [{path, name, size, mtime, problem_id}]
    """
    nb = Path(notebook_dir)
    if not nb.is_dir():
        _debug("notebooks.no_dir", path=str(nb))
        return []
    entries: List[Dict[str, Any]] = []
    for p in nb.rglob("*.json"):
        try:
            stat = p.stat()
        except OSError:
            continue
        # try to extract a 'problem_id' if the JSON top-level has one
        pid: Optional[str] = None
        try:
            head = p.read_text(encoding="utf-8", errors="replace")[:200]
            if '"problem_id"' in head:
                # cheap parse: not ast.literal_eval — just find quoted value
                idx = head.find('"problem_id"')
                seg = head[idx:idx + 80]
                # extract  "problem_id": "XYZ"
                import re as _re
                m = _re.search(r'"problem_id"\s*:\s*"([^"]+)"', seg)
                if m:
                    pid = m.group(1)[:40]
        except Exception:
            pass
        entries.append({
            "path":       str(p.resolve()),
            "name":       p.name,
            "size":       stat.st_size,
            "mtime":      stat.st_mtime,
            "problem_id": pid,
        })
    entries.sort(key=lambda e: e["mtime"], reverse=True)
    _debug("notebooks.ok", n=len(entries))
    return entries


# ──────────────────────────────────────────────────────────────────────
# Module exports
# ──────────────────────────────────────────────────────────────────────

__all__ = [
    "list_capture_runs",
    "compute_capture_summary",
    "compute_capture_runs_summary",
    "list_problem_notebooks",
]
