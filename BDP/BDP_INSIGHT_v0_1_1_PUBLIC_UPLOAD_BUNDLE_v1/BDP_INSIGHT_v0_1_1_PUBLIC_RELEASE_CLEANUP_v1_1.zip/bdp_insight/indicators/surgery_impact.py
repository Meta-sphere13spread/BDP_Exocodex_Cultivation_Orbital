"""Indicator 1 — Surgery Impact Map.

Reads a single InterventionEvent and produces a sober label that says, in
plain English, *roughly* how much the intervention disturbed the model output
under the current harness.

Output (always public-safe):
    {
        "label":          "L2 token surgery on token[3]: High impact, Shifting",
        "impact":         "Low" | "Moderate" | "High",
        "affected_stage": "prompt" | "token" | "embedding" |
                          "residual" | "attention" | "mlp" | "head" |
                          "output_prefix" | "unknown",
        "stability":      "Stable" | "Shifting" | "Unstable",
        "applied":        bool,
        "actual_model_event": bool,
        "note":           "<short observational sentence, no causal claim>",
        "public_safe":    True,
    }

This is OBSERVATIONAL, not causal.  We never say "the layer caused the
answer" — we say "after the change the output looks Shifting".  Final
interpretation is the user's job.

Phrasing rules (GPT alignment):
    - Use "Detected", "Shifting", "Stable" — never "True/False reasoning".
    - Bucket only.  No raw % or score.
"""
from __future__ import annotations

import os
import sys
from typing import Any, Dict, Optional

from ..intervention_event import InterventionEvent


# ──────────────────────────────────────────────────────────────────────
# Debug marker
# ──────────────────────────────────────────────────────────────────────

def _debug(marker: str, **kw: Any) -> None:
    if os.environ.get("BDP_INSIGHT_DEBUG", "").strip() not in ("1", "true", "yes"):
        return
    parts = [f"{k}={_short(v)}" for k, v in kw.items()]
    print(f"[BDP_INSIGHT_I1 {marker}] " + " ".join(parts), file=sys.stderr)


def _short(v: Any, limit: int = 50) -> str:
    s = repr(v)
    return s if len(s) <= limit else s[:limit] + "...]"


# ──────────────────────────────────────────────────────────────────────
# Bucket inference
# ──────────────────────────────────────────────────────────────────────

# 사용자가 어디를 수정했냐에 따른 base impact.  이건 "더 깊은 곳을 만질수록
# 영향이 더 클 수 있다" 라는 매우 거친 priors 일 뿐이며, 실제 impact 는
# stability (output 변화) 가 결정적이다 (단정 X — 관측 표현).
_STAGE_BASE_IMPACT = {
    "embedding":     "High",
    "residual":      "High",
    "layer":         "High",
    "head":          "High",
    "mlp":           "High",
    "attention":     "Moderate",
    "output_prefix": "Moderate",
    "token":         "Moderate",
    "prompt":        "Moderate",
    "unknown":       "Low",
}


def _classify_stability(
    before_output: Optional[str],
    after_output: Optional[str],
) -> str:
    """How much did the visible output text move?

    Pure string heuristic — no model calls, no embedding distance, no
    canonical floats.  Output is bucket only.
    """
    if before_output is None and after_output is None:
        _debug("stability.both_missing")
        return "Stable"
    if before_output is None or after_output is None:
        _debug("stability.one_missing",
               has_before=before_output is not None,
               has_after=after_output is not None)
        return "Shifting"
    a = (before_output or "").strip()
    b = (after_output or "").strip()
    if a == b:
        _debug("stability.identical")
        return "Stable"
    # 짧은 prefix 가 같으면 일부만 흔들림
    common = _common_prefix_len(a, b)
    longer = max(len(a), len(b))
    if longer == 0:
        _debug("stability.both_empty")
        return "Stable"
    ratio = common / float(longer)
    if ratio >= 0.8:
        _debug("stability.high_prefix_overlap", ratio_bucket="≥0.8")
        return "Shifting"  # 거의 같지만 끝쪽에서 갈라짐 = Shifting
    if ratio >= 0.3:
        _debug("stability.partial_prefix_overlap", ratio_bucket="0.3~0.8")
        return "Shifting"
    _debug("stability.low_prefix_overlap", ratio_bucket="<0.3")
    return "Unstable"


def _common_prefix_len(a: str, b: str) -> int:
    n = min(len(a), len(b))
    i = 0
    while i < n and a[i] == b[i]:
        i += 1
    return i


def _resolve_impact(
    base: str,
    stability: str,
    status: str,
    actual: bool,
) -> str:
    """Combine stage prior + observed stability into a single Low/Mod/High."""
    # blocked / queued 상태에서는 모델이 실제로 안 움직였으므로 Low
    if status in ("blocked", "blocked_late", "queued", "noop"):
        _debug("impact.gated_by_status", status=status)
        return "Low"
    # actual 이 아니면 preview/시뮬 — Low
    if not actual:
        _debug("impact.not_actual")
        return "Low"
    # 실 이벤트 + 출력 안 흔들림 → 한 단계 낮춤
    order = ["Low", "Moderate", "High"]
    base_i = order.index(base) if base in order else 0
    if stability == "Stable":
        out = order[max(0, base_i - 1)]
        _debug("impact.dampen_stable", base=base, out=out)
        return out
    if stability == "Unstable":
        out = order[min(2, base_i + 1)]
        _debug("impact.amplify_unstable", base=base, out=out)
        return out
    # Shifting → base 그대로
    _debug("impact.passthrough_shifting", base=base)
    return base


def _natural_label(
    intervention_type: str,
    target_ref: str,
    impact: str,
    stability: str,
    status: str,
) -> str:
    if status in ("blocked", "blocked_late"):
        return f"{intervention_type} on {target_ref or 'target'}: blocked (no model change)"
    if status == "queued":
        return f"{intervention_type} on {target_ref or 'target'}: queued"
    return (
        f"{intervention_type} on {target_ref or 'target'}: "
        f"{impact} impact, {stability}"
    )


def _natural_note(
    impact: str,
    stability: str,
    actual: bool,
    status: str,
) -> str:
    if status == "blocked":
        return "Edit was blocked before reaching the model. No output change."
    if status == "blocked_late":
        return "Edit was blocked after partial application. Output change limited."
    if status == "queued":
        return "Edit is queued for the next generation."
    if not actual:
        return "Preview / simulated event, not applied to a live model run."
    if impact == "High" and stability == "Unstable":
        return "Output looks substantially different from before."
    if impact == "High" and stability == "Shifting":
        return "Output continues from a recognisable point but diverges later."
    if impact == "Moderate":
        return "Output shows a visible difference."
    return "Output looks largely unchanged at the visible level."


# ──────────────────────────────────────────────────────────────────────
# Public API
# ──────────────────────────────────────────────────────────────────────

def compute_surgery_impact(event: InterventionEvent) -> Dict[str, Any]:
    """Return a single Surgery Impact Map record for one InterventionEvent.

    Robust to None / wrong-type input — returns a "Low / Stable / unknown"
    fallback record instead of raising.  This keeps dashboard polling loops
    stable across malformed events.
    """
    if event is None or not isinstance(event, InterventionEvent):
        _debug("compute.bad_input", t=type(event).__name__)
        return {
            "label": "no surgery yet",
            "impact": "Low",
            "affected_stage": "unknown",
            "stability": "Stable",
            "applied": False,
            "actual_model_event": False,
            "note": "No intervention event available.",
            "public_safe": True,
        }

    affected_stage = event.target_kind or "unknown"
    base_impact = _STAGE_BASE_IMPACT.get(affected_stage, "Low")
    _debug("compute.stage", stage=affected_stage, base=base_impact)

    stability = _classify_stability(
        event.before_output_preview,
        event.after_output_preview,
    )

    impact = _resolve_impact(
        base=base_impact,
        stability=stability,
        status=event.status,
        actual=bool(event.actual_model_event),
    )

    applied = event.status == "applied"

    out = {
        "label": _natural_label(
            event.intervention_type, event.target_ref,
            impact, stability, event.status,
        ),
        "impact": impact,
        "affected_stage": affected_stage,
        "stability": stability,
        "applied": applied,
        "actual_model_event": bool(event.actual_model_event),
        "note": _natural_note(impact, stability, event.actual_model_event, event.status),
        "public_safe": True,
    }
    _debug("compute.ok", impact=impact, stability=stability, stage=affected_stage)
    return out
