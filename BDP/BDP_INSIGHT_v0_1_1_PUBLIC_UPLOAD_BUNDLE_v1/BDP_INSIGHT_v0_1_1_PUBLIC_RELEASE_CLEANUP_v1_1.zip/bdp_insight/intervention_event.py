"""InterventionEvent — unified schema for 5 BDP Insight indicators.

This module defines the single input format that all indicators consume.
Other tools (NNsight, TransformerLens, Captum, plain user edits, Meta-13
L1/L2/L3 surgery) can be normalised into this schema via `normalize_event()`.

Public-safety rule (enforced at construction time):
    - Long values are truncated to fixed previews.
    - Forbidden keys are stripped.  Forbidden = anything that could leak raw
      tensors, logits, gradients, weight matrices, candidate rankings, or
      selector internals.

Debug markers:
    All branches and exception paths emit a [BDP_INSIGHT_EV ...] line to stderr
    when BDP_INSIGHT_DEBUG=1.  This honours the user requirement to keep
    debuggability visible at every step.
"""
from __future__ import annotations

import os
import sys
import time
from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Mapping, Optional, Sequence, Union


# ──────────────────────────────────────────────────────────────────────
# Constants
# ──────────────────────────────────────────────────────────────────────

PREVIEW_VALUE_MAX = 80     # before_value / after_value 트림 한계
PREVIEW_OUTPUT_MAX = 160   # before_output_preview / after_output_preview 한계
SOURCE_REF_MAX = 80
META_NOTE_MAX = 200

# Schema 가 절대 통과시키지 않는 키 (raw payload / selector internals).
# 이는 BDP Insight 자체 정책이며, 별개로 v1.13.4 의 public_redactor 도 따로
# 작동한다 (이중 방어).
FORBIDDEN_PAYLOAD_KEYS = frozenset({
    # selector internals
    "score_components", "candidate_rank", "candidate_ranks", "weights_json",
    "rank_table", "raw_weight", "raw_weights", "selector_bias",
    # raw model state
    "logits", "logits_raw", "hidden", "hidden_raw", "hidden_tensor",
    "tensor", "tensor_raw",
    "embedding_raw", "gradients", "gradient_raw", "attention_raw",
    # canonical exact metrics
    "score_exact", "weight_exact", "phi_value", "phi_matrix",
    "spectral_entropy_exact", "obda_phi", "obda_phi_3x3",
})

VALID_TARGET_KINDS = frozenset({
    "token", "prompt", "embedding", "layer", "head",
    "residual", "mlp", "attention", "output_prefix", "unknown",
})

VALID_STATUS = frozenset({
    "applied", "noop", "blocked", "queued", "blocked_late", "cleared", "unknown",
})


# ──────────────────────────────────────────────────────────────────────
# Debug helper
# ──────────────────────────────────────────────────────────────────────

def _debug(marker: str, **kw: Any) -> None:
    """Emit a single [BDP_INSIGHT_EV marker] line to stderr when debug is on.

    Honours user requirement: debug markers in every branch.
    """
    if os.environ.get("BDP_INSIGHT_DEBUG", "").strip() not in ("1", "true", "yes"):
        return
    parts = [f"{k}={_short_repr(v)}" for k, v in kw.items()]
    print(f"[BDP_INSIGHT_EV {marker}] " + " ".join(parts), file=sys.stderr)


def _short_repr(v: Any, limit: int = 60) -> str:
    s = repr(v)
    return s if len(s) <= limit else s[:limit] + "...]"


# ──────────────────────────────────────────────────────────────────────
# Schema dataclass
# ──────────────────────────────────────────────────────────────────────

@dataclass
class InterventionEvent:
    """Single normalised intervention record.

    Construct via `InterventionEvent(...)` directly with public-safe values,
    or via `normalize_event(raw_dict)` for foreign-tool inputs (recommended).
    """
    source_tool: str                     # "meta13_l2_token_surgery", "nnsight", ...
    intervention_type: str               # "token_swap", "prompt_rewrite", ...
    target_kind: str                     # one of VALID_TARGET_KINDS
    target_ref: str                      # e.g. "token[3]", "layer[12].head[5]"
    status: str = "applied"              # one of VALID_STATUS

    before_value: Optional[str] = None              # ≤ PREVIEW_VALUE_MAX
    after_value: Optional[str] = None               # ≤ PREVIEW_VALUE_MAX
    before_output_preview: Optional[str] = None     # ≤ PREVIEW_OUTPUT_MAX
    after_output_preview: Optional[str] = None      # ≤ PREVIEW_OUTPUT_MAX

    actual_model_event: bool = False
    ts: float = field(default_factory=time.time)
    note: Optional[str] = None                       # ≤ META_NOTE_MAX, 자유 메모

    event_type: str = "intervention"
    public_safe: bool = True
    schema_version: str = "0.2"

    # ─── post-init: 입력값을 public-safe 로 강제 ─────────────────────
    def __post_init__(self) -> None:
        # 1) target_kind 정규화 (잘못된 값 → "unknown")
        if self.target_kind not in VALID_TARGET_KINDS:
            _debug("post_init.unknown_target_kind", got=self.target_kind)
            self.target_kind = "unknown"

        # 2) status 정규화
        if self.status not in VALID_STATUS:
            _debug("post_init.unknown_status", got=self.status)
            self.status = "unknown"

        # 3) 문자열 트림 (모두)
        self.source_tool = _safe_str(self.source_tool, SOURCE_REF_MAX)
        self.intervention_type = _safe_str(self.intervention_type, SOURCE_REF_MAX)
        self.target_ref = _safe_str(self.target_ref, SOURCE_REF_MAX)
        self.before_value = _safe_optional_str(self.before_value, PREVIEW_VALUE_MAX)
        self.after_value = _safe_optional_str(self.after_value, PREVIEW_VALUE_MAX)
        self.before_output_preview = _safe_optional_str(
            self.before_output_preview, PREVIEW_OUTPUT_MAX
        )
        self.after_output_preview = _safe_optional_str(
            self.after_output_preview, PREVIEW_OUTPUT_MAX
        )
        self.note = _safe_optional_str(self.note, META_NOTE_MAX)

        # 4) ts 가 음수/이상치면 현재 시각으로 대체
        try:
            ts_f = float(self.ts)
            if ts_f < 0:
                _debug("post_init.bad_ts_negative", got=self.ts)
                self.ts = time.time()
            else:
                self.ts = ts_f
        except (TypeError, ValueError):
            _debug("post_init.bad_ts_type", got=type(self.ts).__name__)
            self.ts = time.time()

        # 5) public_safe 는 항상 True 로 강제 (외부에서 False 로 구성 시도 차단)
        if not self.public_safe:
            _debug("post_init.forced_public_safe_true", was=self.public_safe)
        self.public_safe = True

        _debug(
            "post_init.ok",
            tool=self.source_tool,
            kind=self.target_kind,
            status=self.status,
        )

    def to_dict(self) -> Dict[str, Any]:
        """Return a plain dict for JSON serialisation."""
        return asdict(self)


# ──────────────────────────────────────────────────────────────────────
# String helpers (defensive — never leak)
# ──────────────────────────────────────────────────────────────────────

def _safe_str(value: Any, limit: int) -> str:
    if value is None:
        return ""
    try:
        s = str(value)
    except Exception:
        _debug("safe_str.repr_failed", t=type(value).__name__)
        return ""
    return s[:limit]


def _safe_optional_str(value: Any, limit: int) -> Optional[str]:
    if value is None:
        return None
    s = _safe_str(value, limit)
    return s if s else None


# ──────────────────────────────────────────────────────────────────────
# Normaliser: foreign-tool dict → InterventionEvent
# ──────────────────────────────────────────────────────────────────────

def _strip_forbidden(d: Mapping[str, Any]) -> Dict[str, Any]:
    """Remove FORBIDDEN_PAYLOAD_KEYS recursively from any nested dict.

    Lists are walked; non-dict / non-list leaves pass through.
    """
    out: Dict[str, Any] = {}
    for k, v in d.items():
        lk = str(k).lower()
        if lk in FORBIDDEN_PAYLOAD_KEYS:
            _debug("strip_forbidden.dropped_key", key=lk)
            continue
        if isinstance(v, dict):
            out[k] = _strip_forbidden(v)
        elif isinstance(v, list):
            new_list = []
            for item in v:
                if isinstance(item, dict):
                    new_list.append(_strip_forbidden(item))
                else:
                    new_list.append(item)
            out[k] = new_list
        else:
            out[k] = v
    return out


def normalize_event(raw: Mapping[str, Any]) -> InterventionEvent:
    """Normalise a foreign-tool dict into an InterventionEvent.

    Accepted source keys (any one of the per-row alternatives works):
        source_tool / source / tool
        intervention_type / kind / op / function_id
        target_kind / target_type
        target_ref / target / ref
        before_value / before / old_value / old_word_preview / old_text_preview
        after_value  / after  / new_value / new_word_preview / new_text_preview
        before_output_preview / before_output / before_text
        after_output_preview  / after_output  / after_text
        status / state
        actual_model_event / actual / live
        ts / timestamp / time

    Forbidden keys (e.g. score_components, weights_json, raw tensors) are
    stripped before construction.

    On unrecoverable input the function returns an InterventionEvent with
    target_kind="unknown" and status="unknown" instead of raising — this
    keeps indicator pipelines robust to messy input.
    """
    if raw is None:
        _debug("normalize_event.none_input")
        return InterventionEvent(
            source_tool="unknown",
            intervention_type="unknown",
            target_kind="unknown",
            target_ref="",
            status="unknown",
        )
    if not isinstance(raw, Mapping):
        _debug("normalize_event.not_mapping", t=type(raw).__name__)
        return InterventionEvent(
            source_tool="unknown",
            intervention_type="unknown",
            target_kind="unknown",
            target_ref="",
            status="unknown",
        )

    cleaned = _strip_forbidden(raw)

    def _pick(*keys: str) -> Any:
        for k in keys:
            if k in cleaned and cleaned[k] is not None:
                return cleaned[k]
        return None

    source_tool = _pick("source_tool", "source", "tool") or "unknown"
    intervention_type = (
        _pick("intervention_type", "kind", "op", "function_id") or "unknown"
    )
    target_kind = _pick("target_kind", "target_type") or _infer_target_kind(
        intervention_type
    )
    target_ref = _pick("target_ref", "target", "ref") or ""
    before_value = _pick(
        "before_value", "before", "old_value",
        "old_word_preview", "old_text_preview", "old_word",
    )
    after_value = _pick(
        "after_value", "after", "new_value",
        "new_word_preview", "new_text_preview", "new_word",
    )
    before_output = _pick(
        "before_output_preview", "before_output", "before_text",
    )
    after_output = _pick(
        "after_output_preview", "after_output", "after_text",
        "answer_preview", "partial_answer_preview",
    )
    status = _pick("status", "state") or _infer_status(cleaned)
    actual = bool(_pick("actual_model_event", "actual", "live") or False)
    ts = _pick("ts", "timestamp", "time") or time.time()
    note = _pick("note", "reason", "message")

    ev = InterventionEvent(
        source_tool=str(source_tool),
        intervention_type=str(intervention_type),
        target_kind=str(target_kind),
        target_ref=str(target_ref),
        status=str(status),
        before_value=before_value,
        after_value=after_value,
        before_output_preview=before_output,
        after_output_preview=after_output,
        actual_model_event=actual,
        ts=ts,
        note=note,
    )
    _debug("normalize_event.ok", tool=ev.source_tool, kind=ev.target_kind)
    return ev


def _infer_target_kind(intervention_type: Any) -> str:
    t = str(intervention_type or "").lower()
    if "token_swap" in t or "swap_token" in t or "rewrite_token" in t:
        return "token"
    if "prompt" in t or "rewrite_prompt" in t or "l1_rewrite" in t:
        return "prompt"
    if "embed" in t or "embedding" in t:
        return "embedding"
    if "head" in t and "ablate" in t:
        return "head"
    if "residual" in t or "activation_patch" in t:
        return "residual"
    if "mlp" in t:
        return "mlp"
    if "attention" in t:
        return "attention"
    if "output_intercept" in t or "hodge_output" in t or "after_tokens" in t:
        return "output_prefix"
    return "unknown"


def _infer_status(d: Mapping[str, Any]) -> str:
    kind = str(d.get("kind", "")).lower()
    if "blocked" in kind:
        if "late" in kind:
            return "blocked_late"
        return "blocked"
    if kind == "paid_surgery_applied":
        return "applied" if d.get("changed") else "noop"
    if kind == "paid_surgery_noop":
        return "noop"
    if kind == "paid_command_accepted":
        return "queued"
    if kind == "rewrite_prompt":
        return "applied"
    if kind == "l1_mid_rewrite_armed":
        return "queued"
    if kind == "l1_mid_rewrite_disarmed":
        return "cleared"
    return "unknown"


# ──────────────────────────────────────────────────────────────────────
# Bulk normaliser (events.jsonl 같은 데서 한 번에)
# ──────────────────────────────────────────────────────────────────────

def normalize_events(
    raws: Sequence[Mapping[str, Any]],
) -> List[InterventionEvent]:
    """Normalise a list of foreign dicts into InterventionEvents.

    Bad rows are skipped (with a debug marker), not raised, so a single
    malformed line does not break the whole pipeline.
    """
    out: List[InterventionEvent] = []
    for i, r in enumerate(raws or []):
        try:
            out.append(normalize_event(r))
        except Exception as exc:
            _debug("normalize_events.row_skipped", i=i, err=type(exc).__name__)
    _debug("normalize_events.done", n_in=len(raws or []), n_out=len(out))
    return out
