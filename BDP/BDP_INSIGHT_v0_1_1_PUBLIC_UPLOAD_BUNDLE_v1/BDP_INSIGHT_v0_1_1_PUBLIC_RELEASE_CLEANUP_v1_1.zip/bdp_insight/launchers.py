"""Launch helpers for BDP-insight examples and installed CLI.

These helpers intentionally do not depend on BAT files.  They start the
dynamic Flask debugger and optional Streamlit Studio using Python subprocesses.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Optional
import importlib.util
import os
import socket
import subprocess
import sys
import time
import webbrowser


@dataclass
class LaunchedProcess:
    name: str
    url: str
    process: Optional[subprocess.Popen]

    def is_running(self) -> bool:
        return self.process is not None and self.process.poll() is None

    def terminate(self) -> None:
        if self.process is not None and self.process.poll() is None:
            self.process.terminate()


def find_free_port(start: int = 7860, host: str = "127.0.0.1", limit: int = 50) -> int:
    """Find a free localhost port near `start`."""
    for port in range(int(start), int(start) + int(limit)):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(0.2)
            if s.connect_ex((host, port)) != 0:
                return port
    return int(start)


def open_browser(url: str, *, enabled: bool = True) -> None:
    if not enabled:
        return
    try:
        webbrowser.open(url)
    except Exception:
        pass


def start_dynamic_dashboard(
    *,
    run_dir: str = "results/bdp_hodge_run",
    capture_dir: str = "results/bdp_hodge_capture",
    host: str = "127.0.0.1",
    port: int = 7860,
    open_url: bool = True,
) -> LaunchedProcess:
    """Start the dynamic Flask debugger dashboard.

    This is equivalent to:
        python -m meta13_mri.dashboard_min --run-dir ... --capture-dir ...
    """
    port = find_free_port(port, host=host)
    url = f"http://{host}:{port}"
    Path(run_dir).mkdir(parents=True, exist_ok=True)
    Path(capture_dir).mkdir(parents=True, exist_ok=True)

    cmd = [
        sys.executable,
        "-m",
        "meta13_mri.dashboard_min",
        "--run-dir",
        str(run_dir),
        "--capture-dir",
        str(capture_dir),
        "--host",
        str(host),
        "--port",
        str(port),
    ]
    proc = subprocess.Popen(
        cmd,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        cwd=str(Path.cwd()),
    )
    time.sleep(0.6)
    open_browser(url, enabled=open_url)
    return LaunchedProcess("dynamic-dashboard", url, proc)


def start_static_studio(
    *,
    events_path: str | None = None,
    host: str = "127.0.0.1",
    port: int = 8501,
    open_url: bool = True,
) -> LaunchedProcess:
    """Start the optional Streamlit Studio / static MRI dashboard.

    Requires:
        pip install bdp-insight[studio]

    If Streamlit is missing, this raises RuntimeError with an install hint.
    """
    if importlib.util.find_spec("streamlit") is None:
        raise RuntimeError("streamlit is not installed. Install with: pip install bdp-insight[studio]")

    import bdp_insight.studio.app as studio_app  # imported only when needed

    app_path = Path(studio_app.__file__).resolve()
    port = find_free_port(port, host=host)
    url = f"http://{host}:{port}"

    env = os.environ.copy()
    if events_path:
        env["BDP_INSIGHT_EVENTS_PATH"] = str(events_path)
        try:
            env["BDP_INSIGHT_RESULTS_ROOT"] = str(Path(events_path).parents[2])
        except Exception:
            pass

    cmd = [
        sys.executable,
        "-m",
        "streamlit",
        "run",
        str(app_path),
        "--server.address",
        str(host),
        "--server.port",
        str(port),
        "--browser.gatherUsageStats",
        "false",
    ]
    proc = subprocess.Popen(
        cmd,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        cwd=str(Path.cwd()),
        env=env,
    )
    time.sleep(1.2)
    open_browser(url, enabled=open_url)
    return LaunchedProcess("static-studio", url, proc)


__all__ = [
    "LaunchedProcess",
    "find_free_port",
    "open_browser",
    "start_dynamic_dashboard",
    "start_static_studio",
]
