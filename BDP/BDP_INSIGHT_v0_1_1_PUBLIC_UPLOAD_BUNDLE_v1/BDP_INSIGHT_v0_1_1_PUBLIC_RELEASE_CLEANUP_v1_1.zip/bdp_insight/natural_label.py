"""mri_metric_schema.py — MRI metric schema and sober English labels.

Layer policy
------------
- raw: internal local-only capture material; never public by default
- canonical: stable MRI/regression values; paid/internal only
- public: dashboard-safe buckets and labels; free-visible unless locked

This module contains labels and visibility metadata only.  It does not compute
paid metrics and does not contain mutation logic.
"""
from __future__ import annotations

from enum import Enum
from typing import Any, Dict, TypedDict


class MetricLayer(str, Enum):
    RAW = "raw"
    CANONICAL = "canonical"
    PUBLIC = "public"


class MetricVisibility(str, Enum):
    FREE = "free"
    PAID = "paid"
    INTERNAL = "internal"


METRIC_REGISTRY: Dict[str, Dict[str, Any]] = {
    "activation_residual_activity": {
        "layer": MetricLayer.PUBLIC,
        "visibility": MetricVisibility.FREE,
        "public_name": "Residual Activity",
        "buckets": ["low", "moderate", "high", "available", "unknown"],
    },
    "attention_focus": {
        "layer": MetricLayer.PUBLIC,
        "visibility": MetricVisibility.FREE,
        "public_name": "Attention Focus",
        "buckets": ["low", "moderate", "high", "available", "unknown"],
    },
    "logit_gap": {
        "layer": MetricLayer.PUBLIC,
        "visibility": MetricVisibility.FREE,
        "public_name": "Logit Gap",
        "buckets": ["narrow", "moderate", "strong", "available", "unknown"],
    },
    "gradient_attribution_signal": {
        "layer": MetricLayer.PUBLIC,
        "visibility": MetricVisibility.FREE,
        "public_name": "Gradient Attribution",
        "buckets": ["weak", "moderate", "strong", "available", "locked_or_not_captured"],
    },
    "layer_token_dim_coverage": {
        "layer": MetricLayer.PUBLIC,
        "visibility": MetricVisibility.FREE,
        "public_name": "Layer × Token × Dimension Coverage",
        "buckets": ["available", "metadata_only", "unknown"],
    },
    "mlp_ffn_activity": {
        "layer": MetricLayer.PUBLIC,
        "visibility": MetricVisibility.FREE,
        "public_name": "MLP / FFN Activity",
        "buckets": ["low", "moderate", "high", "unknown"],
    },
    "effective_rank_geometry": {
        "layer": MetricLayer.PUBLIC,
        "visibility": MetricVisibility.FREE,
        "public_name": "Effective Rank",
        "buckets": ["compressed", "balanced", "expanded", "low", "moderate", "high", "unknown"],
    },
    "irsdce_geometry": {
        "layer": MetricLayer.CANONICAL,
        "visibility": MetricVisibility.PAID,
        "public_name": "IRSDCE Geometry",
        "buckets": ["available", "locked"],
        "free_label": "IRSDCE Geometry: Locked",
        "free_message": "Available in paid runtime.",
    },
    "irsdce_irs_weight": {
        "layer": MetricLayer.CANONICAL,
        "visibility": MetricVisibility.PAID,
        "public_name": "IRS Weight",
    },
    "irsdce_dce_weight": {
        "layer": MetricLayer.CANONICAL,
        "visibility": MetricVisibility.PAID,
        "public_name": "DCE Weight",
    },
    "irsdce_cascade_strength": {
        "layer": MetricLayer.CANONICAL,
        "visibility": MetricVisibility.PAID,
        "public_name": "Cascade Strength",
    },
    "route_pressure_canonical": {
        "layer": MetricLayer.CANONICAL,
        "visibility": MetricVisibility.PAID,
        "public_name": "Route Pressure",
    },
    "basis_pressure_canonical": {
        "layer": MetricLayer.CANONICAL,
        "visibility": MetricVisibility.PAID,
        "public_name": "Basis Pressure",
    },
    "phase_pressure_canonical": {
        "layer": MetricLayer.CANONICAL,
        "visibility": MetricVisibility.PAID,
        "public_name": "Phase Pressure",
    },
}


LABEL_TEMPLATES: Dict[str, Dict[str, str]] = {
    "attention_focus": {
        "high": "Attention focus: High",
        "moderate": "Attention focus: Moderate",
        "mid": "Attention focus: Moderate",
        "low": "Attention focus: Low",
        "available": "Attention focus: Available",
        "unknown": "Attention focus: Unknown",
    },
    "activation_residual_activity": {
        "high": "Residual activity: High",
        "moderate": "Residual activity: Moderate",
        "mid": "Residual activity: Moderate",
        "low": "Residual activity: Low",
        "available": "Residual activity: Available",
        "unknown": "Residual activity: Unknown",
    },
    "logit_gap": {
        "strong": "Logit gap: Strong",
        "moderate": "Logit gap: Moderate",
        "mid": "Logit gap: Moderate",
        "narrow": "Logit gap: Narrow",
        "available": "Logit gap: Available",
        "unknown": "Logit gap: Unknown",
    },
    "effective_rank_geometry": {
        "compressed": "Effective rank: Compressed",
        "balanced": "Effective rank: Balanced",
        "expanded": "Effective rank: Expanded",
        "high": "Effective rank: Expanded",
        "moderate": "Effective rank: Balanced",
        "mid": "Effective rank: Balanced",
        "low": "Effective rank: Compressed",
        "unknown": "Effective rank: Unknown",
    },
    "gradient_attribution_signal": {
        "strong": "Gradient attribution: Strong",
        "moderate": "Gradient attribution: Moderate",
        "mid": "Gradient attribution: Moderate",
        "weak": "Gradient attribution: Weak",
        "available": "Gradient attribution: Available",
        "locked_or_not_captured": "Gradient attribution: Not captured",
    },
    "mlp_ffn_activity": {
        "high": "MLP/FFN activity: High",
        "moderate": "MLP/FFN activity: Moderate",
        "mid": "MLP/FFN activity: Moderate",
        "low": "MLP/FFN activity: Low",
        "unknown": "MLP/FFN activity: Unknown",
    },
    "layer_token_dim_coverage": {
        "available": "Coverage: Layer × Token × Dimension available",
        "metadata_only": "Coverage: Metadata only",
        "unknown": "Coverage: Unknown",
    },
    "irsdce_geometry": {
        "available": "IRSDCE geometry: Available",
        "locked": "IRSDCE Geometry: Locked",
    },
}


def _value(v: Any) -> str:
    return getattr(v, "value", str(v))


def get_metric_info(metric_id: str) -> Dict[str, Any]:
    return dict(METRIC_REGISTRY.get(metric_id, {}))


def get_label(metric_id: str, bucket: str) -> str:
    b = str(bucket or "unknown").strip().lower()
    templates = LABEL_TEMPLATES.get(metric_id, {})
    if b in templates:
        return templates[b]
    info = METRIC_REGISTRY.get(metric_id, {})
    name = info.get("public_name", metric_id)
    return f"{name}: {b.replace('_', ' ').title()}"


def is_visible_for_tier(metric_id: str, *, paid_enabled: bool) -> bool:
    info = METRIC_REGISTRY.get(metric_id, {})
    vis = info.get("visibility", MetricVisibility.PAID)
    vis_val = _value(vis)
    if vis_val == MetricVisibility.FREE.value:
        return True
    if vis_val == MetricVisibility.PAID.value:
        return bool(paid_enabled)
    return False


def locked_card(metric_id: str) -> Dict[str, Any]:
    info = METRIC_REGISTRY.get(metric_id, {})
    return {
        "metric_id": metric_id,
        "locked": True,
        "label": info.get("free_label") or f"{info.get('public_name', metric_id)}: Locked",
        "message": info.get("free_message") or "Available in paid runtime.",
        "tier": "free",
        "public_safe": True,
    }


class MRIMetricEnvelope(TypedDict, total=False):
    schema_version: str
    metric_layer: str
    privacy_level: str
    tier_required: str
    raw_mri_metrics: Dict[str, Any]
    canonical_mri_metrics: Dict[str, Any]
    public_mri_metrics: Dict[str, Any]
    locked_metrics: Dict[str, Any]


def make_envelope(*, layer: MetricLayer, metrics: Dict[str, Any], paid_enabled: bool) -> MRIMetricEnvelope:
    env: MRIMetricEnvelope = {
        "schema_version": "mri.v1.13.4",
        "metric_layer": layer.value,
        "privacy_level": "public" if layer == MetricLayer.PUBLIC else ("internal_paid" if paid_enabled else "internal"),
        "tier_required": "free" if layer == MetricLayer.PUBLIC else "paid",
    }
    if layer == MetricLayer.PUBLIC:
        env["public_mri_metrics"] = metrics
    elif layer == MetricLayer.CANONICAL:
        env["canonical_mri_metrics"] = metrics
    else:
        env["raw_mri_metrics"] = metrics
    return env


__all__ = [
    "MetricLayer",
    "MetricVisibility",
    "METRIC_REGISTRY",
    "LABEL_TEMPLATES",
    "get_metric_info",
    "get_label",
    "is_visible_for_tier",
    "locked_card",
    "make_envelope",
]
