"""
premium_client.py — ephemeral premium function lease client (v0.4)
====================================================================

This is not remote execution.
The server does not receive prompt/model/snapshot/log/tensor data and does not
return analysis results. It only delivers an obfuscated encrypted native function
material for one local call.

v0.4 changes
------------
- public API is `lease_function(op)` rather than `fetch_so(op)`
- `fetch_so(op)` remains as a compatibility alias but returns a lease, not bytes
- no request payload is sent to the v0.4 lease endpoint by default
- raw bytes are wrapped in EphemeralBlob and then EphemeralFunctionLease
- `call_once()` performs lease + local execute + clear
- failures include failure_reason for local debugger logs
"""
from __future__ import annotations

import hashlib
import hmac
import logging
import os
import time
from typing import Any, Optional

from .ephemeral_blob import EphemeralBlob
from .ephemeral_lease import EphemeralFunctionLease
from .entitlement import resolve_entitlement

logger = logging.getLogger("meta13.premium_client")


# Free-build public paid preview contract.  This registry is intentionally
# schema/metadata only; it contains no L2/L3 surgery implementation.
PAID_FUNCTION_REGISTRY = {
    "l2.hodge_auto": {
        "tier": "paid",
        "title": "L2 HodgeConverter Auto Token Surgery",
        "description": "Automatic Hodge-style token/span selection followed by conversion through the paid Modal/server kernel.",
        "free_behavior": "blocked_command + paid_preview",
        "input_schema": {
            "new_word": "string required",
            "target_regex": "string optional"
        },
        "output_schema": {
            "ok": "bool",
            "route": "L2_HODGE_AUTO",
            "changed": "bool",
            "hodge_features": "object"
        },
    },
    "l3.embed_perturb": {
        "tier": "free",
        "title": "L3 Embedding Surgery / perturb",
        "description": "Embedding-level amplify/suppress/noise executed as a free local one-generate hook.",
        "free_behavior": "local_free_hook",
        "input_schema": {
            "position": "int",
            "mode": "amplify|suppress|noise",
            "magnitude": "float",
        },
        "output_schema": {
            "ok": "bool",
            "route": "L3_EMBED_PERTURB",
            "embedding_delta": "object",
            "drift_delta": "float optional",
        },
    },
    "l3.embed_replace": {
        "tier": "free",
        "title": "L3 Embedding Surgery / replace",
        "description": "Embedding replacement metadata is free; tensor hook application remains local.",
        "free_behavior": "local_free_hook",
        "input_schema": {
            "position": "int",
            "target_word": "string optional",
            "target_token_id": "int optional",
        },
        "output_schema": {
            "ok": "bool",
            "route": "L3_EMBED_REPLACE",
            "changed": "bool",
        },
    },
    "deep.obda_phi": {
        "tier": "paid",
        "title": "Deep MRI / OBDA phi",
        "description": "Deep MRI scalar extraction. Free build exposes metadata only.",
        "free_behavior": "metadata_only",
        "input_schema": {
            "capture_id": "string",
            "layer_range": "array optional",
        },
        "output_schema": {
            "ok": "bool",
            "phi": "float",
            "confidence": "float",
            "summary": "object",
        },
    },
    "deep.spectral": {
        "tier": "paid",
        "title": "Deep MRI / Spectral Summary",
        "description": "Spectral entropy/effective-rank summary. Free build exposes metadata only.",
        "free_behavior": "metadata_only",
    },
    "deep.attractor": {
        "tier": "paid",
        "title": "Deep MRI / Attractor Lens",
        "description": "Lens/attractor analysis. Free build exposes metadata only.",
        "free_behavior": "metadata_only",
    },
}


def get_paid_function_registry() -> dict:
    """Return paid function metadata only. No surgery implementation is exposed."""
    return dict(PAID_FUNCTION_REGISTRY)

try:
    import requests as _requests
    _HAS_REQUESTS = True
except Exception:
    _HAS_REQUESTS = False


class PremiumRequired(RuntimeError):
    pass


class PremiumTransportError(RuntimeError):
    pass


class PremiumDebuggerClient:
    """
    Premium function delivery client.

    The client never uploads analysis data. It only asks for a one-shot function
    lease by URL path, receives opaque bytes over HTTPS, wraps them in an
    EphemeralBlob, and executes them locally through SoLoader.
    """

    def __init__(
        self,
        base_url: str = "https://api.meta13.example",
        api_key: Optional[str] = None,
        *,
        hmac_secret: Optional[str] = None,
        timeout: float = 30.0,
        prefer_v04_lease_endpoint: bool = True,
    ):
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key or os.getenv("META13_PAID_KEY") or os.getenv("META13_API_KEY", "")
        self.hmac_secret = hmac_secret or os.getenv("META13_HMAC_SECRET", "")
        self.timeout = timeout
        self.prefer_v04_lease_endpoint = bool(prefer_v04_lease_endpoint)
        self.entitlement = resolve_entitlement(
            paid_key=self.api_key or None,
            paid_mode=os.getenv("META13_PAID_MODE"),
            api_base=self.base_url,
            client_version="0.1.12-runtime",
        )

    @staticmethod
    def _op_to_slug(op: str) -> str:
        return op.strip().replace(".", "-").replace("_", "-")

    def _headers(self, signing_message: bytes = b"") -> dict:
        ts = str(int(time.time()))
        h = {
            "Accept": "application/octet-stream, application/json",
            "Cache-Control": "no-store",
            "X-Meta13-Timestamp": ts,
            "X-Meta13-Client": "meta13-mri-v0.4",
        }
        if self.api_key:
            h["Authorization"] = f"Bearer {self.api_key}"
        if self.hmac_secret:
            sig = hmac.new(
                self.hmac_secret.encode("utf-8"),
                ts.encode("utf-8") + b"." + signing_message,
                hashlib.sha256,
            ).hexdigest()
            h["X-Meta13-Signature"] = sig
        return h

    def _raise_for_error_response(self, response, op: str) -> None:
        if response.status_code < 400:
            return
        try:
            payload = response.json()
            detail = payload.get("error") or payload.get("message") or payload
            failure_reason = payload.get("debug", {}).get("failure_reason", "server_error")
        except Exception:
            detail = response.text[:300]
            failure_reason = "server_error"

        if response.status_code in (401, 402, 403):
            raise PremiumRequired(
                f"auth/payment required for op={op!r} "
                f"(HTTP {response.status_code}, failure_reason={failure_reason}): {detail}"
            )
        raise PremiumTransportError(
            f"premium lease failed for op={op!r} "
            f"(HTTP {response.status_code}, failure_reason={failure_reason}): {detail}"
        )

    # ── v0.4 primary API ──────────────────────────────────────────────────
    def lease_function(self, op: str) -> EphemeralFunctionLease:
        """
        Lease one premium function material for exactly one local execution.

        No prompt/model/snapshot/tensor/log/result is sent. By default this calls:
            POST {base_url}/v1/lease/{op-with-dashes}
        with an empty body.
        """
        if not _HAS_REQUESTS:
            raise PremiumRequired("pip install meta13-mri[premium]")
        op = str(op).strip()
        if not op:
            raise ValueError("op is required")

        slug = self._op_to_slug(op)
        signing_message = slug.encode("utf-8")
        url = f"{self.base_url}/v1/lease/{slug}"
        logger.debug("[premium_client] lease op=%s url=%s", op, url)

        response = _requests.post(
            url,
            data=b"",
            headers=self._headers(signing_message),
            timeout=self.timeout,
        )
        self._raise_for_error_response(response, op)

        raw = response.content
        sha_expected = response.headers.get("X-Meta13-SHA256", "").strip().lower()
        if sha_expected:
            sha_actual = hashlib.sha256(raw).hexdigest()
            if not hmac.compare_digest(sha_actual, sha_expected):
                raise PremiumTransportError(
                    f"sha256 mismatch for op={op!r}: expected={sha_expected} actual={sha_actual}"
                )

        price = response.headers.get("X-Meta13-Price-USD", "?")
        lease_id = response.headers.get("X-Meta13-Lease-ID", "")
        logger.info(
            "[premium_client] leased op=%s bytes=%d price=$%s lease_id=%s",
            op, len(raw), price, lease_id[:12],
        )
        blob = EphemeralBlob(raw, op=op)
        del raw
        lease = EphemeralFunctionLease(op=op, _blob=blob)
        if lease_id:
            lease.lease_id = lease_id
        return lease

    def call_once(self, op: str, fn_name: str = "run", *args: Any, **kwargs: Any) -> Any:
        """Lease a function, execute it locally once, and clear material."""
        lease = self.lease_function(op)
        return lease.execute(fn_name, *args, **kwargs)

    # ── compatibility API ─────────────────────────────────────────────────
    def fetch_so(self, op: str) -> EphemeralFunctionLease:
        """
        Deprecated compatibility alias.

        v0.4 does not return raw .so bytes and does not expose ownership. This
        method returns EphemeralFunctionLease so older code can still do:
            with client.fetch_so(op).consume() as lib: ...
        """
        logger.warning("[premium_client] fetch_so() is deprecated; use lease_function().")
        return self.lease_function(op)

    # ── convenience leases ────────────────────────────────────────────────
    def lease_l2_swap_token(self) -> EphemeralFunctionLease:
        raise RuntimeError("l2.swap_token removed; use l2.hodge_auto or l2.hodge_output_intercept")

    def lease_l3_embed_perturb(self) -> EphemeralFunctionLease:
        return self.lease_function("l3.embed_perturb")

    def lease_deep_obda(self) -> EphemeralFunctionLease:
        return self.lease_function("deep.obda_phi")

    def lease_deep_spectral(self) -> EphemeralFunctionLease:
        return self.lease_function("deep.spectral")

    def lease_deep_attractor(self) -> EphemeralFunctionLease:
        return self.lease_function("deep.attractor")

    # v0.3 compatibility names; now return leases, not blobs
    fetch_l3_embed_perturb = lease_l3_embed_perturb
    fetch_deep_obda = lease_deep_obda
    fetch_deep_spectral = lease_deep_spectral
    fetch_deep_attractor = lease_deep_attractor


    # ── free-build preview/status API ───────────────────────────────────────
    def preview(self, function_id: str, payload: Optional[dict] = None) -> dict:
        """Return a paid-feature preview contract without executing paid code."""
        function_id = str(function_id or "").strip()
        spec = PAID_FUNCTION_REGISTRY.get(function_id)
        if not spec:
            return {
                "ok": False,
                "error": "unknown paid function_id",
                "function_id": function_id,
                "available_preview": sorted(PAID_FUNCTION_REGISTRY.keys()),
            }
        return {
            "ok": True,
            "preview_only": True,
            "simulated": True,
            "actual_model_event": False,
            "tier": self.entitlement.tier,
            "function_id": function_id,
            "spec": spec,
            "payload": dict(payload or {}),
            "route_to": "PremiumDebuggerClient.lease_function",
            "message": "Paid key present; command API can execute local paid runtime." if self.entitlement.paid_enabled else "This function requires paid leased local execution.",
        }

    def paid_status(self) -> dict:
        """Report paid capability status for the free distribution build."""
        return {
            "ok": True,
            "tier": self.entitlement.tier,
            "paid_enabled": self.entitlement.paid_enabled,
            "paid_mode": self.entitlement.paid_mode,
            "actual_execution": bool(self.entitlement.paid_enabled and self.entitlement.paid_mode == "local_import"),
            "entitlement": self.entitlement.public_dict(),
            "available_preview": sorted(PAID_FUNCTION_REGISTRY.keys()),
            "message": "Paid local runtime is enabled by key." if self.entitlement.paid_enabled else "Paid execution requires PremiumDebuggerClient lease runtime.",
        }

    def call_paid(self, function_id: str, payload: Optional[dict] = None) -> dict:
        """Free-build guard: never execute L2/L3/deep paid functions locally."""
        function_id = str(function_id or "").strip()
        if not self.entitlement.paid_enabled:
            return {
                "ok": False,
                "error": "paid function requires entitlement key",
                "function_id": function_id,
                "route_to": "PremiumDebuggerClient.lease_function",
                "preview": self.preview(function_id, payload or {}),
            }
        return {
            "ok": False,
            "error": "direct call_paid is reserved for leased native runtime; use /api/debug/command for local_import v1.12",
            "function_id": function_id,
            "paid_mode": self.entitlement.paid_mode,
            "route_to": "PremiumDebuggerClient.lease_function",
            "preview": self.preview(function_id, payload or {}),
        }

    def list_ops(self) -> dict:
        if not _HAS_REQUESTS:
            raise PremiumRequired("pip install meta13-mri[premium]")
        response = _requests.get(f"{self.base_url}/v1/debugger/ops", timeout=self.timeout)
        response.raise_for_status()
        return response.json()
