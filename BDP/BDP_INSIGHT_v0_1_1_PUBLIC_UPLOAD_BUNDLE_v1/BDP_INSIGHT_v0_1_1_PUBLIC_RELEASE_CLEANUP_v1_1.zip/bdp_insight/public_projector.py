from __future__ import annotations

"""Public-safe metric projection helpers.

These helpers intentionally do *not* expose raw selector weights, candidate
rankings, attractor scores, boundary scores, salience scores, or SMAP/Hodge
score components.  They turn mixed runtime signals into coarse dashboard values
such as buckets and rounded percentages.
"""

import hashlib
import json
import os
import time
from typing import Any, Dict, Iterable, Mapping


def internal_hodge_enabled() -> bool:
    return str(os.getenv("META13_INTERNAL_HODGE", "")).strip().lower() in {"1", "true", "yes", "on"}


def public_safe_enabled() -> bool:
    val = str(os.getenv("META13_PUBLIC_SAFE", "1")).strip().lower()
    return val not in {"0", "false", "no", "off"}


def _stable_blob(value: Any) -> bytes:
    try:
        return json.dumps(value, ensure_ascii=False, sort_keys=True, default=str).encode("utf-8")
    except Exception:
        return str(value).encode("utf-8", errors="replace")


def _seed(ctx: Mapping[str, Any] | None, label: str) -> int:
    safe_ctx = {}
    for k in ("model_id", "model_type", "client_version", "tier", "paid_mode", "route", "phase", "selector", "target_role"):
        if ctx and ctx.get(k) is not None:
            safe_ctx[k] = str(ctx.get(k))[:120]
    # session salt is local only and intentionally not returned.
    local = {
        "ctx": safe_ctx,
        "label": label,
        "salt": os.getenv("META13_PUBLIC_PROJECTOR_SALT", "meta13-public-projector-v1"),
    }
    return int.from_bytes(hashlib.blake2s(_stable_blob(local), digest_size=8).digest(), "big")


def bucket_from_percent(percent: int) -> str:
    try:
        p = int(percent)
    except Exception:
        p = 50
    if p >= 76:
        return "high"
    if p >= 46:
        return "mid"
    return "low"


def _signal_to_int(value: Any, fallback: int = 0) -> int:
    if value is None:
        return fallback
    if isinstance(value, bool):
        return 31 if value else 7
    if isinstance(value, (int, float)):
        # Do not pass raw float through.  Quantize immediately.
        return int(abs(float(value)) * 997) % 101
    s = str(value)
    if not s:
        return fallback
    return int.from_bytes(hashlib.blake2s(s[:256].encode("utf-8", errors="replace"), digest_size=4).digest(), "big") % 101


def public_confidence(ctx: Mapping[str, Any] | None = None, signals: Iterable[Any] | None = None) -> Dict[str, Any]:
    """Return a dashboard-safe confidence projection.

    This is not a raw model confidence.  It mixes coarse signals with a stable
    local salt and emits a rounded public value only.
    """
    sigs = list(signals or [])
    seed = _seed(ctx, "confidence")
    acc = (seed % 37) + 31
    for i, sig in enumerate(sigs[:12]):
        lane = ((seed >> ((i % 8) * 8)) & 0xFF) or 1
        acc += ((_signal_to_int(sig, lane) * ((lane % 7) + 1)) + lane) % 101
    # Keep public percent plausible and coarse; no 1:1 mapping to raw scores.
    pct = 35 + (acc % 61)
    pct = int(round(pct / 2.0) * 2)
    return {
        "confidence_percent": pct,
        "confidence_bucket": bucket_from_percent(pct),
        "public_metric": True,
    }


def public_focus(ctx: Mapping[str, Any] | None = None, *, role: str = "unknown", changed: Any = None, condition_passed: Any = None, selector: str | None = None) -> Dict[str, Any]:
    sigs = [role, changed, condition_passed, selector, ctx.get("route") if isinstance(ctx, Mapping) else None]
    p = public_confidence({**(dict(ctx or {})), "target_role": role, "selector": selector or ""}, sigs)
    return {
        "focus_bucket": p["confidence_bucket"],
        "focus_percent": p["confidence_percent"],
        "confidence_bucket": p["confidence_bucket"],
        "confidence_percent": p["confidence_percent"],
        "target_role": role or "unknown",
        "public_safe": True,
    }


def strength_bucket(value: Any = None, *, ctx: Mapping[str, Any] | None = None) -> str:
    p = public_confidence(ctx, [value]).get("confidence_percent", 50)
    return bucket_from_percent(int(p))


def redact_public_metric_payload(payload: Mapping[str, Any] | None, *, ctx: Mapping[str, Any] | None = None) -> Dict[str, Any]:
    """Convert a metric-like payload into public-safe buckets.

    Unknown payloads are reduced to route/role/changed/condition metadata plus
    projected focus/confidence.  Raw keys are deliberately omitted.
    """
    payload = dict(payload or {})
    role = str(payload.get("target_role") or payload.get("role") or payload.get("selector") or "unknown")[:80]
    selector = str(payload.get("selector") or "")[:80]
    changed = payload.get("changed")
    condition = payload.get("condition_passed")
    out = {
        "selector": selector or None,
        "target_role": role,
        "condition_passed": condition,
        "changed": changed,
    }
    out.update(public_focus(ctx or payload, role=role, changed=changed, condition_passed=condition, selector=selector))
    return {k: v for k, v in out.items() if v is not None}


# ── v1.13.4 MRI label helpers ─────────────────────────────────────────────

def public_metric_with_label(metric_id: str, bucket: str, *, paid_enabled: bool) -> Dict[str, Any]:
    """Return a public metric payload with a sober English label."""
    from .mri_metric_schema import get_label, is_visible_for_tier, locked_card
    if not is_visible_for_tier(metric_id, paid_enabled=paid_enabled):
        return locked_card(metric_id)
    return {
        "metric_id": metric_id,
        "bucket": bucket,
        "label": get_label(metric_id, bucket),
        "public_safe": True,
    }
