from __future__ import annotations

"""Public-safe redaction for dashboard/state/event APIs.

Default policy: public-safe unless META13_INTERNAL_HODGE=1 or raw=true is used
from a trusted local development session.  This module removes raw Hodge/SMAP
selector diagnostics and replaces detailed metric payloads with coarse buckets.
"""

from typing import Any, Dict, Iterable
import copy
import os

from .public_projector import internal_hodge_enabled, public_safe_enabled, redact_public_metric_payload
from .entitlement import resolve_entitlement

RAW_KEY_FRAGMENTS = (
    # Keep generic selector/scoring internals hidden.  IRSDCE public axes are
    # allowed below even when they include terms like "weight" or "basis".
    "weight", "weights", "weights_json", "weights_used", "score_component", "score_components",
    "candidate_rank", "rank_table", "raw_weight", "basis_weights", "basis_delta",
    "curvature", "boundary", "salience", "delta_logit", "delta_id", "raw_confidence",
    "attractor_score", "attn_in", "attn_out", "basis_bias", "edge_weight", "cosine",
    "logits", "hidden", "tensor", "embedding_raw",
)

# IRSDCE is a paid Whitebox MRI geometry axis in v1.13.4.  These keys are
# graphable only when paid entitlement is active; free mode redacts them.
IRSDCE_PUBLIC_KEY_FRAGMENTS = (
    "irsdce", "irs_dce", "irs", "dce",
    "irreducible_representation_shift", "dimensional_cascade",
    "irs_weight", "dce_weight", "cascade_strength", "dce_cascade_strength",
    "representation_shift", "phase_drift", "route_pressure", "basis_pressure",
    "phase_pressure", "axis_pressure", "collapse_marker", "expansion_marker",
)

# Preserve these despite containing broad fragments.
ALLOW_KEYS = {"changed", "route", "target_role", "source", "phase", "kind", "tier", "paid_mode", "paid_enabled", "hidden_size", "num_hidden_layers", "num_attention_heads", "intermediate_size"}

EVENT_GROUPS = {
    "preview": {"paid_preview", "prologue_sim_log", "prologue_compare", "prologue_event", "prologue_open"},
    "system": {"attach_started", "runtime_status", "state_write_skipped", "runtime_status_write_failed", "freeze_wait", "freeze_enter", "freeze_exit"},
}


def should_redact(raw: bool = False) -> bool:
    if raw and internal_hodge_enabled():
        return False
    return public_safe_enabled()


def _is_irsdce_public_key(key: str) -> bool:
    """IRSDCE key passthrough is paid-only in v1.13.4."""
    try:
        ent = resolve_entitlement()
        if not ent.paid_enabled:
            return False
    except Exception:
        return False
    lk = str(key).lower()
    return any(frag in lk for frag in IRSDCE_PUBLIC_KEY_FRAGMENTS)


def _is_raw_key(key: str) -> bool:
    lk = str(key).lower()
    if lk in ALLOW_KEYS:
        return False
    # v1.13.4 hotfix: paid 모드에서만 IRSDCE 키를 화이트리스트로 통과시킨다.
    # free 모드에서는 IRSDCE 키도 차단되어야 한다 (보안 정책 변경: free 노출 → paid 한정).
    # 단, 해당 키가 IRSDCE 키이면 RAW_KEY_FRAGMENTS 매칭과 무관하게 차단해야 하므로
    # 아래 두 단계로 처리한다.
    is_irsdce = any(frag in lk for frag in IRSDCE_PUBLIC_KEY_FRAGMENTS)
    if is_irsdce:
        # paid 통과 시 redact 안 함, free 에서는 redact (= raw key 로 분류)
        try:
            ent = resolve_entitlement()
            if ent.paid_enabled:
                return False  # paid: IRSDCE 키 통과
        except Exception:
            pass
        return True  # free: IRSDCE 키 차단
    return any(frag in lk for frag in RAW_KEY_FRAGMENTS)


def _redact_value(value: Any, *, ctx: Dict[str, Any] | None = None) -> Any:
    if isinstance(value, dict):
        return redact_dict(value, ctx=ctx)
    if isinstance(value, list):
        return [_redact_value(v, ctx=ctx) for v in value[:200]]
    return value


def redact_dict(data: Dict[str, Any], *, ctx: Dict[str, Any] | None = None) -> Dict[str, Any]:
    ctx = ctx or data
    out: Dict[str, Any] = {}
    for k, v in (data or {}).items():
        if _is_raw_key(k):
            continue
        if k == "meta" and isinstance(v, dict):
            safe_meta = redact_public_metric_payload(v, ctx={**ctx, **data})
            out["public_meta"] = safe_meta
            continue
        if k == "features" and isinstance(v, dict):
            out["public_features"] = redact_public_metric_payload(v, ctx={**ctx, **data})
            continue
        out[k] = _redact_value(v, ctx=ctx)
    out.setdefault("public_safe", True)
    return out


def event_group(event: Dict[str, Any]) -> str:
    k = str((event or {}).get("kind") or "")
    if k in EVENT_GROUPS["preview"] or (event or {}).get("preview_only") or (event or {}).get("actual_model_event") is False:
        return "preview"
    if k in EVENT_GROUPS["system"] or k.endswith("_skipped") or "status" in k:
        return "system"
    return "actual"


def redact_event(event: Dict[str, Any], *, raw: bool = False) -> Dict[str, Any]:
    ev = copy.deepcopy(event or {})
    if not should_redact(raw):
        ev["event_group"] = event_group(ev)
        return ev
    red = redact_dict(ev, ctx=ev)
    red["event_group"] = event_group(ev)
    return red


def redact_events(events: Iterable[Dict[str, Any]], *, raw: bool = False, group: str | None = None) -> list[Dict[str, Any]]:
    rows = []
    for ev in events or []:
        red = redact_event(ev, raw=raw)
        if group and group != "all" and red.get("event_group") != group:
            continue
        rows.append(red)
    return rows


def redact_state(state: Dict[str, Any], *, raw: bool = False) -> Dict[str, Any]:
    st = copy.deepcopy(state or {})
    if not should_redact(raw):
        st.setdefault("public_safe", False)
        return st
    return redact_dict(st, ctx=st)
