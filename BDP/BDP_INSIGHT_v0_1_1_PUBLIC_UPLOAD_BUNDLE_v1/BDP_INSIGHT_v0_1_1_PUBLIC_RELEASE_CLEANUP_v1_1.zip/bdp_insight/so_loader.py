"""
so_loader.py — ephemeral native library loader (v0.4)
======================================================

The loader is entered through EphemeralBlob.consume() / EphemeralFunctionLease.
It removes the normal ownership path: no public raw bytes, no persistent cache,
and best-effort zero/delete cleanup.

Linux uses memfd_create when available. Other platforms fall back to a temporary
file that is immediately unlinked where possible and zero-deleted on cleanup.
Windows native in-memory DLL loading is intentionally marked as experimental;
for MVP, Linux .so ephemeral lease is the primary path.
"""
from __future__ import annotations

import ctypes
import gc
import logging
import os
import platform
import signal
import sys
import tempfile
import threading
import time
from pathlib import Path
from typing import Any, Optional

logger = logging.getLogger("meta13.so_loader")

_IS_WINDOWS = platform.system() == "Windows"
_IS_LINUX = platform.system() == "Linux"
_SIGNAL_LOCK = threading.RLock()


class SoLoader:
    """
    One-shot native library loader.

    Direct construction is allowed only for test/internal compatibility, but a
    warning is emitted unless _from_ephemeral=True.
    """

    def __init__(self, op: str, blob: bytes, *, _from_ephemeral: bool = False):
        if not _from_ephemeral:
            logger.warning(
                "[so_loader] direct construction detected; use EphemeralFunctionLease/"
                "EphemeralBlob.consume() for the safe v0.4 flow."
            )
        self.op = op
        self._blob = bytearray(blob)
        del blob
        self._lib: Optional[ctypes.CDLL] = None
        self._tmpfile: Optional[str] = None
        self._fd: Optional[int] = None
        self._t_load: float = 0.0
        self._cleared: bool = False
        self._signal_installed: bool = False
        self._prev_sigterm = None
        self._prev_sigint = None
        self._install_signal_handlers_if_safe()

    def __enter__(self) -> "SoLoader":
        self._load()
        return self

    def __exit__(self, *_):
        self._clear()

    # ── signal cleanup ───────────────────────────────────────────────────
    def _install_signal_handlers_if_safe(self) -> None:
        # signal.signal only works in the main thread. Avoid breaking worker
        # threads used by notebooks, web apps, or UI runtimes.
        if threading.current_thread() is not threading.main_thread():
            logger.debug("[so_loader] skip signal handlers outside main thread")
            return
        try:
            with _SIGNAL_LOCK:
                self._prev_sigterm = signal.getsignal(signal.SIGTERM)
                self._prev_sigint = signal.getsignal(signal.SIGINT)
                signal.signal(signal.SIGTERM, self._emergency_clear)
                signal.signal(signal.SIGINT, self._emergency_clear)
                self._signal_installed = True
        except Exception as exc:
            logger.debug("[so_loader] signal handler install skipped: %s", exc)

    def _restore_signal_handlers(self) -> None:
        if not self._signal_installed:
            return
        if threading.current_thread() is not threading.main_thread():
            return
        try:
            with _SIGNAL_LOCK:
                signal.signal(signal.SIGTERM, self._prev_sigterm)
                signal.signal(signal.SIGINT, self._prev_sigint)
        except Exception:
            pass
        self._signal_installed = False

    # ── load ──────────────────────────────────────────────────────────────
    def _load(self) -> None:
        self._t_load = time.perf_counter()
        if _IS_LINUX:
            try:
                self._load_via_memfd()
                return
            except Exception as exc:
                logger.debug("[so_loader] memfd path unavailable for op=%s: %s", self.op, exc)
        self._load_via_tmpfile()

    def _load_via_memfd(self) -> None:
        if not hasattr(os, "memfd_create"):
            raise RuntimeError("os.memfd_create unavailable")
        fd = os.memfd_create("m13_ephemeral", flags=getattr(os, "MFD_CLOEXEC", 0x0001))
        self._fd = fd
        try:
            os.write(fd, bytes(self._blob))
            os.lseek(fd, 0, os.SEEK_SET)
            path = f"/proc/self/fd/{fd}"
            self._lib = ctypes.CDLL(path)
            logger.debug("[so_loader] loaded via memfd op=%s size=%d", self.op, len(self._blob))
        except Exception:
            self._close_fd()
            raise

    def _load_via_tmpfile(self) -> None:
        suffix = ".dll" if _IS_WINDOWS else ".so"
        tmp = tempfile.NamedTemporaryFile(
            suffix=suffix,
            delete=False,
            prefix="m13_ephemeral_",
            dir=tempfile.gettempdir(),
        )
        self._tmpfile = tmp.name
        try:
            tmp.write(bytes(self._blob))
            tmp.flush()
            tmp.close()
            self._lib = ctypes.CDLL(self._tmpfile)
            # POSIX: loaded library keeps the inode, so unlink path immediately.
            if not _IS_WINDOWS:
                try:
                    os.unlink(self._tmpfile)
                    logger.debug("[so_loader] tmp path unlinked immediately op=%s", self.op)
                    self._tmpfile = None
                except Exception as exc:
                    logger.warning("[so_loader] immediate unlink failed: %s", exc)
            logger.debug("[so_loader] loaded via tmpfile op=%s size=%d", self.op, len(self._blob))
        except Exception:
            try:
                tmp.close()
            except Exception:
                pass
            self._clear()
            raise

    # ── call ──────────────────────────────────────────────────────────────
    def call(self, fn_name: str = "run", *args: Any, **kwargs: Any) -> Any:
        if self._lib is None or self._cleared:
            raise RuntimeError(f"[so_loader] library not loaded or already cleared: op={self.op}")
        fn = getattr(self._lib, fn_name, None)
        if fn is None:
            raise AttributeError(f"[so_loader] {fn_name!r} not exported by op={self.op}")
        if kwargs:
            logger.debug("[so_loader] kwargs ignored by raw ctypes call: %s", sorted(kwargs.keys()))
        logger.debug("[so_loader] call op=%s fn=%s", self.op, fn_name)
        return fn(*args)

    # ── cleanup ───────────────────────────────────────────────────────────
    def _close_fd(self) -> None:
        if self._fd is not None:
            try:
                os.close(self._fd)
            except Exception:
                pass
            self._fd = None

    def _zero_tmpfile_then_delete(self) -> None:
        if not self._tmpfile:
            return
        path = Path(self._tmpfile)
        if path.exists():
            try:
                size = path.stat().st_size
                with open(path, "r+b", buffering=0) as f:
                    f.write(b"\x00" * size)
                    try:
                        f.flush()
                        os.fsync(f.fileno())
                    except Exception:
                        pass
                os.unlink(path)
                logger.debug("[so_loader] tmpfile zero+deleted path=%s", path)
            except Exception as exc:
                logger.warning("[so_loader] tmpfile cleanup warning path=%s err=%s", path, exc)
        self._tmpfile = None

    def _zero_blob(self) -> None:
        if self._blob:
            try:
                ctypes.memset((ctypes.c_char * len(self._blob)).from_buffer(self._blob), 0, len(self._blob))
            except Exception:
                for i in range(len(self._blob)):
                    self._blob[i] = 0
            self._blob = bytearray()

    def _clear(self) -> None:
        if self._cleared:
            return
        self._cleared = True
        if self._lib is not None:
            try:
                del self._lib
            except Exception as exc:
                logger.debug("[so_loader] lib del warning: %s", exc)
            self._lib = None
        self._close_fd()
        self._zero_tmpfile_then_delete()
        self._zero_blob()
        gc.collect()
        elapsed = round(time.perf_counter() - self._t_load, 4) if self._t_load else 0.0
        logger.info("[so_loader] clear complete op=%s held=%.4fs", self.op, elapsed)
        self._restore_signal_handlers()

    def _emergency_clear(self, signum, frame):
        logger.warning("[so_loader] emergency clear signal=%s op=%s", signum, self.op)
        self._clear()
        prev = self._prev_sigterm if signum == signal.SIGTERM else self._prev_sigint
        if callable(prev):
            prev(signum, frame)
        else:
            sys.exit(0)

    def __del__(self):
        if not getattr(self, "_cleared", True):
            self._clear()
