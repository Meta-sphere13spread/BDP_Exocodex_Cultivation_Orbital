"""BDP Insight Streamlit studio (Prototype).

Static / historical visualisation of the 5 intervention indicators.

Run with the installed entry-point script:
    bdp-insight-studio

Or directly with Streamlit:
    streamlit run -m bdp_insight.studio.app

Or, by file path:
    streamlit run $(python -c "from bdp_insight.studio import _app_path; print(_app_path())")
"""
from __future__ import annotations

import os
import sys
from pathlib import Path


def _app_path() -> str:
    """Return absolute path to studio/app.py — useful for `streamlit run`."""
    return str(Path(__file__).resolve().parent / "app.py")


def run_streamlit() -> int:
    """Console-script entry point: launches Streamlit on the studio app.

    Used by ``bdp-insight-studio`` after ``pip install bdp-insight[studio]``.
    """
    try:
        import streamlit.web.cli as stcli  # type: ignore
    except ImportError:
        sys.stderr.write(
            "[bdp_insight] Streamlit is not installed.\n"
            "  Install with: pip install 'bdp-insight[studio]'\n"
        )
        return 1

    app_path = _app_path()
    if not os.path.isfile(app_path):
        sys.stderr.write(
            f"[bdp_insight] studio/app.py not found at: {app_path}\n"
        )
        return 2

    # Streamlit 의 click CLI 를 직접 호출 (sys.exit 없이 return 으로 마무리)
    sys.argv = ["streamlit", "run", app_path]
    try:
        stcli.main(standalone_mode=False)
        return 0
    except SystemExit as exc:
        return int(exc.code or 0)


__all__ = ["_app_path", "run_streamlit"]
