"""Common helpers for the BDP Insight Streamlit studio.

This file is intentionally framework-agnostic where possible — the only
Streamlit calls live in `app.py` and the tab modules.  Indicator
computation and event loading are pure Python here so they remain unit-
testable without a Streamlit runtime.
"""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional

from bdp_insight import InterventionEvent, normalize_event
from bdp_insight.indicators import (
    compute_surgery_impact,
    compute_dependency_shift,
    compute_stale_reasoning,
    compute_continuation_recond,
    compute_intervention_timeline,
)


def _debug(marker: str, **kw: Any) -> None:
    if os.environ.get("BDP_INSIGHT_DEBUG", "").strip() not in ("1", "true", "yes"):
        return
    parts = [f"{k}={v!r}" for k, v in kw.items()]
    print(f"[BDP_INSIGHT_STUDIO {marker}] " + " ".join(parts), file=sys.stderr)


# ──────────────────────────────────────────────────────────────────────
# Event loading
# ──────────────────────────────────────────────────────────────────────

def load_events_from_jsonl(path: str) -> List[InterventionEvent]:
    """Load and normalise events from a JSONL file.

    Each line is one JSON object.  Lines that fail to parse are skipped
    with a debug marker, never raised — a single bad line should not
    break a multi-thousand-event session.
    """
    p = Path(path)
    if not p.is_file():
        _debug("load.no_file", path=str(p))
        return []

    out: List[InterventionEvent] = []
    skipped = 0
    with p.open("r", encoding="utf-8") as f:
        for i, line in enumerate(f):
            line = line.strip()
            if not line:
                continue
            try:
                row = json.loads(line)
            except json.JSONDecodeError as exc:
                skipped += 1
                _debug("load.bad_line", i=i, err=type(exc).__name__)
                continue
            try:
                ev = normalize_event(row)
                out.append(ev)
            except Exception as exc:
                skipped += 1
                _debug("load.normalize_failed", i=i, err=type(exc).__name__)

    _debug("load.done", path=str(p), n=len(out), skipped=skipped)
    return out


def load_events_from_iterable(rows: Iterable[Dict[str, Any]]) -> List[InterventionEvent]:
    """Normalise an in-memory iterable of dicts into InterventionEvents."""
    out: List[InterventionEvent] = []
    for r in rows:
        try:
            out.append(normalize_event(r))
        except Exception:
            continue
    return out


# ──────────────────────────────────────────────────────────────────────
# Indicator bundle (5 in one shot)
# ──────────────────────────────────────────────────────────────────────

def compute_all_indicators(
    events: List[InterventionEvent],
    *,
    selected_index: Optional[int] = None,
) -> Dict[str, Any]:
    """Run all 5 indicators on a list of events.

    Args:
        events: Full list of InterventionEvents (chronological order
            doesn't matter — Indicator 5 sorts internally).
        selected_index: If given, indicators 1–4 are computed for
            `events[selected_index]`.  Otherwise the latest event is used.

    Returns:
        {
          "surgery_impact":        {...} | None,
          "dependency_shift":      {...} | None,
          "stale_reasoning":       {...} | None,
          "continuation_recond":   {...} | None,
          "intervention_timeline": {...},
          "n_events": int,
          "selected_event":        InterventionEvent | None,
        }
    """
    if not events:
        empty_tl = compute_intervention_timeline([])
        return {
            "surgery_impact": None,
            "dependency_shift": None,
            "stale_reasoning": None,
            "continuation_recond": None,
            "intervention_timeline": empty_tl,
            "n_events": 0,
            "selected_event": None,
        }

    # Indicator 5 (timeline) handles its own chronological ordering
    timeline = compute_intervention_timeline(events)

    if selected_index is None:
        # latest = timeline newest (already desc-sorted)
        latest_item = timeline.get("newest")
        if latest_item is None:
            selected = events[-1]
        else:
            # find the InterventionEvent matching newest's ts
            target_ts = latest_item["ts"]
            selected = next(
                (e for e in events if abs(e.ts - target_ts) < 1e-6),
                events[-1],
            )
    else:
        idx = max(0, min(selected_index, len(events) - 1))
        selected = events[idx]

    return {
        "surgery_impact": compute_surgery_impact(selected),
        "dependency_shift": compute_dependency_shift(selected),
        "stale_reasoning": compute_stale_reasoning(selected),
        "continuation_recond": compute_continuation_recond(selected),
        "intervention_timeline": timeline,
        "n_events": len(events),
        "selected_event": selected,
    }


# ──────────────────────────────────────────────────────────────────────
# Sample events (for "demo session" without a real capture file)
# ──────────────────────────────────────────────────────────────────────

def sample_events() -> List[InterventionEvent]:
    """Return a small fixed set of InterventionEvents for first-run demos.

    These match the canonical test cases in tests/test_indicators.py:
        1) L1 prompt rewrite                    Stable
        2) L2 token swap (2→9, 7→14)           Stable / Recomputed
        3) L2 Hodge output intercept           STALE  ★ user-emphasised
        4) NNsight activation patch (external)  Reconditioned
    """
    import time
    base_ts = time.time() - 600
    return [
        InterventionEvent(
            source_tool="meta13_l1", intervention_type="rewrite_prompt",
            target_kind="prompt", target_ref="prompt[full]",
            before_value="original prompt", after_value="improved prompt",
            status="applied", actual_model_event=True, ts=base_ts + 60,
        ),
        InterventionEvent(
            source_tool="meta13_l2_token_surgery", intervention_type="token_swap",
            target_kind="token", target_ref="token[0]",
            before_value="2", after_value="9",
            before_output_preview="2 + 5 = 7",
            after_output_preview="9 + 5 = 14",
            status="applied", actual_model_event=True, ts=base_ts + 120,
        ),
        InterventionEvent(
            source_tool="meta13_l2_hodge_output_intercept",
            intervention_type="hodge_output_intercept",
            target_kind="output_prefix", target_ref="output[after_equals]",
            before_value="7", after_value="99",
            before_output_preview="3 + 4 = 7, then add 5 = 12",
            after_output_preview="3 + 4 = 99, then add 5 = 12",
            status="applied", actual_model_event=True, ts=base_ts + 240,
        ),
        InterventionEvent(
            source_tool="nnsight", intervention_type="activation_patch",
            target_kind="residual", target_ref="layer[12].head[5]",
            before_value="hidden_old", after_value="hidden_new",
            before_output_preview="The capital of France is Paris.",
            after_output_preview="The capital of France is London.",
            status="applied", actual_model_event=True, ts=base_ts + 360,
        ),
    ]


# ──────────────────────────────────────────────────────────────────────
# Streaming: tail-load events.jsonl with offset bookkeeping
# ──────────────────────────────────────────────────────────────────────

def stream_events_since(
    path: str,
    last_offset: int = 0,
    *,
    max_new_lines: int = 5000,
    m13_filter: bool = False,
) -> Dict[str, Any]:
    """Read NEW lines appended to events.jsonl since `last_offset` (bytes).

    Returns:
        {
            "events":      [InterventionEvent ...],
            "new_offset":  int,         # next call's last_offset
            "rotated":     bool,        # file shrank/replaced
            "n_skipped":   int,         # bad lines silently skipped
        }

    This is the function the studio app calls every poll tick (5 s).
    The first call passes last_offset=0 to load everything; subsequent
    calls pass back the returned new_offset.

    Bad/incomplete lines are skipped — a partial last line is treated as
    "not yet committed" and left for the next poll tick (the new_offset
    points to the start of the partial line, so it'll be re-read).
    """
    p = Path(path)
    if not p.is_file():
        _debug("stream.no_file", path=str(p))
        return {"events": [], "new_offset": last_offset, "rotated": False,
                "n_skipped": 0}

    try:
        size = p.stat().st_size
    except OSError as exc:
        _debug("stream.stat_failed", path=str(p), err=type(exc).__name__)
        return {"events": [], "new_offset": last_offset, "rotated": False,
                "n_skipped": 0}

    rotated = False
    if size < last_offset:
        # file was truncated / replaced — re-read from start
        rotated = True
        last_offset = 0

    if size == last_offset:
        return {"events": [], "new_offset": size, "rotated": rotated,
                "n_skipped": 0}

    new_events: List[InterventionEvent] = []
    skipped = 0
    next_offset = size
    try:
        with p.open("rb") as f:
            f.seek(last_offset)
            buf = f.read(max(0, size - last_offset))
        text = buf.decode("utf-8", errors="replace")

        # Split — keep last partial line for the next tick
        lines = text.split("\n")
        if not text.endswith("\n") and lines:
            # last item is a partial line — back off so we re-read it
            partial = lines.pop().encode("utf-8", errors="replace")
            next_offset = size - len(partial)

        for i, line in enumerate(lines):
            if i >= max_new_lines:
                # cap — leave the rest for next poll
                # offset must point to the start of line[i]
                consumed_text = "\n".join(lines[:i]) + ("\n" if i > 0 else "")
                next_offset = last_offset + len(
                    consumed_text.encode("utf-8", errors="replace")
                )
                _debug("stream.cap_hit", processed=i, remaining=len(lines) - i)
                break
            line = line.strip()
            if not line:
                continue
            try:
                row = json.loads(line)
                # Optional: skip M13 v1.13.4 book-keeping rows.
                # When m13_filter=True, checkpoint / freeze_* / paid_command_accepted
                # are dropped so the studio shows only real interventions.
                if m13_filter:
                    from bdp_insight.bridge.m13 import (
                        _M13_IGNORED_KINDS, m13_event_to_intervention_event,
                    )
                    if isinstance(row, dict) and row.get("kind") in _M13_IGNORED_KINDS:
                        continue
                    ev = m13_event_to_intervention_event(row)
                    if ev is None:
                        continue
                else:
                    ev = normalize_event(row)
                new_events.append(ev)
            except Exception:
                skipped += 1
                continue
    except OSError as exc:
        _debug("stream.read_failed", path=str(p), err=type(exc).__name__)
        return {"events": [], "new_offset": last_offset, "rotated": rotated,
                "n_skipped": 0}

    _debug("stream.ok",
           path=str(p),
           new=len(new_events),
           skipped=skipped,
           offset_before=last_offset,
           offset_after=next_offset,
           rotated=rotated)
    return {
        "events":     new_events,
        "new_offset": next_offset,
        "rotated":    rotated,
        "n_skipped":  skipped,
    }


# ──────────────────────────────────────────────────────────────────────
# Results-tree scanning: list candidate run dirs / events.jsonl files
# ──────────────────────────────────────────────────────────────────────

def scan_results_tree(root: str) -> Dict[str, List[Dict[str, Any]]]:
    """Scan a results/ root for candidate dynamic_debug + capture trees.

    Returns:
        {
          "events_files":  [{path, run_dir, size, mtime} ...],
          "capture_runs":  [{path, run_id, mtime, has_result_minimal} ...],
        }

    Used by the studio sidebar's file picker — newest-first.
    """
    rt = Path(root)
    out_events: List[Dict[str, Any]] = []
    out_caps:   List[Dict[str, Any]] = []
    if not rt.is_dir():
        _debug("scan.no_root", path=str(rt))
        return {"events_files": [], "capture_runs": []}

    # Look for dynamic_debug/events.jsonl up to depth 4
    for ev in rt.rglob("dynamic_debug/events.jsonl"):
        try:
            stat = ev.stat()
        except OSError:
            continue
        out_events.append({
            "path":     str(ev.resolve()),
            "run_dir":  str(ev.parent.parent.resolve()),
            "size":     stat.st_size,
            "mtime":    stat.st_mtime,
        })

    # Capture runs: any subdir containing a result_minimal.json or
    # capture_index.json.  We look 2-3 levels deep to keep the scan cheap.
    for cap in rt.rglob("result_minimal.json"):
        try:
            stat = cap.stat()
        except OSError:
            continue
        run_dir = cap.parent
        out_caps.append({
            "path":               str(run_dir.resolve()),
            "run_id":             run_dir.name,
            "mtime":              stat.st_mtime,
            "has_result_minimal": True,
        })

    out_events.sort(key=lambda e: e["mtime"], reverse=True)
    out_caps.sort(key=lambda c: c["mtime"], reverse=True)
    _debug("scan.ok",
           n_events=len(out_events), n_caps=len(out_caps))
    return {"events_files": out_events, "capture_runs": out_caps}
