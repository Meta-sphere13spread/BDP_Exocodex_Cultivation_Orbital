"""BDP Insight Studio — Streamlit application (Prototype).

Run with:
    streamlit run studio/app.py

Or after `pip install bdp-insight[studio]`:
    python -m streamlit run -m bdp_insight.studio.app

The studio loads intervention events from one of:
    1. An uploaded events.jsonl file (preferred for real sessions)
    2. A path entered manually in the sidebar
    3. A built-in sample session (demo, 4 events including the canonical
       stale case used in the project's test suite)

Five tabs render the 5 indicators.  All values are bucketed natural-
language labels; raw scores / weights / tensors are never exposed.
"""
from __future__ import annotations

import sys
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

try:
    import streamlit as st
except ImportError as exc:  # pragma: no cover
    print(
        "[BDP_INSIGHT] Streamlit is not installed.  "
        "Install with: pip install bdp-insight[studio]",
        file=sys.stderr,
    )
    raise


def _short_age(mtime: float) -> str:
    """Return a short '5s ago / 3m ago / 2h ago' string for a UNIX mtime."""
    age = time.time() - mtime
    if age < 0:
        return "future?"
    if age < 60:
        return f"{int(age)}s ago"
    if age < 3600:
        return f"{int(age // 60)}m ago"
    if age < 86400:
        return f"{int(age // 3600)}h ago"
    return f"{int(age // 86400)}d ago"



# ──────────────────────────────────────────────────────────────────────
# M13 prompt / command / result trace panel for static Studio
# ──────────────────────────────────────────────────────────────────────

def _bdp_read_jsonl_tail(path: str | None, *, limit: int = 80) -> List[Dict[str, Any]]:
    """Read a public-debug tail from JSONL without throwing.

    This is intentionally UI-only: it does not alter events, commands, or
    capture files. It lets the static Streamlit dashboard show the same user
    context that the dynamic debugger already writes: prompt preview, queued
    command payload, and applied/noop result.
    """
    if not path:
        return []
    p = Path(path)
    if not p.is_file():
        return []
    rows: List[Dict[str, Any]] = []
    try:
        for line in p.read_text(encoding="utf-8", errors="replace").splitlines()[-limit:]:
            line = line.strip()
            if not line:
                continue
            try:
                obj = __import__('json').loads(line)
                if isinstance(obj, dict):
                    rows.append(obj)
            except Exception:
                continue
    except Exception:
        return []
    return rows


def _bdp_safe_preview(value: Any, limit: int = 360) -> str:
    if value is None:
        return ""
    try:
        text = str(value)
    except Exception:
        return ""
    text = text.replace("\r", " ").strip()
    return text[:limit]


def _bdp_public_payload(payload: Any) -> Dict[str, Any]:
    """Keep user command fields, drop nothing essential for UI debugging.

    The user specifically wants to see *what command modified what*. We still
    bound long values and avoid showing model/tensor internals.
    """
    if not isinstance(payload, dict):
        return {}
    out: Dict[str, Any] = {}
    allow = {
        "old_word", "new_word", "position", "mode", "selector",
        "target_regex", "after_tokens", "continuation_tokens",
        "magnitude", "note", "value", "replacement",
    }
    for k, v in payload.items():
        if str(k) not in allow:
            continue
        if isinstance(v, (dict, list, tuple)):
            out[str(k)] = _bdp_safe_preview(v, 220)
        else:
            out[str(k)] = _bdp_safe_preview(v, 220)
    return out


def _bdp_find_latest_prompt(rows: List[Dict[str, Any]]) -> str:
    for row in reversed(rows):
        if row.get("prompt_preview"):
            return _bdp_safe_preview(row.get("prompt_preview"), 500)
        extra = row.get("extra") if isinstance(row.get("extra"), dict) else {}
        if extra.get("prompt_preview"):
            return _bdp_safe_preview(extra.get("prompt_preview"), 500)
    return ""


def _bdp_result_row(row: Dict[str, Any]) -> Dict[str, Any]:
    meta = row.get("meta") if isinstance(row.get("meta"), dict) else {}
    return {
        "kind": _bdp_safe_preview(row.get("kind"), 80),
        "function_id": _bdp_safe_preview(row.get("function_id"), 80),
        "op": _bdp_safe_preview(row.get("op"), 80),
        "route": _bdp_safe_preview(row.get("route"), 100),
        "changed": row.get("changed", ""),
        "source": _bdp_safe_preview(row.get("source"), 80),
        "paid_mode": _bdp_safe_preview(row.get("paid_mode"), 80),
        "prompt_before": _bdp_safe_preview(row.get("prompt_preview") or row.get("prompt_before_preview"), 260),
        "prompt_after": _bdp_safe_preview(row.get("prompt_after_preview"), 260),
        "before": _bdp_safe_preview(meta.get("old_word_preview") or meta.get("old_text_preview") or row.get("before_value"), 120),
        "after": _bdp_safe_preview(meta.get("new_word_preview") or meta.get("new_text_preview") or row.get("after_value"), 120),
        "result": _bdp_safe_preview(meta.get("modified_partial_preview") or row.get("answer_preview") or row.get("after_output_preview"), 260),
        "reason": _bdp_safe_preview(meta.get("reason") or row.get("error"), 220),
    }


def _bdp_command_row(row: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "id": _bdp_safe_preview(row.get("id"), 80),
        "op": _bdp_safe_preview(row.get("op"), 80),
        "payload": _bdp_public_payload(row.get("payload")),
    }


def _bdp_render_prompt_command_result_panel(st: Any, selected_events_path: Optional[str]) -> None:
    """Render the missing static-dashboard context: prompt, command, result."""
    if not selected_events_path:
        return

    ev_path = Path(selected_events_path)
    dbg_dir = ev_path.parent
    cmd_path = dbg_dir / "commands.jsonl"

    raw_events = _bdp_read_jsonl_tail(str(ev_path), limit=140)
    raw_cmds = _bdp_read_jsonl_tail(str(cmd_path), limit=40)

    prompt = _bdp_find_latest_prompt(raw_events)
    cmd_rows = [_bdp_command_row(r) for r in raw_cmds[-10:]]
    result_rows = [
        _bdp_result_row(r)
        for r in raw_events
        if str(r.get("kind", "")) in {
            "l1_prompt_rewrite_applied",
            "l1_mid_rewrite_partial_generated",
            "paid_surgery_applied",
            "paid_surgery_noop",
            "paid_output_intercept_applied",
            "paid_output_intercept_noop",
            "blocked_command",
            "paid_surgery_blocked_late",
        }
    ][-12:]

    st.markdown("### Prompt / Command / Result Trace")
    st.caption(
        "정적 디버거용 공개 추적 패널입니다. 동적 대시보드에서 큐에 넣은 명령, "
        "그때 보인 프롬프트 preview, 적용/미적용 결과 이벤트를 함께 보여줍니다."
    )

    c1, c2, c3 = st.columns(3)
    with c1:
        st.metric("prompt", "present" if prompt else "missing")
    with c2:
        st.metric("commands", len(cmd_rows))
    with c3:
        st.metric("results", len(result_rows))

    with st.expander("Current / latest prompt preview", expanded=bool(prompt)):
        if prompt:
            st.code(prompt, language="text")
        else:
            st.info("아직 events.jsonl의 checkpoint/before_generate 행에서 prompt_preview를 찾지 못했습니다.")

    with st.expander("Queued modification commands", expanded=bool(cmd_rows)):
        if cmd_rows:
            st.dataframe(cmd_rows, hide_index=True, use_container_width=True)
        else:
            st.info("commands.jsonl에 표시할 명령이 아직 없습니다.")

    with st.expander("Applied / noop surgery results", expanded=bool(result_rows)):
        if result_rows:
            st.dataframe(result_rows, hide_index=True, use_container_width=True)
        else:
            st.info("아직 적용/미적용 수술 이벤트가 없습니다. 동적 대시보드에서 Run/Queue 후 다음 generate를 실행하세요.")


from bdp_insight import __version__ as _VERSION, __release_phase__ as _PHASE
from bdp_insight import InterventionEvent

# ──────────────────────────────────────────────────────────────────────
# Robust dual-mode import
# ──────────────────────────────────────────────────────────────────────
# Streamlit can be launched two ways and they have DIFFERENT import semantics:
#
#   (1) `streamlit run bdp_insight/studio/app.py`
#         → Python loads app.py as a TOP-LEVEL script.  Relative imports
#           (`from ._common import ...`) FAIL with:
#               ImportError: attempted relative import with no known parent package
#
#   (2) `python -m streamlit run bdp_insight/studio/app.py`
#         + PYTHONPATH set to the project root
#         → Python sees `bdp_insight.studio.app` as a package module and
#           relative imports work.
#
# We support BOTH by trying relative first (clean for case 2) and falling
# back to absolute imports (case 1).  Additionally, we self-heal sys.path
# by prepending the project root if it isn't already there — this lets
# the absolute-import branch find `bdp_insight` even when the user
# forgot to set PYTHONPATH.
import os as _os
import sys as _sys
from pathlib import Path as _Path

# Self-heal: ensure project root is on sys.path so `import bdp_insight`
# works even from `streamlit run path/to/app.py` without PYTHONPATH.
_HERE = _Path(__file__).resolve()
# app.py lives at <root>/bdp_insight/studio/app.py
# so the project root is parents[2]
try:
    _PROJECT_ROOT = _HERE.parents[2]
    if str(_PROJECT_ROOT) not in _sys.path:
        _sys.path.insert(0, str(_PROJECT_ROOT))
except IndexError:                                              # pragma: no cover
    pass

try:
    # Preferred path — works under `python -m streamlit run ...`
    from ._common import (
        load_events_from_jsonl,
        load_events_from_iterable,
        compute_all_indicators,
        sample_events,
        stream_events_since,
        scan_results_tree,
    )
    from ..indicators.static_capture import (
        list_capture_runs,
        compute_capture_summary,
    )
    from .tabs import (
        tab_intervention_impact,
        tab_dependency_shift,
        tab_irsdce_dynamics,
    )
    from ..indicators.irsdce_dynamics import analyze_capture_run as _analyze_irsdce
except ImportError:
    # Fallback path — works under bare `streamlit run app.py`
    from bdp_insight.studio._common import (                     # type: ignore
        load_events_from_jsonl,
        load_events_from_iterable,
        compute_all_indicators,
        sample_events,
        stream_events_since,
        scan_results_tree,
    )
    from bdp_insight.indicators.static_capture import (          # type: ignore
        list_capture_runs,
        compute_capture_summary,
    )
    from bdp_insight.studio.tabs import (                        # type: ignore
        tab_intervention_impact,
        tab_dependency_shift,
        tab_irsdce_dynamics,
    )
    from bdp_insight.indicators.irsdce_dynamics import (         # type: ignore
        analyze_capture_run as _analyze_irsdce,
    )


# ──────────────────────────────────────────────────────────────────────
# Page config
# ──────────────────────────────────────────────────────────────────────

st.set_page_config(
    page_title="BDP Insight · MRI Signal Type 1",
    page_icon="🩺",
    layout="wide",
)


# ──────────────────────────────────────────────────────────────────────
# Top banner — Prototype status (sober, sticky-ish)
# ──────────────────────────────────────────────────────────────────────

st.markdown(
    f"""
    <div style="
        background:#1c1f25; border:1px solid #4a3700;
        padding:10px 14px; border-radius:6px; margin-bottom:14px;
        font-size:13px; color:#d8dde2;">
      <strong>BDP Insight</strong>
      <span style="
        background:#4a3700; color:#ffd166; border:1px solid #634800;
        padding:1px 7px; border-radius:3px; font-size:11px;
        letter-spacing:0.4px; margin-left:6px;">PROTOTYPE</span>
      <span style="color:#8a93a0; margin-left:8px;">
        v{_VERSION} · {_PHASE}
      </span>
      <div style="color:#8a93a0; font-size:12px; margin-top:4px;">
        MRI Signal — Type 1 (Public Reference).  Static indicators only:
        OBDA / IRS-DCE / logit-lens output / attention output.  Values
        are observational labels (Detected / Stale / Reconditioned / …),
        not correctness verdicts.
      </div>
    </div>
    """,
    unsafe_allow_html=True,
)


# ──────────────────────────────────────────────────────────────────────
# Sidebar — event source
# ──────────────────────────────────────────────────────────────────────

with st.sidebar:
    st.markdown("### Event source")

    source = st.radio(
        "Where do events come from?",
        ["Sample session (demo)",
         "Auto-scan results/ tree",     # ← NEW
         "Upload events.jsonl",
         "File path"],
        index=1,                           # ← default to auto-scan (real-use priority)
        label_visibility="collapsed",
    )

    events: List[InterventionEvent] = []
    selected_events_path: Optional[str] = None
    selected_capture_run: Optional[str] = None

    # ── Auto-refresh + streaming controls ──
    st.markdown("---")
    st.markdown("### Live updates")
    auto_refresh = st.checkbox(
        "Auto-refresh every 5 s",
        value=False,
        help=(
            "When ON, the studio re-polls the selected events.jsonl "
            "every 5 seconds, streaming only NEW lines (offset-tracked). "
            "Existing indicators stay in place — only new events are added."
        ),
    )
    refresh_interval = st.number_input(
        "Refresh interval (sec)",
        min_value=2, max_value=60, value=5, step=1,
        disabled=not auto_refresh,
    )

    st.markdown("---")
    st.markdown("### Source detail")

    if source == "Sample session (demo)":
        events = sample_events()
        st.caption(
            "Built-in 4-event demo: L1 prompt rewrite, L2 token swap, "
            "L2 Hodge output intercept (canonical stale case), "
            "external NNsight activation patch."
        )

    elif source == "Auto-scan results/ tree":
        results_root = st.text_input(
            "Results root",
            value=st.session_state.get("results_root", __import__("os").environ.get("BDP_INSIGHT_RESULTS_ROOT", "results")),
            help="Recursively scans for dynamic_debug/events.jsonl + capture runs.",
        )
        st.session_state["results_root"] = results_root

        scan_now = st.button("🔍 Rescan", help="Force a rescan now")
        # Auto-rescan during Auto-refresh: every tick after `refresh_interval`
        # seconds.  This ensures new capture runs (created mid-session) and
        # newly-rotated events.jsonl files appear without manual intervention.
        last_scan_key = "scan_last_ts"
        now = time.time()
        last_scan = float(st.session_state.get(last_scan_key, 0.0))
        auto_rescan_due = (
            auto_refresh and (now - last_scan) >= float(refresh_interval)
        )
        if scan_now or auto_rescan_due or "scan_results" not in st.session_state:
            st.session_state["scan_results"] = scan_results_tree(results_root)
            st.session_state[last_scan_key] = now

        scan = st.session_state["scan_results"]
        ev_files: List[Dict[str, Any]] = scan.get("events_files", [])
        cap_runs: List[Dict[str, Any]] = scan.get("capture_runs", [])

        # Events.jsonl picker
        if ev_files:
            ev_labels = [
                f"{i:02d} · {Path(e['path']).parent.parent.name}/dynamic_debug "
                f"({e['size']} B, {_short_age(e['mtime'])})"
                for i, e in enumerate(ev_files)
            ]
            picked = st.selectbox(
                f"Events file ({len(ev_files)} found)",
                options=ev_labels,
                index=0,
                key="picked_events",
            )
            selected_events_path = ev_files[ev_labels.index(picked)]["path"]

            # Streaming offset bookkeeping in session_state ----
            offset_key = f"offset::{selected_events_path}"
            if offset_key not in st.session_state:
                st.session_state[offset_key] = 0
                st.session_state[f"buf::{selected_events_path}"] = []

            # Stream new lines since last poll
            stream = stream_events_since(
                selected_events_path,
                last_offset=st.session_state[offset_key],
                m13_filter=True,   # M13 events.jsonl: drop checkpoint / freeze_*
            )
            if stream["rotated"]:
                # file rotated/truncated — drop buffered events too
                st.session_state[f"buf::{selected_events_path}"] = []

            buf_key = f"buf::{selected_events_path}"
            buffered: List[InterventionEvent] = list(
                st.session_state.get(buf_key, [])
            )
            buffered.extend(stream["events"])
            # cap to last 5000 to bound memory
            if len(buffered) > 5000:
                buffered = buffered[-5000:]
            st.session_state[buf_key] = buffered
            st.session_state[offset_key] = stream["new_offset"]
            events = buffered

            st.caption(
                f"Loaded {len(events)} events · "
                f"+{len(stream['events'])} new this tick · "
                f"offset={stream['new_offset']:,} B"
                + (" (rotated)" if stream["rotated"] else "")
            )
        else:
            st.warning(
                f"No `dynamic_debug/events.jsonl` found under `{results_root}`."
            )

        # Capture run picker (for tab 6)
        st.markdown("---")
        st.markdown("### Capture run (for tab 6)")
        if cap_runs:
            cap_labels = [
                f"{i:02d} · {c['run_id']} ({_short_age(c['mtime'])})"
                for i, c in enumerate(cap_runs)
            ]
            picked_cap = st.selectbox(
                f"Capture run ({len(cap_runs)} found)",
                options=cap_labels,
                index=0,
                key="picked_capture_run",
            )
            selected_capture_run = cap_runs[
                cap_labels.index(picked_cap)
            ]["path"]
        else:
            st.caption("No capture runs found yet.")

    elif source == "Upload events.jsonl":
        up = st.file_uploader("Upload events.jsonl", type=["jsonl"])
        if up is not None:
            try:
                rows = []
                for line in up.read().decode("utf-8").splitlines():
                    line = line.strip()
                    if not line:
                        continue
                    import json as _json
                    try:
                        rows.append(_json.loads(line))
                    except _json.JSONDecodeError:
                        continue
                events = load_events_from_iterable(rows)
                st.success(f"Loaded {len(events)} events.")
            except Exception as exc:
                st.error(f"Could not parse upload: {exc}")

    else:  # File path
        path = st.text_input(
            "Path to events.jsonl",
            value="",
            placeholder="/abs/path/events.jsonl",
        )
        if path:
            selected_events_path = path
            offset_key = f"offset::{path}"
            if offset_key not in st.session_state:
                st.session_state[offset_key] = 0
                st.session_state[f"buf::{path}"] = []
            stream = stream_events_since(
                path, last_offset=st.session_state[offset_key],
                m13_filter=True,
            )
            if stream["rotated"]:
                st.session_state[f"buf::{path}"] = []
            buf_key = f"buf::{path}"
            buffered = list(st.session_state.get(buf_key, []))
            buffered.extend(stream["events"])
            if len(buffered) > 5000:
                buffered = buffered[-5000:]
            st.session_state[buf_key] = buffered
            st.session_state[offset_key] = stream["new_offset"]
            events = buffered
            st.caption(
                f"Loaded {len(events)} events · "
                f"+{len(stream['events'])} this tick"
            )

    st.markdown("---")
    st.markdown("### Selected event")
    if events:
        labels = []
        for i, e in enumerate(events):
            short = (e.intervention_type or "?")[:24]
            labels.append(f"{i:02d} · {short} · {e.status}")
        # newest-first is more familiar — but we keep ascending order so
        # the selected index lines up with the original event index.
        sel_label = st.selectbox(
            "Pick one for indicators 1–4",
            options=labels,
            index=len(labels) - 1,  # default = last (most recent)
        )
        sel_idx = labels.index(sel_label)
    else:
        sel_idx = None
        st.info("No events loaded.")

    st.markdown("---")
    st.caption(
        "Raw scores, weights, candidate ranks, and selector internals are "
        "NEVER displayed in this app, even with admin privileges."
    )


# ──────────────────────────────────────────────────────────────────────
# Compute indicators
# ──────────────────────────────────────────────────────────────────────

bundle = compute_all_indicators(events, selected_index=sel_idx)



# Prompt / command / result trace panel
_bdp_render_prompt_command_result_panel(st, selected_events_path)

# ──────────────────────────────────────────────────────────────────────
# 5 indicator tabs + 2 supporting tabs
# ──────────────────────────────────────────────────────────────────────

tab_titles = [
    "1 · Surgery Impact",
    "2 · Dependency Shift",
    "3 · IRS-DCE Dynamics",
]

tabs = st.tabs(tab_titles)

with tabs[0]:
    tab_intervention_impact.render(st, bundle.get("surgery_impact"))
with tabs[1]:
    tab_dependency_shift.render(st, bundle.get("dependency_shift"))

with tabs[2]:
    # IRS-DCE Dynamics tab — reads selected capture run, computes
    # CPI/EDS/CDI/AGA/BCI on the fly, renders 7 PR_s figures.
    irsdce_report = (
        _analyze_irsdce(selected_capture_run)
        if selected_capture_run else None
    )
    tab_irsdce_dynamics.render(st, irsdce_report)


# ──────────────────────────────────────────────────────────────────────
# Footer
# ──────────────────────────────────────────────────────────────────────

st.markdown(
    """
    <div style="color:#6a727f; font-size:11px; margin-top:30px;
               border-top:1px solid #2a2d33; padding-top:10px;">
      BDP Insight · MRI Signal — Type 1 (Public Reference, Prototype).
      Indicators describe <em>change</em>, not correctness.
      Variation also depends on harness, prompt template, generation
      config, and tokenizer; final interpretation is left to the user.
    </div>
    """,
    unsafe_allow_html=True,
)


# ──────────────────────────────────────────────────────────────────────
# Auto-refresh trigger (file streaming + capture rescan)
# ──────────────────────────────────────────────────────────────────────
#
# Streamlit doesn't have a built-in non-blocking "tick" without extra
# packages.  We do the cheapest thing that works: if the user opted in,
# sleep `refresh_interval` seconds and trigger a rerun.  All offset and
# scan state is in st.session_state, so the rerun resumes streaming
# (only NEW lines, no double-counting).
#
# IMPORTANT: this MUST be the very last call in the script.  Anything
# placed below it will not run on the previous tick.

if auto_refresh:
    # Mark when we last ticked so the user can verify the refresh works
    st.caption(
        f"⟳ Live · refreshing every {int(refresh_interval)} s "
        f"(last tick: {time.strftime('%H:%M:%S')})"
    )
    time.sleep(int(refresh_interval))
    # Streamlit ≥ 1.27 has st.rerun(); 1.18-1.26 has experimental_rerun()
    if hasattr(st, "rerun"):
        st.rerun()
    else:                                              # pragma: no cover
        st.experimental_rerun()
