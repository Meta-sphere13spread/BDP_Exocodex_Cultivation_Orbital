"""5 indicator visual tabs + 2 supporting tabs for the BDP Insight studio."""
