"""Tab 6 — Static Capture Summary (SMAP-style).

Ported from SMAP10_2 `tab_ai_analysis.parse_session_to_context`.

Renders geometry scalars, OBDA orthogonality state, lens attractor, and
generation outcome from a `capture_dir/<run_id>/result_minimal.json`,
WITHOUT requiring any live capture.  If no run is selected, the tab
shows an empty state with hints.

Public-safe: only rounded floats (3 dp), bucketed labels, and short
preview strings.  Never raw scores / weights / tensors.
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional


def _impact_color(state: str) -> str:
    return {
        "Stable":   "#88e09a",
        "Drifting": "#ffd166",
        "Broken":   "#ff8b8b",
        "Low":      "#88e09a",
        "Mid":      "#ffd166",
        "High":     "#ff8b8b",
    }.get(state, "#a8b3bf")


def render(st: Any, summary: Optional[Dict[str, Any]]) -> None:
    """Render the static capture summary tab.

    Args:
        st:      streamlit module (passed by app.py)
        summary: output of `compute_capture_summary(run_dir)` or None
    """
    st.subheader("6 · Static Capture Summary")
    st.caption(
        "Read-only summary of a completed capture run.  Geometry, OBDA, "
        "lens attractor — pulled from `result_minimal.json` after the "
        "fact.  No live model required."
    )

    if summary is None or not summary.get("ok"):
        st.info(
            "No capture run selected, or the run has no `result_minimal.json` "
            "yet.  Pick one from the sidebar."
        )
        return

    # ── Header line ──
    st.write(f"**{summary.get('label', '')}**")
    rm = summary.get("run_meta") or {}
    if rm.get("model"):
        meta_bits = []
        if rm.get("model"):
            meta_bits.append(f"model=`{rm['model']}`")
        if rm.get("duration_sec") is not None:
            meta_bits.append(f"{rm['duration_sec']}s")
        if rm.get("started_at"):
            meta_bits.append(f"started_at={rm['started_at']}")
        st.caption(" · ".join(meta_bits))

    # ── Geometry scalars ──
    geom = summary.get("geometry") or {}
    if any(v is not None for v in geom.values()):
        st.markdown("**Geometry**")
        cols = st.columns(4)
        with cols[0]:
            st.metric("CPI",       geom.get("cpi") or "—")
            st.caption(f"bucket: {geom.get('cpi_bucket', 'Unknown')}")
        with cols[1]:
            st.metric("EDS",       geom.get("eds") or "—")
        with cols[2]:
            st.metric("CDI",       geom.get("cdi") or "—")
        with cols[3]:
            st.metric("ω peak L",  geom.get("omega_peak_layer") or "—")
        cols2 = st.columns(3)
        with cols2[0]:
            st.metric("CPI start",     geom.get("cpi_start") or "—")
        with cols2[1]:
            st.metric("Work final",    geom.get("work_final") or "—")
        with cols2[2]:
            st.metric("AUC Δid",       geom.get("auc_delta_id") or "—")

    # ── Layer events ──
    events = summary.get("event_layers") or []
    if events:
        st.markdown(f"**Layer events** ({len(events)})")
        st.dataframe(
            [{"layer": e.get("L"), "event": e.get("event")} for e in events],
            hide_index=True, use_container_width=True,
        )

    # ── Lens attractor ──
    lens = summary.get("lens")
    if lens:
        st.markdown("**Lens attractor**")
        cols = st.columns(3)
        with cols[0]:
            st.metric("Token",       lens.get("token") or "—")
        with cols[1]:
            st.metric("First layer", lens.get("first_layer") or "—")
        with cols[2]:
            st.metric("Stability",   lens.get("stability") or "—")

    # ── OBDA orthogonality ──
    obda = summary.get("obda")
    if obda:
        st.markdown("**OBDA orthogonality**")
        cols = st.columns(4)
        state = obda.get("state", "Unknown")
        with cols[0]:
            color = _impact_color(state)
            st.markdown(
                f"<div style='font-size:13px;color:#8a93a0;'>State</div>"
                f"<div style='font-size:18px;color:{color};font-weight:600;'>"
                f"{state}</div>",
                unsafe_allow_html=True,
            )
        with cols[1]:
            st.metric("σ min",        obda.get("sigma_min") or "—")
        with cols[2]:
            st.metric("σ max",        obda.get("sigma_max") or "—")
        with cols[3]:
            st.metric("σ min layer",  obda.get("sigma_min_layer") or "—")
        breaks = obda.get("break_layers") or []
        if breaks:
            st.caption(
                f"Orthogonality break layers: "
                f"{', '.join(str(x) for x in breaks)}"
            )

    # ── Generation summary ──
    gen = summary.get("generation")
    if gen:
        st.markdown("**Generation**")
        cols = st.columns(3)
        with cols[0]:
            st.metric("steps",  gen.get("n_steps") or "—")
        with cols[1]:
            st.metric("success",
                      "✓" if gen.get("success") else
                      ("✗" if gen.get("success") is False else "—"))
        with cols[2]:
            st.metric("mode",   gen.get("mode_used") or "—")
        if gen.get("preview"):
            st.code(gen["preview"], language="text")

    # ── Raw JSON (collapsed) ──
    with st.expander("Raw indicator output (public-safe JSON)", expanded=False):
        st.json(summary)
