"""Tab 4 — Continuation Reconditioning.

Surfaces whether the continuation actually conditioned on the new prefix
after an output intercept.  States: Reconditioned / Partially reconditioned /
Stale / No hit / Not applicable.
"""
from __future__ import annotations

from typing import Any, Dict, Optional


def render(st: Any, result: Optional[Dict[str, Any]]) -> None:
    st.subheader("4 · Continuation Reconditioning")
    st.caption(
        "After an output intercept, did the model actually condition its "
        "continuation on the new prefix?"
    )

    if result is None:
        st.info("No intervention event selected.")
        return

    state = result.get("state", "Not applicable")
    cols = st.columns(2)
    with cols[0]:
        st.metric("State", state)
    with cols[1]:
        evidence = result.get("evidence") or {}
        starts = bool(evidence.get(
            "after_output_preview_starts_with_new_prefix", False
        ))
        st.metric("Starts with new prefix", "yes" if starts else "no")

    if state == "Reconditioned":
        st.success(result.get("label", ""))
    elif state == "Stale":
        st.error(result.get("label", ""))
    elif state == "Partially reconditioned":
        st.warning(result.get("label", ""))
    else:
        st.info(result.get("label", ""))

    if result.get("note"):
        st.write(result["note"])

    evidence = result.get("evidence") or {}
    if evidence.get("edited_prefix"):
        st.markdown("**Edited prefix**")
        st.code(evidence["edited_prefix"], language="text")

    with st.expander("Raw indicator output (public-safe JSON)", expanded=False):
        st.json(result)
