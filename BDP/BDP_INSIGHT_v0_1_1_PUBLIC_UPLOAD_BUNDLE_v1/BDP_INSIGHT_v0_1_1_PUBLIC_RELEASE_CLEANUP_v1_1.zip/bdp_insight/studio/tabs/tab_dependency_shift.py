"""Tab 2 — Token Dependency Shift.

Shows the small node/edge graph (with strength_bucket only — no raw weights)
plus the changed anchor and a coarse result_path bucket.
"""
from __future__ import annotations

from typing import Any, Dict, Optional


_BUCKET_TO_HEX = {
    "weak":     "#7a7e87",
    "moderate": "#c8a04a",
    "strong":   "#d96b5a",
}
_SIDE_TO_LABEL = {
    "common": "shared",
    "before": "before-only",
    "after":  "after-only",
}


def render(st: Any, result: Optional[Dict[str, Any]]) -> None:
    st.subheader("2 · Token Dependency Shift")
    st.caption(
        "Where did the dependency chain change after the edit? "
        "Edge strength is bucketed (weak / moderate / strong) — no weights."
    )

    if result is None:
        st.info("No intervention event selected.")
        return

    cols = st.columns(3)
    with cols[0]:
        st.metric("Shift", result.get("shift", "Not detected"))
    with cols[1]:
        st.metric("Result path", result.get("result_path", "Unknown"))
    with cols[2]:
        st.metric("Changed anchor", result.get("changed_anchor", "—") or "—")

    st.write(f"**{result.get('label', '')}**")
    if result.get("note"):
        st.caption(result["note"])

    graph = result.get("graph") or {}
    nodes = graph.get("nodes", [])
    edges = graph.get("edges", [])

    if nodes:
        st.markdown("**Nodes**")
        # simple 3-column table: id / label / side
        rows = []
        for n in nodes:
            rows.append({
                "id": n.get("id", ""),
                "token": n.get("label", ""),
                "side": _SIDE_TO_LABEL.get(n.get("side", ""), n.get("side", "")),
            })
        st.dataframe(rows, hide_index=True, use_container_width=True)

    if edges:
        st.markdown("**Edges (strength bucket only)**")
        edge_rows = []
        for e in edges:
            edge_rows.append({
                "src": e.get("src", ""),
                "dst": e.get("dst", ""),
                "strength": e.get("strength_bucket", ""),
            })
        st.dataframe(edge_rows, hide_index=True, use_container_width=True)

    with st.expander("Raw indicator output (public-safe JSON)", expanded=False):
        st.json(result)
