"""Tab 1 — Surgery Impact Map.

Reads `compute_surgery_impact(...)` output and renders impact / stage /
stability as three metric cards + a one-line natural-language note.

No raw scores, weights, or float values are surfaced.  This is by design.
"""
from __future__ import annotations

from typing import Any, Dict, Optional


def render(st: Any, result: Optional[Dict[str, Any]]) -> None:
    """Render the Surgery Impact card.

    Args:
        st: streamlit module (passed in to keep this file unit-importable
            without streamlit installed).
        result: output of `compute_surgery_impact(event)`, or None.
    """
    st.subheader("1 · Surgery Impact Map")
    st.caption(
        "How much did the intervention disturb the visible model output? "
        "Bucketed only — no exact scores."
    )

    if result is None:
        st.info("No intervention event selected.")
        return

    cols = st.columns(3)
    with cols[0]:
        impact = result.get("impact", "Low")
        st.metric("Impact", impact)
    with cols[1]:
        st.metric("Affected stage", result.get("affected_stage", "unknown"))
    with cols[2]:
        st.metric("Stability", result.get("stability", "Stable"))

    st.write(f"**{result.get('label', '')}**")
    if result.get("note"):
        st.caption(result["note"])

    with st.expander("Raw indicator output (public-safe JSON)", expanded=False):
        st.json(result)
