"""Tab 5 — Intervention Timeline.

Sorted projection of all intervention events.  Pure tabular view —
the data is the indicator output, and Streamlit just renders it.
"""
from __future__ import annotations

from typing import Any, Dict, Optional


def render(st: Any, result: Optional[Dict[str, Any]]) -> None:
    st.subheader("5 · Intervention Timeline")
    st.caption(
        "All intervention events, newest first.  Includes external "
        "(NNsight / TransformerLens / user prompt edits) when those "
        "tools fed events into BDP Insight."
    )

    if not result:
        st.info("No timeline available.")
        return

    summary = result.get("summary") or {}
    cols = st.columns(4)
    with cols[0]:
        st.metric("Total", summary.get("n_total", 0))
    with cols[1]:
        st.metric("Applied", summary.get("n_applied", 0))
    with cols[2]:
        st.metric("Blocked", summary.get("n_blocked", 0))
    with cols[3]:
        fams = summary.get("by_family") or {}
        st.metric("Families", len(fams))

    st.write(f"**{result.get('label', '')}**")

    items = result.get("items") or []
    if not items:
        st.info("Timeline is empty.")
    else:
        rows = []
        for it in items:
            ago = it.get("ago_sec")
            ago_str = (
                f"{ago}s ago" if ago is not None and ago < 60
                else (f"{ago // 60}m ago" if ago is not None else "—")
            )
            rows.append({
                "ago": ago_str,
                "family": it.get("family", "?"),
                "kind": it.get("kind_label", "?"),
                "status": it.get("status", "?"),
                "source": it.get("source_tool", "")[:30],
                "before": it.get("before", "")[:30],
                "after": it.get("after", "")[:30],
                "actual": "✓" if it.get("actual_model_event") else "·",
            })
        st.dataframe(rows, hide_index=True, use_container_width=True)

    fams = summary.get("by_family") or {}
    if fams:
        st.markdown("**By family**")
        fam_rows = [{"family": k, "count": v} for k, v in fams.items()]
        st.dataframe(fam_rows, hide_index=True, use_container_width=True)

    with st.expander("Raw indicator output (public-safe JSON)", expanded=False):
        st.json(result)
