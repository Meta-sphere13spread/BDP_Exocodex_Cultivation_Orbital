"""Tab — IRS-DCE Dynamics (PR_s + IRS-DCE_AUC visualisation).

Renders the 7 figures from `PR_s.py`:

    PS1  2D scatter (4-quadrant ID vs PC1r)
    PS2  3D trajectory (AGA-sized markers)
    PS3  spike/valley cross-section
    PS4  AGA / Density / Orbital bar chart
    PS5  2D trajectory + AGA overlay
    PS6  BCI cloud + 1/4 circle + w·ln(w) fit
    PS7  CPI / EDS(post-spike) / CDI bar (case comparison)

Each figure is shown as a small thumbnail in the main tab; clicking
"📊 Open figure window" opens it full-size in a Streamlit dialog
(st.dialog) — no separate browser window needed but the rendered figure
fills the dialog so the user can inspect it without losing context.

Stream-aware: this tab re-reads its data on every Streamlit rerun, so
when the user has Auto-refresh ON, the figures update every tick along
with the rest of the studio.

Public-safe: all values shown are from the published research metrics
(CPI / EDS / CDI / AGA / BCI / Δ_ID).  Per the 2026-05-03 user policy,
these are intentionally free.
"""
from __future__ import annotations

from typing import Any, Dict, Optional


# ──────────────────────────────────────────────────────────────────────
# Bucket → colour helper (consistent with rest of studio)
# ──────────────────────────────────────────────────────────────────────

def _bucket_color(label: str) -> str:
    return {
        "Free flow":            "#88e09a",
        "Touched":              "#ffd166",
        "Mild stagnation":      "#ff8b8b",
        "Heavy stagnation":     "#ff5b5b",
        "No dissolution":       "#a8b3bf",
        "Weak dissolution":     "#ffd166",
        "Partial dissolution":  "#88e09a",
        "Strong dissolution":   "#5bd97f",
        "Order broken":         "#ff8b8b",
    }.get(label, "#a8b3bf")


# ══════════════════════════════════════════════════════════════════════
# PS1 — 2D Scatter (ID vs PC1r), 4 quadrants
# ══════════════════════════════════════════════════════════════════════

def _build_ps1_scatter(rep: Dict[str, Any]):
    import plotly.graph_objects as go
    id_p   = rep["id_profile"]
    pc1_p  = rep["pc1r_profile"]
    aga    = rep["aga"]
    L      = len(id_p)

    fig = go.Figure()
    fig.add_trace(go.Scatter(
        x=id_p, y=pc1_p,
        mode="markers+text",
        marker=dict(
            size=[8 + 18 * a for a in aga],
            color=list(range(L)),
            colorscale="Viridis",
            colorbar=dict(title="layer", thickness=12),
            line=dict(width=0.5, color="#222"),
        ),
        text=[str(i) for i in range(L)],
        textposition="middle right",
        textfont=dict(size=9, color="#888"),
        hovertemplate="layer %{text}<br>ID=%{x:.3f}<br>PC1r=%{y:.3f}<extra></extra>",
        showlegend=False,
    ))
    fig.update_layout(
        title="PS1 — Phase Stagnation 2D Map (ID × PC1r, AGA-sized)",
        xaxis_title="ID  (Intrinsic Dimension)",
        yaxis_title="PC1r  (Stringiness)",
        height=520, hovermode="closest",
        plot_bgcolor="#f8f8f8",
    )
    return fig


# ══════════════════════════════════════════════════════════════════════
# PS2 — 3D Trajectory (ID, PC1r, layer) + AGA-sized markers
# ══════════════════════════════════════════════════════════════════════

def _build_ps2_trajectory_3d(rep: Dict[str, Any]):
    import plotly.graph_objects as go
    id_p  = rep["id_profile"]
    pc1_p = rep["pc1r_profile"]
    aga   = rep["aga"]
    L     = len(id_p)
    layers = list(range(L))
    spike  = rep["summary"]["spike_layer"]
    valley = rep["summary"]["valley_layer"]

    fig = go.Figure()
    # Trajectory line
    fig.add_trace(go.Scatter3d(
        x=layers, y=id_p, z=pc1_p,
        mode="lines",
        line=dict(color="#4a9eff", width=3),
        showlegend=False,
        hoverinfo="skip",
    ))
    # AGA-sized markers
    fig.add_trace(go.Scatter3d(
        x=layers, y=id_p, z=pc1_p,
        mode="markers",
        marker=dict(
            size=[5 + 14 * a for a in aga],
            color=aga,
            colorscale="Plasma",
            colorbar=dict(title="AGA", thickness=10),
            line=dict(width=0.5, color="#222"),
        ),
        text=[f"L{i}" for i in range(L)],
        hovertemplate="%{text}<br>ID=%{y:.3f}<br>PC1r=%{z:.3f}<br>"
                      "AGA=%{marker.color:.3f}<extra></extra>",
        showlegend=False,
    ))
    # Spike / valley markers
    if 0 <= spike < L:
        fig.add_trace(go.Scatter3d(
            x=[spike], y=[id_p[spike]], z=[pc1_p[spike]],
            mode="markers+text",
            marker=dict(size=18, color="#ff5b5b",
                        symbol="diamond", line=dict(width=2, color="white")),
            text=["spike"], textposition="top center",
            textfont=dict(size=11, color="#ff5b5b"),
            showlegend=False,
        ))
    if 0 <= valley < L:
        fig.add_trace(go.Scatter3d(
            x=[valley], y=[id_p[valley]], z=[pc1_p[valley]],
            mode="markers+text",
            marker=dict(size=18, color="#5bd97f",
                        symbol="diamond", line=dict(width=2, color="white")),
            text=["valley"], textposition="bottom center",
            textfont=dict(size=11, color="#5bd97f"),
            showlegend=False,
        ))
    fig.update_layout(
        title="PS2 — 3D Trajectory (layer × ID × PC1r, AGA-sized + spike/valley)",
        scene=dict(
            xaxis_title="layer",
            yaxis_title="ID",
            zaxis_title="PC1r",
            bgcolor="#0d0d1a",
        ),
        height=620,
        paper_bgcolor="#0d0d1a",
        font=dict(color="#e0e6f0"),
    )
    return fig


# ══════════════════════════════════════════════════════════════════════
# PS3 — Spike / Valley cross-section
# ══════════════════════════════════════════════════════════════════════

def _build_ps3_spike_valley(rep: Dict[str, Any]):
    import plotly.graph_objects as go
    from plotly.subplots import make_subplots
    id_p  = rep["id_profile"]
    pc1_p = rep["pc1r_profile"]
    omega = rep["omega_profile"]
    L     = len(id_p)
    layers = list(range(L))
    spike  = rep["summary"]["spike_layer"]
    valley = rep["summary"]["valley_layer"]

    fig = make_subplots(rows=1, cols=3, subplot_titles=("ID", "PC1r", "Ω"))
    for col, (vals, name) in enumerate(
        [(id_p, "ID"), (pc1_p, "PC1r"), (omega, "Ω")], start=1
    ):
        fig.add_trace(go.Scatter(x=layers, y=vals, mode="lines+markers",
                                 line=dict(color="#4a9eff"),
                                 marker=dict(size=4),
                                 showlegend=False), row=1, col=col)
        if 0 <= spike < L:
            fig.add_vline(x=spike, line_dash="dash", line_color="#ff5b5b",
                          annotation_text="spike",
                          annotation_position="top", row=1, col=col)
        if 0 <= valley < L:
            fig.add_vline(x=valley, line_dash="dot", line_color="#5bd97f",
                          annotation_text="valley",
                          annotation_position="bottom", row=1, col=col)
    fig.update_layout(
        title="PS3 — Spike / Valley cross-section",
        height=420, showlegend=False,
    )
    return fig


# ══════════════════════════════════════════════════════════════════════
# PS4 — AGA / Density / Orbital bar
# ══════════════════════════════════════════════════════════════════════

def _build_ps4_aga_bars(rep: Dict[str, Any]):
    import plotly.graph_objects as go
    aga     = rep["aga"]
    density = rep["density"]
    orbital = rep["orbital"]
    L       = len(aga)
    layers  = list(range(L))

    fig = go.Figure()
    fig.add_trace(go.Bar(x=layers, y=density, name="Density", marker_color="#4a9eff",
                         opacity=0.6))
    fig.add_trace(go.Bar(x=layers, y=orbital, name="Orbital", marker_color="#ffd166",
                         opacity=0.6))
    fig.add_trace(go.Bar(x=layers, y=aga,     name="AGA",     marker_color="#ff5b5b",
                         opacity=0.85))
    fig.update_layout(
        title="PS4 — Density × Orbital × Ω → AGA (per layer)",
        xaxis_title="layer", barmode="group",
        height=440, hovermode="x unified",
    )
    return fig


# ══════════════════════════════════════════════════════════════════════
# PS5 — 2D trajectory + AGA overlay
# ══════════════════════════════════════════════════════════════════════

def _build_ps5_trajectory_2d(rep: Dict[str, Any]):
    import plotly.graph_objects as go
    id_p  = rep["id_profile"]
    pc1_p = rep["pc1r_profile"]
    aga   = rep["aga"]
    L     = len(id_p)

    fig = go.Figure()
    # Trajectory line
    fig.add_trace(go.Scatter(
        x=id_p, y=pc1_p, mode="lines",
        line=dict(color="#a8b3bf", width=1.5),
        showlegend=False, hoverinfo="skip",
    ))
    # AGA-coloured markers
    fig.add_trace(go.Scatter(
        x=id_p, y=pc1_p, mode="markers+text",
        marker=dict(size=[6 + 14 * a for a in aga],
                    color=aga, colorscale="Plasma",
                    colorbar=dict(title="AGA", thickness=10),
                    line=dict(width=0.5, color="#222")),
        text=[str(i) for i in range(L)],
        textfont=dict(size=8, color="#666"),
        hovertemplate="layer %{text}<br>ID=%{x:.3f}<br>"
                      "PC1r=%{y:.3f}<extra></extra>",
        showlegend=False,
    ))
    fig.update_layout(
        title="PS5 — 2D Trajectory with AGA overlay",
        xaxis_title="ID",
        yaxis_title="PC1r",
        height=520, plot_bgcolor="#f8f8f8",
    )
    return fig


# ══════════════════════════════════════════════════════════════════════
# PS6 — BCI scatter cloud + 1/4 circle reference
# ══════════════════════════════════════════════════════════════════════

def _build_ps6_bci(rep: Dict[str, Any]):
    import plotly.graph_objects as go
    import numpy as np
    id_p  = np.array(rep["id_profile"])
    pc1_p = np.array(rep["pc1r_profile"])

    if id_p.size == 0:
        fig = go.Figure()
        fig.update_layout(title="PS6 — BCI (no data)")
        return fig

    # Normalise to [0, 1] for circle-fit display
    id_n  = (id_p - id_p.min()) / (np.ptp(id_p) + 1e-12)
    pc1_n = (pc1_p - pc1_p.min()) / (np.ptp(pc1_p) + 1e-12)

    fig = go.Figure()
    # Reference 1/4 circle (radius 1, centred at (1,1))
    theta = np.linspace(np.pi, 1.5 * np.pi, 50)
    cx = 1.0 + np.cos(theta)
    cy = 1.0 + np.sin(theta)
    fig.add_trace(go.Scatter(
        x=cx, y=cy, mode="lines",
        line=dict(color="#888", dash="dash", width=2),
        name="reference 1/4 circle",
    ))
    # Data points
    fig.add_trace(go.Scatter(
        x=id_n, y=pc1_n, mode="markers+text",
        marker=dict(size=10, color=list(range(len(id_n))),
                    colorscale="Viridis", line=dict(width=0.5, color="#222")),
        text=[str(i) for i in range(len(id_n))],
        textposition="top center",
        textfont=dict(size=9, color="#666"),
        name="layers",
        hovertemplate="layer %{text}<br>ID_n=%{x:.3f}<br>"
                      "PC1r_n=%{y:.3f}<extra></extra>",
    ))
    fig.update_layout(
        title="PS6 — BCI scatter (normalised) vs 1/4 circle reference",
        xaxis_title="ID (normalised)",
        yaxis_title="PC1r (normalised)",
        xaxis=dict(range=[-0.05, 1.05]),
        yaxis=dict(range=[-0.05, 1.05], scaleanchor="x", scaleratio=1),
        height=520, plot_bgcolor="#f8f8f8",
    )
    return fig


# ══════════════════════════════════════════════════════════════════════
# PS7 — CPI / EDS_post / CDI bar
# ══════════════════════════════════════════════════════════════════════

def _build_ps7_cpi_eds_cdi(rep: Dict[str, Any]):
    import plotly.graph_objects as go
    cpi_val = rep["cpi"]["cpi"]
    cdi_info = rep["cdi"]
    cdi_val  = cdi_info.get("cdi", 0.0)
    eds_post = cdi_info.get("eds_post_spike", 0.0) if cdi_info.get("order_ok") else 0.0
    fig = go.Figure(data=[
        go.Bar(name="CPI",            x=["CPI"],            y=[cpi_val],
               marker_color="#ff5b5b"),
        go.Bar(name="EDS post-spike", x=["EDS post-spike"], y=[eds_post],
               marker_color="#ffd166"),
        go.Bar(name="CDI",            x=["CDI"],            y=[cdi_val],
               marker_color="#5bd97f"),
    ])
    fig.update_layout(
        title="PS7 — CPI / EDS_post / CDI",
        yaxis_title="value",
        height=400, showlegend=False,
    )
    return fig


# ══════════════════════════════════════════════════════════════════════
# Renderer
# ══════════════════════════════════════════════════════════════════════

# Figure registry: title → builder fn (loaded lazily)
_FIGURES = [
    ("PS1 · 2D Phase Stagnation Map",     _build_ps1_scatter,         "📊"),
    ("PS2 · 3D Trajectory",               _build_ps2_trajectory_3d,   "🌐"),
    ("PS3 · Spike/Valley cross-section",  _build_ps3_spike_valley,    "📈"),
    ("PS4 · AGA / Density / Orbital",     _build_ps4_aga_bars,        "📊"),
    ("PS5 · 2D Trajectory + AGA overlay", _build_ps5_trajectory_2d,   "📈"),
    ("PS6 · BCI cloud + 1/4 circle",      _build_ps6_bci,             "⭕"),
    ("PS7 · CPI / EDS / CDI",             _build_ps7_cpi_eds_cdi,     "📊"),
]


def _render_summary_cards(st: Any, rep: Dict[str, Any]) -> None:
    """Top 4-card summary (CPI / CDI / spike layer / AUC)."""
    summary = rep["summary"]
    cols = st.columns(4)
    cpi_label = summary["cpi_bucket"]
    cdi_label = summary["cdi_bucket"]
    with cols[0]:
        c = _bucket_color(cpi_label)
        st.markdown(
            f"<div style='font-size:11px;color:#8a93a0;'>CPI</div>"
            f"<div style='font-size:18px;color:{c};font-weight:600;'>{cpi_label}</div>"
            f"<div style='font-size:11px;color:#666;'>"
            f"{rep['cpi']['cpi']:.3f}  "
            f"({rep['cpi']['longest_run']}/{rep['cpi']['L']} layers)</div>",
            unsafe_allow_html=True,
        )
    with cols[1]:
        c = _bucket_color(cdi_label)
        st.markdown(
            f"<div style='font-size:11px;color:#8a93a0;'>CDI</div>"
            f"<div style='font-size:18px;color:{c};font-weight:600;'>{cdi_label}</div>"
            f"<div style='font-size:11px;color:#666;'>"
            f"{rep['cdi']['cdi']:.3f}  "
            f"order_ok={rep['cdi'].get('order_ok')}</div>",
            unsafe_allow_html=True,
        )
    with cols[2]:
        st.metric("Spike layer", summary["spike_layer"])
        st.caption(f"Valley layer = {summary['valley_layer']}")
    with cols[3]:
        st.metric("AUC(Δ_ID > 0)", f"{summary['auc_delta_id_pos']:.3f}")
        st.caption(f"{rep['n_layers']} layers analysed")


def _show_figure_dialog(st: Any, key: str, title: str, builder, rep: Dict[str, Any]):
    """Open a Streamlit dialog with one full-size figure.

    Streamlit ≥ 1.31 has st.dialog.  For older versions we fall back to
    a full-width expander that opens automatically.
    """
    if hasattr(st, "dialog"):
        @st.dialog(title, width="large")          # ← Streamlit ≥ 1.31
        def _dialog():
            fig = builder(rep)
            st.plotly_chart(fig, use_container_width=True)
            st.caption(
                "Click outside the dialog or press Esc to close.  "
                "The figure is rendered live from the current capture run."
            )
        _dialog()
    else:                                          # pragma: no cover
        with st.expander(f"🔍 {title}", expanded=True):
            fig = builder(rep)
            st.plotly_chart(fig, use_container_width=True)


def render(st: Any, report: Optional[Dict[str, Any]]) -> None:
    """Render the IRS-DCE Dynamics tab.

    Args:
        st:     streamlit module
        report: output of `analyze_capture_run(run_dir)` or None
    """
    st.subheader("IRS-DCE Dynamics  ·  CPI / EDS / CDI / AGA / BCI")
    st.caption(
        "Static analysis of phase stagnation and dimensional escape "
        "(per the user's published research — PR_s.py + IRS-DCE_AUC.py).  "
        "Open any figure in a separate window for full-size inspection."
    )

    if report is None or not report.get("ok"):
        st.info(
            "No capture run with hidden states selected.\n\n"
            "→ Pick a capture run from the sidebar.  The run must contain "
            "`hidden_states_per_layer` in `result_minimal.json` (this is "
            "now captured by default — see "
            "`meta13_mri/capture_basic.py`)."
        )
        return

    # ── Top-row summary cards ──
    _render_summary_cards(st, report)
    st.divider()

    # ── Figure thumbnails grid (2 per row) ──
    st.markdown("### Figures (click to open)")
    st.caption(
        "Each figure is a thumbnail.  Click "
        "<kbd>📊 Open figure window</kbd> to view it full-size in a "
        "separate dialog without losing the studio context.",
        unsafe_allow_html=True,
    )

    for i in range(0, len(_FIGURES), 2):
        row = st.columns(2)
        for j in range(2):
            if i + j >= len(_FIGURES):
                continue
            title, builder, icon = _FIGURES[i + j]
            with row[j]:
                # Thumbnail (smaller height)
                try:
                    fig = builder(report)
                    fig.update_layout(height=260, margin=dict(l=20, r=20, t=40, b=20),
                                      title_font_size=11)
                    st.plotly_chart(
                        fig,
                        use_container_width=True,
                        key=f"thumb_irsdce_{i+j}",
                    )
                except Exception as exc:
                    st.error(f"Failed to render {title}: {type(exc).__name__}: {exc}")
                # Open-window button
                btn_key = f"open_irsdce_fig_{i+j}"
                if st.button(f"{icon} Open figure window", key=btn_key,
                             use_container_width=True):
                    _show_figure_dialog(st, btn_key, title, builder, report)

    # ── Raw report (collapsed) ──
    st.divider()
    with st.expander("Raw indicator output (public-safe JSON)", expanded=False):
        # strip the long arrays for readability
        light = {k: v for k, v in report.items()
                 if k not in ("id_profile", "pc1r_profile", "omega_profile",
                              "density", "orbital", "aga",
                              "eds_profile", "work_cumulative", "delta_id")}
        light["_array_lens"] = {
            "id_profile":      len(report.get("id_profile", [])),
            "pc1r_profile":    len(report.get("pc1r_profile", [])),
            "omega_profile":   len(report.get("omega_profile", [])),
            "aga":             len(report.get("aga", [])),
            "eds_profile":     len(report.get("eds_profile", [])),
            "work_cumulative": len(report.get("work_cumulative", [])),
        }
        st.json(light)
