"""Tab 3 — Stale Reasoning Detector.

Surfaces the consistency label (Stable / Stale / Unknown) plus the
edited anchor and the stale tail preview that was reused.

This is the indicator the user emphasised most strongly — it catches
the canonical "intermediate edited but downstream did not recompute" case
(e.g. `3 + 4 = 99 ... add 5 = 12`).
"""
from __future__ import annotations

from typing import Any, Dict, Optional


def render(st: Any, result: Optional[Dict[str, Any]]) -> None:
    st.subheader("3 · Stale Reasoning Detector")
    st.caption(
        "Did the downstream chain recompute on the new anchor, or reuse "
        "the old tail?  Observational only — never a right/wrong call."
    )

    if result is None:
        st.info("No intervention event selected.")
        return

    consistency = result.get("consistency", "Unknown")
    warning = bool(result.get("warning", False))

    cols = st.columns(2)
    with cols[0]:
        st.metric("Consistency", consistency)
    with cols[1]:
        st.metric("Warning", "⚠ yes" if warning else "no")

    if consistency == "Stale":
        st.error(result.get("label", ""))
    elif consistency == "Stable":
        st.success(result.get("label", ""))
    else:
        st.info(result.get("label", ""))

    if result.get("note"):
        st.write(result["note"])

    evidence = result.get("evidence") or {}
    if evidence:
        st.markdown("**Evidence**")
        # short table
        ev_rows = [
            {"field": "edited_anchor",
             "value": evidence.get("edited_anchor", "") or "—"},
            {"field": "stale_tail_preview",
             "value": evidence.get("stale_tail_preview", "") or "—"},
        ]
        st.dataframe(ev_rows, hide_index=True, use_container_width=True)

    with st.expander("Raw indicator output (public-safe JSON)", expanded=False):
        st.json(result)
