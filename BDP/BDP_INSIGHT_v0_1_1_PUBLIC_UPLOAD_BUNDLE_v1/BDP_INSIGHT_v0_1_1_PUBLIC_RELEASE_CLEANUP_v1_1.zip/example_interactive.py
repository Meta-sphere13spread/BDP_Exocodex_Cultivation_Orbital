"""Interactive BDP-insight L2 HodgeConverter example.

Run from the package root:

    python example_interactive.py

This example first asks for your RapidAPI URL / Host / Key. Press Enter to use the default URL/Host. It then optionally opens the
dynamic debugger and static Studio, then starts a small chat loop.

Static Studio IRS-DCE requires hidden-state capture; this example keeps capture enabled by default.

Inside chat:
    /hodge 9 2 8 32      queue L2 Hodge intervention: target_regex=2 -> new_word=9
    /max 256             change normal max_new_tokens
    /quit                exit
"""
from __future__ import annotations

from bdp_insight.cli import chat_main

if __name__ == "__main__":
    raise SystemExit(chat_main())
