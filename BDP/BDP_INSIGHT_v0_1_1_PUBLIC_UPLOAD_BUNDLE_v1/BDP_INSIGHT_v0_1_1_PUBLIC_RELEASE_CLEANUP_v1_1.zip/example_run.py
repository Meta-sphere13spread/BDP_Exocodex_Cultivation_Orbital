"""BDP-insight L2 HodgeConverter example.

Copy your RapidAPI values from the API Hub Code Snippet into the variables
below, then run from the package root:

    python example_run.py

This root-level example uses Qwen as the public baseline model.  You can replace model_id
with your own local HF causal language model.
"""
from __future__ import annotations

import torch
from transformers import AutoModelForCausalLM, AutoTokenizer

from bdp_insight.api import (
    BDPHodgeConfig,
    attach_hodge_debugger,
    check_rapidapi_config,
    generate_text,
    queue_hodge_output_intervention,
)

# 1) Paste values from your RapidAPI / API Hub Code Snippet.
#    Customer-side values only. Do NOT paste provider-side secret here.
rapidapi_url = "https://bdp-insight-l2.p.rapidapi.com/v1/hodge/convert"
rapidapi_host = "bdp-insight-l2.p.rapidapi.com"
rapidapi_key = "YOUR_RAPIDAPI_KEY"

config = BDPHodgeConfig(
    rapidapi_url=rapidapi_url,
    rapidapi_host=rapidapi_host,
    rapidapi_key=rapidapi_key,
    debug=True,
)
print("[config]", check_rapidapi_config(config))

# 2) Load model.
model_id = "Qwen/Qwen2.5-0.5B-Instruct"
tokenizer = AutoTokenizer.from_pretrained(model_id, trust_remote_code=True)
if tokenizer.pad_token_id is None:
    tokenizer.pad_token_id = tokenizer.eos_token_id

model = AutoModelForCausalLM.from_pretrained(
    model_id,
    torch_dtype=torch.float32,
    trust_remote_code=True,
).eval()

# 3) Attach debugger.  The returned model is the same object with generate() wrapped.
run_dir = "results/example_hodge_run"
model = attach_hodge_debugger(
    model=model,
    tokenizer=tokenizer,
    config=config,
    model_id=model_id,
    run_dir=run_dir,
    outdir="results/example_hodge_capture",
    enable_capture=True,  # required for Static Studio / IRS-DCE hidden-state capture
)

prompt = "2 + 9 는?"
print("\n[baseline]")
print(generate_text(model=model, tokenizer=tokenizer, prompt=prompt, max_new_tokens=128))

# 4) Queue one L2 Hodge output-prefix intervention for the next generate().
# This does not rewrite the user prompt.  It patches the partial generated output
# when target_regex appears, then continues from the patched prefix.
queue_hodge_output_intervention(
    run_dir=run_dir,
    new_word="4",
    target_regex="9",
    wait_tokens=8,
    continuation_tokens=32,
)

print("\n[hodge]")
print(generate_text(model=model, tokenizer=tokenizer, prompt=prompt, max_new_tokens=128))
