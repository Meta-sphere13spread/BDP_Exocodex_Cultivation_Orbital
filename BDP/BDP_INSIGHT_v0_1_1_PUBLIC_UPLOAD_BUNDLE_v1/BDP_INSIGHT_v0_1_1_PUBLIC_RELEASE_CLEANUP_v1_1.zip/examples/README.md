# Examples

Main user examples are at the package root:

```bash
python example_run.py
python example_interactive.py
```

Additional examples in this folder:

```bash
python examples/example_direct_api.py   # API Hub / Modal smoke test only
python examples/example_gemma.py        # optional Gemma-style model example
```

The client only needs:

```text
rapidapi_url
rapidapi_host
rapidapi_key
```

No provider-side secrets are required in client examples.
