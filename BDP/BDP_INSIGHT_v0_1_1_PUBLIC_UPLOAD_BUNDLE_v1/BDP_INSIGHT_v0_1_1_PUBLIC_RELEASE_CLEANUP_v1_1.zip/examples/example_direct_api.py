"""Direct API Hub smoke test without loading a model.

This verifies your RapidAPI subscription, host, key, and Modal adapter path.
It does not test the dynamic debugger continuation path.
"""
from __future__ import annotations

import json
import urllib.request

rapidapi_url = "https://bdp-insight-l2.p.rapidapi.com/v1/hodge/convert"
rapidapi_host = "bdp-insight-l2.p.rapidapi.com"
rapidapi_key = "YOUR_RAPIDAPI_KEY"

body = {
    "text": "2 + 4 = 6",
    "replacement": "9",
    "target_regex": "2",
    "mode": "output",
    "wait_tokens": 8,
    "continuation_tokens": 32,
}

req = urllib.request.Request(
    rapidapi_url,
    data=json.dumps(body, ensure_ascii=False).encode("utf-8"),
    headers={
        "Content-Type": "application/json; charset=utf-8",
        "X-RapidAPI-Key": rapidapi_key,
        "X-RapidAPI-Host": rapidapi_host,
    },
    method="POST",
)

with urllib.request.urlopen(req, timeout=60) as resp:
    print(resp.read().decode("utf-8", errors="replace"))
