"""Optional Gemma-style compatibility example.

Replace model_id with the Gemma checkpoint available in your environment.
Qwen is the public baseline, but the runtime path is not Qwen-specific.
"""
from __future__ import annotations

import torch
from transformers import AutoModelForCausalLM, AutoTokenizer

from bdp_insight.api import BDPHodgeConfig, attach_hodge_debugger, generate_text, queue_hodge_output_intervention

rapidapi_url = "https://bdp-insight-l2.p.rapidapi.com/v1/hodge/convert"
rapidapi_host = "bdp-insight-l2.p.rapidapi.com"
rapidapi_key = "YOUR_RAPIDAPI_KEY"

model_id = "google/gemma-2-2b-it"  # Change to your local Gemma/Gemma-style model.
config = BDPHodgeConfig(rapidapi_url=rapidapi_url, rapidapi_host=rapidapi_host, rapidapi_key=rapidapi_key, debug=True)

tokenizer = AutoTokenizer.from_pretrained(model_id, trust_remote_code=True)
model = AutoModelForCausalLM.from_pretrained(model_id, torch_dtype=torch.float32, trust_remote_code=True).eval()

run_dir = "results/example_gemma_hodge_run"
model = attach_hodge_debugger(model=model, tokenizer=tokenizer, config=config, model_id=model_id, run_dir=run_dir)

prompt = "2개의 상자에 각각 사과가 3개씩 있다. 전체 사과 수를 수식으로 쓰고 계산해"
print("[baseline]")
print(generate_text(model=model, tokenizer=tokenizer, prompt=prompt, max_new_tokens=256))

queue_hodge_output_intervention(run_dir=run_dir, new_word="9", target_regex="2", wait_tokens=64, continuation_tokens=32)
print("[hodge]")
print(generate_text(model=model, tokenizer=tokenizer, prompt=prompt, max_new_tokens=256))
