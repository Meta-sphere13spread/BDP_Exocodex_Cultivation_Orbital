from .attach import attach, attach_debugger, MRISession
from .base import BaseModelDebugCore, BaseRunResult
from .capture_basic import BasicCaptureWriter
from .command_queue import CommandQueue
from .debug_control import DebugController
from .premium_client import PremiumDebuggerClient, PremiumRequired
from .entitlement import RuntimeEntitlement, resolve_entitlement
from .ephemeral_blob import EphemeralBlob
from .ephemeral_lease import EphemeralFunctionLease, LeaseConsumed, LeaseMaterialAccessBlocked
from .so_loader import SoLoader
from .easter_egg import L4EasterEgg
from .selftest import run_selftest
from .irsdce_geometry import build_irsdce_geometry_graph, load_irsdce_geometry_from_files
from .public_internal_metrics import build_public_internal_metrics, build_public_internal_graph

try:  # Flask is optional until dashboard/prologue is used.
    from .prologue_bridge import prologue_bp, inject_prologue_js
except Exception:  # pragma: no cover - optional dashboard extra missing
    prologue_bp = None
    def inject_prologue_js(*args, **kwargs):
        return ""

__all__ = [
    "attach",
    "attach_debugger",
    "MRISession",
    "BaseModelDebugCore", "BaseRunResult",
    "BasicCaptureWriter",
    "CommandQueue",
    "DebugController",
    "PremiumDebuggerClient", "PremiumRequired",
    "RuntimeEntitlement", "resolve_entitlement",
    "EphemeralBlob",
    "EphemeralFunctionLease", "LeaseConsumed", "LeaseMaterialAccessBlocked",
    "SoLoader",
    "L4EasterEgg",
    "run_selftest",
    "build_irsdce_geometry_graph", "load_irsdce_geometry_from_files",
    "build_public_internal_metrics", "build_public_internal_graph",
    "prologue_bp", "inject_prologue_js",
]
__version__ = "0.1.13.2-runtime-step6-public-internals"
