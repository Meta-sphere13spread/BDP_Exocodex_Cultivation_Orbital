"""
attach.py — Meta-13 MRI 단일 진입점
=====================================

두 가지 사용 방식:

방식 A — 세션 방식 (MRISession 반환):
    from meta13_mri import attach
    dbg = attach("Qwen/Qwen2.5-0.5B-Instruct")
    r = dbg.run("What is 2+2?")
    dbg.dashboard()

방식 B — generate 래핑 방식 (모델 그대로 반환):
    from meta13_mri import attach_debugger
    model = attach_debugger(model, tokenizer=tok, model_id="name")
    out = model.generate(**inputs, max_new_tokens=16)  # 기존 코드 유지
    dbg = model._meta13_session  # dashboard 등 접근 시

attach() 인자:
    model_name_or_path / model / tokenizer / model_id
    max_new_tokens / outdir / run_dir / device / load_in_8bit / trust_remote_code

attach_debugger() 인자:
    model          : 이미 로드된 HF 모델 (필수)
    tokenizer      : HF 토크나이저 (필수)
    model_id       : 표시용 이름
    run_dir        : 동적 디버그 상태 경로
    outdir         : MRI 캡처 저장 경로
    enable_l1      : True면 L1 rewrite command 자동 적용
    enable_capture : True면 MRI 파일 저장

정책:
    L1 rewrite    — 무료 실행
    L2/L3 surgery — 유료 잠금 (PremiumDebuggerClient)
    L4 graft      — Coming Soon
    T-engine      — Easter egg
"""
from __future__ import annotations

import json
import logging
import os
import threading
import time
import webbrowser
from pathlib import Path
from typing import Any, Dict, List, Optional

from .base import BaseModelDebugCore
from .command_queue import CommandQueue
from .atomic import atomic_write_json
from .entitlement import resolve_entitlement

logger = logging.getLogger("meta13_mri.attach")


def _init_dynamic_debug_files(core: BaseModelDebugCore) -> Dict[str, str]:
    """
    v1.7: attach 직후 dashboard가 빈 경로를 보지 않도록 dynamic_debug 파일을 즉시 만든다.

    generate가 한 번도 실행되지 않아도 /api/debug/paths에서 state_exists/events_exists가
    true가 되며, 첫 이벤트 attach_started가 남는다. 기존 파일이 있으면 보존하고
    attach_started만 append한다.
    """
    run_dir = Path(getattr(core, "run_dir", "results/mri_run")).resolve()
    outdir = Path(getattr(core, "outdir", "results/mri_capture")).resolve()
    dyn = run_dir / "dynamic_debug"
    dyn.mkdir(parents=True, exist_ok=True)

    events_path = dyn / "events.jsonl"
    commands_path = dyn / "commands.jsonl"
    state_path = dyn / "current_state.json"
    runtime_status_path = dyn / "runtime_status.json"

    # 빈 파일이라도 먼저 생성해서 dashboard 경로 진단이 false로 떨어지지 않게 한다.
    events_path.touch(exist_ok=True)
    commands_path.touch(exist_ok=True)

    init_event = {
        "kind": "attach_started",
        "source": "attach_debugger",
        "phase": "attach",
        "tier": getattr(getattr(core, "entitlement", None), "tier", "free"),
        "paid_enabled": bool(getattr(getattr(core, "entitlement", None), "paid_enabled", False)),
        "paid_mode": getattr(getattr(core, "entitlement", None), "paid_mode", "free"),
        "ts": time.time(),
        "extra": {
            "model_id": getattr(core, "model_id", "model"),
            "run_dir": str(run_dir),
            "mri_outdir": str(outdir),
        },
    }
    with events_path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(init_event, ensure_ascii=False) + "\n")

    runtime_status = {
        "ok": True,
        "source": "attach_debugger",
        "ts": time.time(),
        "status": core.status(),
        "entitlement": getattr(getattr(core, "entitlement", None), "public_dict", lambda: {})(),
    }
    try:
        atomic_write_json(runtime_status_path, runtime_status)
    except Exception as exc:
        with events_path.open("a", encoding="utf-8") as f:
            f.write(json.dumps({
                "kind": "runtime_status_write_failed",
                "error": f"{type(exc).__name__}: {exc}",
                "ts": time.time(),
            }, ensure_ascii=False) + "\n")

    if not state_path.exists():
        state = {
            "run_id": "base_model_debugger",
            "ts": time.time(),
            "phase": "attached",
            "source": "attach_debugger",
            "paused": False,
            "tier": getattr(getattr(core, "entitlement", None), "tier", "free"),
            "paid_enabled": bool(getattr(getattr(core, "entitlement", None), "paid_enabled", False)),
            "paid_mode": getattr(getattr(core, "entitlement", None), "paid_mode", "free"),
            "free_scope": ["static_basic", "l1_rewrite_prompt"],
            "paid_scope": ["l2_hodge_auto", "l2_hodge_output_intercept"], "free_l3_scope": ["l3_embed_perturb"],
            "t_engine": "easter_egg_only",
            "extra": {
                "route": "ATTACHED_IDLE",
                "l1_rewrite_applied": False,
            },
            "status": core.status(),
        }
        state_path.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding="utf-8")

    return {
        "run_dir": str(run_dir),
        "outdir": str(outdir),
        "events_path": str(events_path),
        "state_path": str(state_path),
        "commands_path": str(commands_path),
        "runtime_status_path": str(runtime_status_path),
    }


def _wait_if_paused(core: BaseModelDebugCore, *, phase: str, source: str) -> None:
    """v1.9 next-turn freeze gate.

    freeze_wait polls commands without rewriting current_state.json on every
    loop. This prevents Windows ``PermissionError: [WinError 5]`` when the
    dashboard reads the same state file while the paused runner is waiting.
    """
    controller = getattr(core, "debug_controller", None)
    if controller is None:
        return

    snap = controller.poll_commands_only(
        core,
        "freeze_precheck",
        {"freeze_phase": phase},
        source,
        write_state=True,
        append_event=False,
    )
    if not snap.get("paused"):
        return

    controller.queue.append_event({
        "kind": "freeze_enter",
        "phase": phase,
        "source": source,
        "ts": time.time(),
    })

    # Write the paused state once at enter, not on every wait tick.
    try:
        enter_state = dict(snap)
        enter_state.update({"phase": "freeze_wait", "paused": True})
        enter_extra = dict(enter_state.get("extra") or {})
        enter_extra.update({"waiting_for": "resume_or_abort", "freeze_phase": phase})
        enter_state["extra"] = enter_extra
        controller.queue.write_state(enter_state)
    except Exception as exc:
        controller.queue.append_event({
            "kind": "state_write_skipped",
            "reason": type(exc).__name__,
            "error": str(exc),
            "phase": "freeze_enter",
            "source": source,
            "ts": time.time(),
        })

    last_heartbeat = 0.0
    snap2 = snap
    while True:
        time.sleep(0.2)
        now = time.time()
        try:
            snap2 = controller.poll_commands_only(
                core,
                "freeze_wait",
                {"waiting_for": "resume_or_abort", "freeze_phase": phase},
                source,
                write_state=False,
                append_event=False,
            )
        except RuntimeError as exc:
            if "DebugAbortRequested" in str(exc):
                controller.queue.append_event({
                    "kind": "freeze_abort",
                    "phase": phase,
                    "source": source,
                    "ts": time.time(),
                })
            raise
        if now - last_heartbeat >= 2.0:
            controller.queue.append_event({
                "kind": "freeze_wait",
                "phase": phase,
                "source": source,
                "paused": bool(snap2.get("paused")),
                "ts": now,
            })
            last_heartbeat = now
        if not snap2.get("paused"):
            controller.queue.append_event({
                "kind": "freeze_exit",
                "phase": phase,
                "source": source,
                "ts": time.time(),
            })
            try:
                exit_state = dict(snap2)
                exit_state.update({"phase": phase, "paused": False})
                controller.queue.write_state(exit_state)
            except Exception as exc:
                controller.queue.append_event({
                    "kind": "state_write_skipped",
                    "reason": type(exc).__name__,
                    "error": str(exc),
                    "phase": "freeze_exit",
                    "source": source,
                    "ts": time.time(),
                })
            return


# ─────────────────────────────────────────────────────────────────────────────
# 방식 A: attach() — MRISession 반환
# ─────────────────────────────────────────────────────────────────────────────

def attach(
    model_name_or_path: str = "",
    *,
    model: Any = None,
    tokenizer: Any = None,
    model_id: str = "",
    max_new_tokens: int = 128,
    outdir: str = "results/mri_capture",
    run_dir: str = "results/mri_run",
    device: str = "auto",
    load_in_8bit: bool = False,
    trust_remote_code: bool = False,
    paid_key: Optional[str] = None,
    paid_mode: Optional[str] = None,
    paid_enabled: Optional[bool] = None,
    allow_local_import: bool = False,
) -> "MRISession":
    """
    모델에 MRI 디버거를 붙이고 MRISession 반환.

    사용자는 dbg.run() 으로 프롬프트를 실행한다.
    """
    _id = model_id or model_name_or_path or "model"

    if model is None:
        if not model_name_or_path:
            raise ValueError("model_name_or_path 또는 model= 인자 중 하나가 필요합니다.")
        logger.info("[attach] 모델 로드 중: %s  device=%s  8bit=%s",
                    model_name_or_path, device, load_in_8bit)
        model, tokenizer = _load_hf_model(
            model_name_or_path,
            device=device,
            load_in_8bit=load_in_8bit,
            trust_remote_code=trust_remote_code,
        )
        logger.info("[attach] 로드 완료: %s", model_name_or_path)

    if tokenizer is None:
        raise ValueError("tokenizer= 인자가 필요합니다.")

    if getattr(tokenizer, "pad_token_id", None) is None:
        tokenizer.pad_token_id = getattr(tokenizer, "eos_token_id", 0)

    core = BaseModelDebugCore(
        model, tokenizer,
        outdir=outdir,
        run_dir=run_dir,
        model_id=_id,
        paid_key=paid_key,
        paid_mode=paid_mode,
        paid_enabled=paid_enabled,
        allow_local_import=allow_local_import,
    )
    _init_dynamic_debug_files(core)
    return MRISession(core, max_new_tokens=max_new_tokens)


# ─────────────────────────────────────────────────────────────────────────────
# 방식 B: attach_debugger() — model.generate 래핑, 모델 그대로 반환
# ─────────────────────────────────────────────────────────────────────────────

def attach_debugger(
    model: Any,
    *,
    tokenizer: Any,
    model_id: str = "",
    run_dir: str = "results/mri_run",
    outdir: str = "results/mri_capture",
    max_new_tokens_hint: Optional[int] = None,
    enable_l1: bool = True,
    enable_capture: bool = True,
    paid_key: Optional[str] = None,
    paid_mode: Optional[str] = None,
    paid_enabled: Optional[bool] = None,
    allow_local_import: bool = False,
) -> Any:
    """
    이미 로드된 HF-like model 의 generate() 를 MRI wrapper 로 감싼다.
    model 자체를 수정해서 그대로 반환하므로 기존 하네스 코드 변경이 없다.

    사용 예:
        model = attach_debugger(model, tokenizer=tok, model_id="name")
        out = model.generate(**inputs, max_new_tokens=16)  # 기존 코드 유지

    model 에 추가되는 속성:
        _meta13_debugger_attached : bool
        _meta13_original_generate : 원본 generate 함수
        _meta13_mri_core          : BaseModelDebugCore
        _meta13_session           : MRISession (dashboard 접근용)

    Parameters
    ----------
    model          이미 로드된 HF 모델
    tokenizer      HF 토크나이저
    model_id       대시보드 표시 이름
    run_dir        동적 디버그 경로
    outdir         MRI 캡처 경로
    max_new_tokens_hint  capture 시 저장할 max_new_tokens 힌트
    enable_l1      True 면 generate 전 L1 rewrite command 자동 적용
    enable_capture True 면 MRI 파일 저장

    Returns
    -------
    model (generate 가 래핑된 동일 객체)
    """
    if getattr(model, "_meta13_debugger_attached", False):
        logger.warning("[attach_debugger] 이미 attach됨: %s", getattr(model, "_meta13_mri_core", {}).model_id if hasattr(model, "_meta13_mri_core") else "unknown")
        return model

    _id = model_id or getattr(getattr(model, "config", None), "name_or_path", "model")

    if getattr(tokenizer, "pad_token_id", None) is None:
        tokenizer.pad_token_id = getattr(tokenizer, "eos_token_id", 0)

    core = BaseModelDebugCore(
        model, tokenizer,
        outdir=outdir,
        run_dir=run_dir,
        model_id=_id,
        paid_key=paid_key,
        paid_mode=paid_mode,
        paid_enabled=paid_enabled,
        allow_local_import=allow_local_import,
    )
    init_paths = _init_dynamic_debug_files(core)
    session = MRISession(core, max_new_tokens=max_new_tokens_hint or 128)

    original_generate = model.generate

    def _meta13_generate(*args, **kwargs):
        return _generate_wrapper(
            core=core,
            tokenizer=tokenizer,
            original_generate=original_generate,
            args=args,
            kwargs=kwargs,
            enable_l1=enable_l1,
            enable_capture=enable_capture,
        )

    model.generate = _meta13_generate
    model._meta13_debugger_attached = True
    model._meta13_original_generate = original_generate
    model._meta13_mri_core = core
    model._meta13_session = session

    logger.info("[attach_debugger] model.generate 래핑 완료: %s", _id)
    logger.info("[attach_debugger] dynamic_debug events=%s state=%s",
                init_paths.get("events_path"), init_paths.get("state_path"))
    return model



def _route_with_paid(route: str, suffix: str) -> str:
    return route if suffix in route else f"{route}+{suffix}"



def _apply_pending_paid_surgery_to_generate(core: BaseModelDebugCore, tokenizer: Any, args: tuple, kwargs: dict, route: str, *, source: str):
    """Apply paid L2/L3 operations queued by DebugController for one generate call.

    Modal-remote dashboard fix:
    - Manual L2 swap and Hodge-auto are applied by decoding the current prompt,
      using the paid text kernel when available, and re-encoding the edited prompt.
    - This avoids sending tokenizer/model/tensor objects to Modal.
    - L3 hook remains local one-generate hook because it necessarily touches the
      local model object.
    """
    handles = []
    entitlement = getattr(core, "entitlement", resolve_entitlement())
    if not getattr(entitlement, "paid_enabled", False):
        return args, kwargs, route, handles

    def _decode_current_prompt():
        input_ids, input_source = _get_generate_input_ids(args, kwargs)
        if input_ids is None:
            return "", None, "missing"
        try:
            ids = input_ids[0].detach().clone().tolist() if hasattr(input_ids, "detach") else input_ids[0].tolist()
            text = tokenizer.decode([int(x) for x in ids], skip_special_tokens=False)
            return text, input_ids, input_source
        except Exception as exc:
            core.debug_controller.queue.append_event({
                "kind": "paid_surgery_noop",
                "function_id": "l2.decode_input",
                "route": "L2_TEXT_BRIDGE",
                "changed": False,
                "meta": {"reason": f"decode current prompt failed: {type(exc).__name__}: {exc}"},
                "source": source,
                "tier": "paid",
                "actual_model_event": True,
                "preview_only": False,
                "ts": time.time(),
            })
            return "", None, "missing"

    def _encode_replace_prompt(new_text: str, input_ids, input_source: str):
        try:
            new_ids = _encode_plain(tokenizer, new_text)
            if not new_ids:
                return args, kwargs, False, {"reason": "re-encoded prompt is empty"}
            if input_ids is not None and hasattr(input_ids, "new_tensor"):
                new_tensor = input_ids.new_tensor([new_ids])
            else:
                import torch as _torch
                new_tensor = _torch.tensor([new_ids], dtype=getattr(input_ids, 'dtype', None) or _torch.long)
            new_args, new_kwargs = _replace_generate_input_ids(args, kwargs, new_tensor, input_source)
            return new_args, new_kwargs, True, {"new_input_len": len(new_ids), "text_bridge": True}
        except Exception as exc:
            return args, kwargs, False, {"reason": f"encode/replace prompt failed: {type(exc).__name__}: {exc}"}

    l2_pending = list(getattr(core, "_pending_l2_token_surgery", []) or [])
    core._pending_l2_token_surgery = []
    if l2_pending:
        from .paid_local_ops import hodge_auto_replace_text
        for item in l2_pending:
            function_id = item.get("function_id", "l2.swap_token")
            op_name = str(item.get("op", "")).lower()
            payload = dict(item.get("payload") or {})
            prompt_text, input_ids, input_source = _decode_current_prompt()
            changed = False
            meta = {}
            route_name = "L2_TOKEN_SURGERY"

            if not prompt_text or input_ids is None:
                meta = {"reason": "input_ids missing or prompt decode failed"}
            elif function_id == "l2.hodge_auto" or op_name in {"hodge_token_auto", "hodge_auto", "hodge_convert", "hodge_token_convert"}:
                route_name = "L2_HODGE_AUTO"
                new_value = payload.get("new_word", payload.get("value", payload.get("replacement", "")))
                try:
                    # B_I_S6 product rule:
                    # HodgeConverter is a server-bound runtime output-prefix intervention.
                    # Do not rewrite the user prompt by default.  Arm the hidden stabilized
                    # output fallback, generate a partial assistant prefix, send only that
                    # partial output to the paid API Hub/Modal kernel, then continue from the
                    # modified prefix.  Set BDP_ALLOW_HODGE_INPUT_BRIDGE=1 only for old dev tests.
                    target_regex = payload.get("target_regex")
                    old_word = payload.get("old_word", payload.get("target", ""))
                    allow_input_bridge = os.environ.get("BDP_ALLOW_HODGE_INPUT_BRIDGE", "0").strip().lower() in {"1", "true", "yes", "on"}
                    fallback_enabled = str(payload.get("auto_output_fallback", "1")).lower() not in {"0", "false", "no", "off"}
                    new_text = ""
                    if fallback_enabled and not allow_input_bridge:
                        fb_payload = {
                            "new_word": new_value,
                            "replacement": new_value,
                            "value": new_value,
                            "target_regex": target_regex,
                            "old_word": old_word,
                            "hodge_wait_tokens": payload.get("hodge_wait_tokens", 8),
                            "after_tokens": payload.get("after_tokens", payload.get("hodge_wait_tokens", 8)),
                            "continuation_tokens": payload.get("continuation_tokens", 16),
                            "stabilize_prefix": True,
                            "_internal_from_hodge_auto": True,
                        }
                        if str(target_regex or "").strip() or str(old_word or "").strip():
                            core._pending_output_hodge_intercept = [{
                                "function_id": "l2.hodge_auto",
                                "op": "hodge_auto_output_fallback",
                                "payload": fb_payload,
                            }]
                            meta = {
                                "input_changed": False,
                                "prompt_text_unchanged": True,
                                "armed_hidden_output_fallback": True,
                                "public_surface": "hodge_auto_output_fallback",
                                "s6_output_fallback_only": True,
                            }
                            changed = False
                        else:
                            meta = {"input_changed": False, "hidden_output_fallback": False, "reason": "no explicit target for safe fallback"}
                            changed = False
                    else:
                        # Legacy developer bridge: not product-default because it rewrites prompt text.
                        new_text, changed, meta = hodge_auto_replace_text(
                            prompt_text,
                            new_value,
                            selector="auto",
                            target_regex=target_regex,
                        )
                        if changed:
                            args, kwargs, ok_replace, replace_meta = _encode_replace_prompt(new_text, input_ids, input_source)
                            meta = {**(meta or {}), **replace_meta, "public_surface": "hodge_auto_input_legacy", "legacy_input_bridge": True}
                            changed = bool(ok_replace)
                except Exception as exc:
                    changed = False
                    meta = {"reason": f"modal hodge output-fallback bridge failed: {type(exc).__name__}: {exc}"}
            else:
                changed = False
                meta = {
                    "mode": "manual_l2_removed",
                    "reason": "L2 manual token swap/graft/basis selection and public Output intercept were removed from the product surface; use HodgeConverter auto.",
                    "op": op_name or function_id,
                    "function_id": function_id,
                }

            if changed:
                route = _route_with_paid(route, route_name)

            core.debug_controller.queue.append_event({
                "kind": "paid_surgery_applied" if changed else "paid_surgery_noop",
                "function_id": function_id,
                "op": op_name or function_id,
                "route": route_name,
                "changed": changed,
                "meta": meta or {},
                "source": source,
                "tier": "paid",
                "paid_mode": getattr(entitlement, "paid_mode", "paid"),
                "actual_model_event": True,
                "preview_only": False,
                "prompt_preview": (prompt_text or "")[:240],
                "prompt_after_preview": (new_text if changed and 'new_text' in locals() else "")[:240],
                "command_payload_public": {
                    "old_word": str(payload.get("old_word", ""))[:80],
                    "new_word": str(payload.get("new_word", payload.get("value", payload.get("replacement", ""))))[:80],
                    "target_regex": str(payload.get("target_regex", ""))[:120],
                    "position": str(payload.get("position", ""))[:40],
                    "mode": str(payload.get("mode", ""))[:80],
                },
                "ts": time.time(),
            })

    l3_pending = list(getattr(core, "_pending_l3_embed_surgery", []) or [])
    core._pending_l3_embed_surgery = []
    if l3_pending:
        from .paid_local_ops import install_l3_embedding_hook
        for item in l3_pending:
            function_id = item.get("function_id", "l3.embed_perturb")
            handle, result = install_l3_embedding_hook(core.model, dict(item.get("payload") or {}))
            if handle is not None:
                handles.append(handle)
            if result.ok and result.changed:
                route = _route_with_paid(route, result.route)
            ev_l3 = result.event(function_id=function_id, source=source)
            ev_l3.setdefault("op", "embed_perturb")
            ev_l3.setdefault("prompt_preview", (_decode_current_prompt()[0] or "")[:240])
            ev_l3.setdefault("command_payload_public", {
                "position": str((item.get("payload") or {}).get("position", ""))[:40],
                "magnitude": str((item.get("payload") or {}).get("magnitude", ""))[:40],
                "mode": str((item.get("payload") or {}).get("mode", ""))[:80],
                "note": str((item.get("payload") or {}).get("note", ""))[:120],
            })
            core.debug_controller.queue.append_event(ev_l3)

    return args, kwargs, route, handles

def _remove_paid_hooks(handles: list) -> None:
    for h in handles:
        try:
            h.remove()
        except Exception:
            pass


def _get_generate_input_ids(args: tuple, kwargs: dict):
    if args and hasattr(args[0], "shape"):
        return args[0], "args"
    if "input_ids" in kwargs:
        return kwargs["input_ids"], "kwargs"
    return None, "missing"


def _replace_generate_input_ids(args: tuple, kwargs: dict, new_input_ids, old_source: str):
    args = tuple(args or ())
    kwargs = dict(kwargs or {})
    if old_source == "args":
        args = (new_input_ids,) + args[1:]
    else:
        kwargs["input_ids"] = new_input_ids
    try:
        kwargs["attention_mask"] = new_input_ids.new_ones(new_input_ids.shape)
    except Exception:
        pass
    for k in ("position_ids", "token_type_ids"):
        kwargs.pop(k, None)
    return args, kwargs


def _encode_plain(tokenizer: Any, text: str) -> List[int]:
    try:
        return list(tokenizer.encode(str(text), add_special_tokens=False))
    except TypeError:
        return list(tokenizer(str(text), add_special_tokens=False)["input_ids"])


def _decode_generated_part(tokenizer: Any, out, input_len: int) -> str:
    try:
        ids = out[0][input_len:] if len(out.shape) > 1 else out[input_len:]
        return tokenizer.decode(ids, skip_special_tokens=True)
    except Exception:
        return ""



def _bis1_output_target_ready(text: str, payload: dict) -> tuple[bool, dict]:
    """Client-side target readiness guard for Output intercept.

    Prevents HodgeConverter from replacing a different candidate when the requested
    old_word/regex value has not appeared yet.
    """
    import re as _re
    stext = str(text or "")
    payload = dict(payload or {})
    selector = str(payload.get("selector", "") or "").strip().lower()
    target_regex = payload.get("target_regex")
    old_word = payload.get("old_word", payload.get("target_old_word", payload.get("target", None)))

    if target_regex is not None and str(target_regex).strip():
        try:
            m = _re.search(str(target_regex), stext)
        except Exception as exc:
            return False, {"reason": f"invalid_target_regex:{type(exc).__name__}:{exc}", "target_regex": str(target_regex)[:160]}
        if not m:
            return False, {"reason": "target_regex_not_ready", "target_regex": str(target_regex)[:160]}
        return True, {"ready_by": "target_regex", "span": [int(m.start()), int(m.end())]}

    if old_word is not None and str(old_word).strip():
        old = str(old_word)
        pos = stext.find(old)
        if pos < 0:
            return False, {"reason": "old_word_not_ready", "old_word_preview": old[:80]}
        return True, {"ready_by": "old_word", "span": [int(pos), int(pos + len(old))]}

    if selector in {"after_equals", "result_number"}:
        pat = r"(?<==\s*)\d+"
        m = _re.search(pat, stext)
        if not m:
            return False, {"reason": "after_equals_value_not_ready", "target_regex": pat}
        payload.setdefault("target_regex", pat)
        return True, {"ready_by": "after_equals_default", "span": [int(m.start()), int(m.end())], "target_regex": pat}

    return True, {"ready_by": "auto"}


def _bis1_stabilize_modified_prefix(new_partial_text: str, meta: dict, payload: dict) -> tuple[str, dict]:
    """Trim stale generated tail after the changed target span.

    Without this, output intercept can produce inconsistent tails such as
    '1 + 2 = 99 ... then add 3 ...' because only the first value was replaced
    while the already-generated continuation still references the old value.
    """
    meta = dict(meta or {})
    payload = dict(payload or {})
    enabled = str(payload.get("stabilize_prefix", payload.get("prefix_lock", "1"))).lower() not in {"0", "false", "no", "off"}
    if not enabled:
        return new_partial_text, {"stabilize_prefix": False}
    try:
        pos = int(meta.get("char_position", -1))
    except Exception:
        pos = -1
    new_preview = str(meta.get("new_text_preview", payload.get("new_word", payload.get("replacement", ""))) or "")
    if pos < 0 or not new_preview:
        return new_partial_text, {"stabilize_prefix": False, "reason": "missing char_position/new_text_preview"}
    cut = max(0, min(len(new_partial_text), pos + len(new_preview)))
    old_len = len(new_partial_text)
    trimmed_tail = new_partial_text[cut:]
    if cut <= 0 or cut >= old_len:
        return new_partial_text, {"stabilize_prefix": True, "trimmed": False, "cut": cut, "old_len": old_len}
    return new_partial_text[:cut], {
        "stabilize_prefix": True,
        "trimmed": True,
        "cut": cut,
        "old_len": old_len,
        "trimmed_tail_preview": trimmed_tail[:120],
    }

def _run_paid_output_hodge_intercept(
    *,
    core: BaseModelDebugCore,
    tokenizer: Any,
    original_generate,
    args: tuple,
    kwargs: dict,
    route: str,
    source: str,
):
    """Target-first output-side Hodge interception for paid runtime.

    S6.4:
      - Generate 1~2 token micro-prefix chunks.
      - Check whether the requested target actually appeared.
      - Stop immediately when target appears.
      - Call the API Hub / Modal server Hodge kernel.
      - Resume continuation from the patched prefix.

    This intentionally behaves like a dynamic debugger breakpoint: generation
    pauses at the pre-operation/target-ready boundary, performs a paid server
    patch, then continues from the patched prefix.  The user prompt text remains
    unchanged.
    """
    pending = list(getattr(core, "_pending_output_hodge_intercept", []) or [])
    core._pending_output_hodge_intercept = []
    if not pending:
        return None, route, None

    from .paid_local_ops import hodge_output_replace_text

    item = pending[0]
    for extra_item in pending[1:]:
        core.debug_controller.queue.append_event({
            "kind": "paid_output_intercept_skipped",
            "reason": "only one output intercept is applied per generate",
            "function_id": extra_item.get("function_id", "l2.hodge_output_intercept"),
            "payload_preview": str(extra_item.get("payload") or {})[:300],
            "source": source,
            "tier": "paid",
            "actual_model_event": True,
            "ts": time.time(),
        })

    payload = dict(item.get("payload") or {})
    function_id = item.get("function_id", "l2.hodge_output_intercept")

    if not bool(payload.get("_internal_from_hodge_auto")):
        core.debug_controller.queue.append_event({
            "kind": "paid_output_intercept_removed",
            "function_id": function_id,
            "reason": "public Output intercept was merged into HodgeConverter and removed from the product surface",
            "source": source,
            "tier": "paid",
            "actual_model_event": True,
            "ts": time.time(),
        })
        return None, route, None

    input_ids, input_source = _get_generate_input_ids(args, kwargs)
    if input_ids is None:
        core.debug_controller.queue.append_event({
            "kind": "paid_output_intercept_noop",
            "function_id": function_id,
            "reason": "input_ids missing",
            "source": source,
            "tier": "paid",
            "actual_model_event": True,
            "ts": time.time(),
        })
        return None, route, None

    try:
        original_max = int(kwargs.get("max_new_tokens", payload.get("max_new_tokens", 32)) or 32)
    except Exception:
        original_max = 32
    original_max = max(1, min(original_max, 4096))

    # Product field "wait_tokens" / hodge_wait_tokens now means:
    # maximum number of generated probe tokens before giving up and falling
    # back to a normal generate.  We do NOT generate a long fixed prefix first.
    try:
        wait_tokens = int(payload.get("hodge_wait_tokens", payload.get("wait_tokens", payload.get("stabilization_tokens", 8))) or 8)
    except Exception:
        wait_tokens = 8
    wait_tokens = max(1, min(wait_tokens, max(1, original_max), 128))

    try:
        probe_step = int(payload.get("probe_step_tokens", payload.get("target_probe_step", 1)) or 1)
    except Exception:
        probe_step = 1
    probe_step = max(1, min(probe_step, 2))

    try:
        input_len = int(input_ids.shape[-1])
    except Exception:
        input_len = 0

    try:
        row0 = [int(x) for x in input_ids.detach().clone()[0].tolist()]
    except Exception:
        row0 = []

    partial_ids: List[int] = []
    partial_text = ""
    partial_latency = 0.0
    target_ready = False
    target_ready_meta = {"reason": "target_first_not_started"}
    probe_steps = 0
    probe_tokens_generated = 0
    current_input = input_ids

    t_probe = time.perf_counter()
    for _ in range(wait_tokens):
        remaining = wait_tokens - probe_tokens_generated
        if remaining <= 0:
            break
        step_budget = max(1, min(probe_step, remaining))

        probe_args, probe_kwargs = _replace_generate_input_ids(args, kwargs, current_input, input_source)
        probe_kwargs["max_new_tokens"] = step_budget
        # stale position-like tensors are already removed by _replace_generate_input_ids.

        step_out = original_generate(*probe_args, **probe_kwargs)
        try:
            current_len = int(current_input.shape[-1])
            seq = step_out[0] if len(step_out.shape) > 1 else step_out
            new_piece = [int(x) for x in seq[current_len:].tolist()]
        except Exception:
            new_piece = []

        if not new_piece:
            target_ready_meta = {"reason": "target_first_empty_piece"}
            break

        partial_ids.extend(new_piece)
        probe_steps += 1
        probe_tokens_generated += len(new_piece)

        try:
            partial_text = tokenizer.decode(partial_ids, skip_special_tokens=True)
        except Exception:
            partial_text = ""

        target_ready, target_ready_meta = _bis1_output_target_ready(partial_text, payload)
        if target_ready:
            target_ready_meta = {
                **(target_ready_meta or {}),
                "target_first_stop": True,
                "probe_steps": probe_steps,
                "probe_tokens_generated": probe_tokens_generated,
                "probe_step_tokens": probe_step,
            }
            break

        # Prepare context for the next micro-probe: original prompt + generated prefix.
        if row0:
            try:
                current_input = input_ids.new_tensor([row0 + partial_ids])
            except Exception:
                target_ready_meta = {"reason": "target_first_current_input_build_failed"}
                break

    partial_latency = round(time.perf_counter() - t_probe, 4)
    partial_token_budget = probe_tokens_generated

    if not target_ready:
        try:
            prompt_preview_for_event = tokenizer.decode(input_ids[0], skip_special_tokens=True)[:240]
        except Exception:
            prompt_preview_for_event = ""
        core.debug_controller.queue.append_event({
            "kind": "paid_output_intercept_noop",
            "function_id": function_id,
            "op": item.get("op", "hodge_output_intercept"),
            "route": "L2_HODGE_OUTPUT_INTERCEPT",
            "changed": False,
            "meta": {
                **(target_ready_meta or {}),
                "target_first_probe": True,
                "target_first_breakpoint": False,
                "probe_steps": probe_steps,
                "probe_tokens_generated": probe_tokens_generated,
                "hodge_wait_tokens": wait_tokens,
                "probe_step_tokens": probe_step,
            },
            "source": source,
            "tier": "paid",
            "actual_model_event": True,
            "preview_only": False,
            "partial_preview": partial_text[:180],
            "prompt_preview": prompt_preview_for_event,
            "ts": time.time(),
        })
        t_full = time.perf_counter()
        out = original_generate(*args, **kwargs)
        return out, route, round(time.perf_counter() - t_full, 4)

    if target_ready_meta.get("target_regex") and not payload.get("target_regex"):
        payload["target_regex"] = target_ready_meta.get("target_regex")

    new_partial_text, changed, meta = hodge_output_replace_text(partial_text, payload)
    try:
        prompt_preview_for_event = tokenizer.decode(input_ids[0], skip_special_tokens=True)[:240]
    except Exception:
        prompt_preview_for_event = ""

    base_event = {
        "function_id": function_id,
        "op": item.get("op", "hodge_output_intercept"),
        "source": source,
        "tier": "paid",
        "actual_model_event": True,
        "preview_only": False,
        "after_tokens": probe_tokens_generated,
        "partial_token_budget": partial_token_budget,
        "hodge_wait_tokens": wait_tokens,
        "probe_step_tokens": probe_step,
        "probe_steps": probe_steps,
        "target_first_probe": True,
        "target_first_breakpoint": True,
        "partial_latency_sec": partial_latency,
        "partial_preview": partial_text[:180],
        "prompt_preview": prompt_preview_for_event,
        "command_payload_public": {
            "old_word": str(payload.get("old_word", ""))[:80],
            "new_word": str(payload.get("new_word", payload.get("value", payload.get("replacement", ""))))[:80],
            "target_regex": str(payload.get("target_regex", ""))[:120],
            "wait_tokens": str(payload.get("hodge_wait_tokens", payload.get("wait_tokens", "")))[:40],
            "continuation_tokens": str(payload.get("continuation_tokens", ""))[:40],
        },
        "ts": time.time(),
    }

    if not changed:
        ev = dict(base_event)
        ev.update({
            "kind": "paid_output_intercept_noop",
            "route": "L2_HODGE_OUTPUT_INTERCEPT",
            "changed": False,
            "meta": {
                **(meta or {}),
                **(target_ready_meta or {}),
                "target_first_probe": True,
                "target_first_server_nochange": True,
            },
        })
        core.debug_controller.queue.append_event(ev)
        t_full = time.perf_counter()
        out = original_generate(*args, **kwargs)
        return out, route, round(time.perf_counter() - t_full, 4)

    # In target-first mode the prefix is already stopped at target readiness, so
    # stale tails should be minimal.  If the legacy stabilizer is available, let
    # it perform a conservative cut; otherwise use the server-returned partial.
    try:
        stable_text, stable_meta = _bis1_stabilize_modified_prefix(new_partial_text, meta or {}, payload)
    except Exception:
        stable_text, stable_meta = new_partial_text, {"stabilize_prefix": False, "reason": "stabilizer_unavailable"}
    if stable_text != new_partial_text:
        new_partial_text = stable_text
        meta = {**(meta or {}), **stable_meta}
    else:
        meta = {**(meta or {}), **stable_meta}

    prefix_ids = _encode_plain(tokenizer, new_partial_text)
    if not prefix_ids:
        ev = dict(base_event)
        ev.update({
            "kind": "paid_output_intercept_noop",
            "route": "L2_HODGE_OUTPUT_INTERCEPT",
            "changed": False,
            "meta": {"reason": "modified partial re-encoded empty", **(meta or {})},
        })
        core.debug_controller.queue.append_event(ev)
        t_full = time.perf_counter()
        out = original_generate(*args, **kwargs)
        return out, route, round(time.perf_counter() - t_full, 4)

    try:
        base_row = row0 if row0 else [int(x) for x in input_ids.detach().clone()[0].tolist()]
        combined = input_ids.new_tensor([base_row + prefix_ids])
    except Exception as exc:
        ev = dict(base_event)
        ev.update({
            "kind": "paid_output_intercept_noop",
            "route": "L2_HODGE_OUTPUT_INTERCEPT",
            "changed": False,
            "meta": {"reason": f"combined input build failed: {type(exc).__name__}: {exc}", **(meta or {})},
        })
        core.debug_controller.queue.append_event(ev)
        t_full = time.perf_counter()
        out = original_generate(*args, **kwargs)
        return out, route, round(time.perf_counter() - t_full, 4)

    cont_args, cont_kwargs = _replace_generate_input_ids(args, kwargs, combined, input_source)
    try:
        continuation_tokens = int(payload.get("continuation_tokens", max(0, original_max - probe_tokens_generated)) or 0)
    except Exception:
        continuation_tokens = max(0, original_max - probe_tokens_generated)
    continuation_tokens = max(0, min(continuation_tokens, 256))
    cont_kwargs["max_new_tokens"] = continuation_tokens

    t_cont = time.perf_counter()
    if continuation_tokens > 0:
        out = original_generate(*cont_args, **cont_kwargs)
    else:
        out = combined
    cont_latency = round(time.perf_counter() - t_cont, 4)

    route = _route_with_paid(route, "L2_HODGE_OUTPUT_INTERCEPT")
    ev = dict(base_event)
    ev.update({
        "kind": "paid_output_intercept_applied",
        "route": "L2_HODGE_OUTPUT_INTERCEPT",
        "changed": True,
        "meta": {
            **(meta or {}),
            **(target_ready_meta or {}),
            "continuation_tokens": continuation_tokens,
            "modified_partial_preview": new_partial_text[:180],
            "partial_token_len": len(prefix_ids),
            "original_max_new_tokens": original_max,
            "prompt_text_unchanged": True,
            "output_prefix_mutated": True,
            "s6_remote_output_fallback": True,
            "s6_4_target_first_breakpoint": True,
            "target_first_probe": True,
            "probe_steps": probe_steps,
            "probe_tokens_generated": probe_tokens_generated,
            "probe_step_tokens": probe_step,
            "debugger_paused_for_l2_patch": True,
        },
        "continuation_latency_sec": cont_latency,
    })
    core.debug_controller.queue.append_event(ev)
    return out, route, round(partial_latency + cont_latency, 4)


def _generate_wrapper(
    *,
    core: BaseModelDebugCore,
    tokenizer: Any,
    original_generate,
    args: tuple,
    kwargs: dict,
    enable_l1: bool,
    enable_capture: bool,
) -> Any:
    """
    model.generate 래퍼 내부 구현.

    v1.3 patch:
    - L1 rewrite 적용 후 prompt_preview 를 새 프롬프트 기준으로 갱신.
    - positional input_ids + old attention_mask 조합에서도 새 attention_mask 로 교체.
    - capture route 를 ATTACHED_GENERATE / L1_REWRITE_ATTACHED_GENERATE 로 구분.
    - caller kwargs 원본을 오염시키지 않도록 shallow copy 사용.
    """
    kwargs = dict(kwargs or {})
    args = tuple(args or ())

    def _decode_input_preview(_args: tuple, _kwargs: dict) -> str:
        try:
            if _args and hasattr(_args[0], "shape"):
                return tokenizer.decode(_args[0][0], skip_special_tokens=True)[:240]
            if "input_ids" in _kwargs:
                return tokenizer.decode(_kwargs["input_ids"][0], skip_special_tokens=True)[:240]
        except Exception:
            return ""
        return ""

    prompt_preview = _decode_input_preview(args, kwargs)

    core.debug_controller.poll_and_checkpoint(
        core,
        "before_generate",
        {"prompt_preview": prompt_preview[:120], "prompt_len": len(prompt_preview)},
        "attach_debugger",
    )
    _wait_if_paused(core, phase="before_generate", source="attach_debugger")

    rewrite_applied = False
    route = "ATTACHED_GENERATE"

    if enable_l1 and getattr(core, "_pending_prompt_rewrite", ""):
        new_prompt = str(core._pending_prompt_rewrite)
        core._pending_prompt_rewrite = ""
        try:
            device = None
            if args and hasattr(args[0], "device"):
                device = args[0].device
            elif "input_ids" in kwargs and hasattr(kwargs["input_ids"], "device"):
                device = kwargs["input_ids"].device

            new_inputs = tokenizer(
                new_prompt,
                return_tensors="pt",
                truncation=True,
                max_length=4096,
            )
            if device is not None:
                new_inputs = {k: v.to(device) for k, v in new_inputs.items()}

            # 기존 input 관련 kwargs 제거 후 새 입력 삽입
            # generate(**inputs) 방식과 generate(input_ids, attention_mask=...) 방식 둘 다 지원
            for old_key in ("input_ids", "attention_mask", "token_type_ids", "position_ids"):
                kwargs.pop(old_key, None)

            if args and hasattr(args[0], "shape"):
                # positional input_ids 교체, 나머지 kwargs 로 추가
                args = (new_inputs["input_ids"],) + args[1:]
                for k, v in new_inputs.items():
                    if k != "input_ids":
                        kwargs[k] = v
            else:
                kwargs.update(new_inputs)

            # ★ prompt_preview 를 새 프롬프트 기준으로 갱신
            prompt_preview = new_prompt[:240]
            rewrite_applied = True
            route = "L1_REWRITE_ATTACHED_GENERATE"

            core.debug_controller.queue.append_event({
                "kind": "l1_prompt_rewrite_applied",
                "new_prompt_len": len(new_prompt),
                "new_prompt_preview": new_prompt[:120],
                "ts": time.time(),
                "tier": "free_l1",
            })
            logger.info("[attach_debugger] L1 rewrite applied: %d chars", len(new_prompt))

        except Exception as e:
            core.debug_controller.queue.append_event({
                "kind": "l1_prompt_rewrite_failed",
                "error": f"{type(e).__name__}: {e}",
                "ts": time.time(),
                "tier": "free_l1",
            })
            logger.warning("[attach_debugger] L1 rewrite 적용 실패: %s", e)


    # v1.10: 예약형 L1 mid-turn rewrite.
    # 1) 다음 generate에서 짧은 partial을 먼저 생성한다.
    # 2) 사용자에게 최종 답변을 반환하기 전에 mid_generate_l1_wait 상태로 멈춘다.
    # 3) 대시보드에서 L1 새 프롬프트를 넣고 resume하면 기존 partial을 버리고 새 프롬프트로 재생성한다.
    if enable_l1 and (not rewrite_applied) and getattr(core, "_l1_mid_rewrite_armed", False):
        try:
            after_tokens = int(getattr(core, "_l1_mid_rewrite_after_tokens", 8) or 8)
        except Exception:
            after_tokens = 8
        after_tokens = max(1, min(after_tokens, 64))
        core._l1_mid_rewrite_armed = False

        partial_kwargs = dict(kwargs)
        partial_kwargs["max_new_tokens"] = after_tokens
        partial_preview = ""
        partial_latency = 0.0
        try:
            t_mid = time.perf_counter()
            partial_out = original_generate(*args, **partial_kwargs)
            partial_latency = round(time.perf_counter() - t_mid, 4)
            try:
                if args and hasattr(args[0], "shape"):
                    input_len = int(args[0].shape[-1])
                elif "input_ids" in kwargs:
                    input_len = int(kwargs["input_ids"].shape[-1])
                else:
                    input_len = 0
                partial_ids = partial_out[0][input_len:] if len(partial_out.shape) > 1 else partial_out[input_len:]
                partial_preview = tokenizer.decode(partial_ids, skip_special_tokens=True).strip()[:240]
            except Exception:
                partial_preview = ""
            core.debug_controller.queue.append_event({
                "kind": "l1_mid_rewrite_partial_generated",
                "after_tokens": after_tokens,
                "partial_preview": partial_preview[:160],
                "latency_sec": partial_latency,
                "ts": time.time(),
                "tier": "free_l1",
            })
            core._wait_for_l1_mid_rewrite(
                phase="mid_generate",
                source="attach_debugger",
                partial_preview=partial_preview,
                prompt_preview=prompt_preview,
            )
        except RuntimeError:
            raise
        except Exception as e:
            core.debug_controller.queue.append_event({
                "kind": "l1_mid_rewrite_partial_failed",
                "error": f"{type(e).__name__}: {e}",
                "ts": time.time(),
                "tier": "free_l1",
            })

        if getattr(core, "_pending_prompt_rewrite", ""):
            new_prompt = str(core._pending_prompt_rewrite)
            core._pending_prompt_rewrite = ""
            try:
                device = None
                if args and hasattr(args[0], "device"):
                    device = args[0].device
                elif "input_ids" in kwargs and hasattr(kwargs["input_ids"], "device"):
                    device = kwargs["input_ids"].device

                new_inputs = tokenizer(
                    new_prompt,
                    return_tensors="pt",
                    truncation=True,
                    max_length=4096,
                )
                if device is not None:
                    new_inputs = {k: v.to(device) for k, v in new_inputs.items()}

                for old_key in ("input_ids", "attention_mask", "token_type_ids", "position_ids"):
                    kwargs.pop(old_key, None)

                if args and hasattr(args[0], "shape"):
                    args = (new_inputs["input_ids"],) + args[1:]
                    for k, v in new_inputs.items():
                        if k != "input_ids":
                            kwargs[k] = v
                else:
                    kwargs.update(new_inputs)

                prompt_preview = new_prompt[:240]
                rewrite_applied = True
                route = "L1_MID_REWRITE_ATTACHED_GENERATE"
                core.debug_controller.queue.append_event({
                    "kind": "l1_mid_rewrite_applied",
                    "new_prompt_len": len(new_prompt),
                    "new_prompt_preview": new_prompt[:120],
                    "discarded_partial_preview": partial_preview[:120],
                    "ts": time.time(),
                    "tier": "free_l1",
                })
                logger.info("[attach_debugger] L1 mid rewrite applied: %d chars", len(new_prompt))
            except Exception as e:
                core.debug_controller.queue.append_event({
                    "kind": "l1_mid_rewrite_failed",
                    "error": f"{type(e).__name__}: {e}",
                    "ts": time.time(),
                    "tier": "free_l1",
                })
                logger.warning("[attach_debugger] L1 mid rewrite 적용 실패: %s", e)
        else:
            route = "L1_MID_REWRITE_NOOP_ATTACHED_GENERATE"
            core.debug_controller.queue.append_event({
                "kind": "l1_mid_rewrite_noop",
                "discarded_partial_preview": partial_preview[:120],
                "ts": time.time(),
                "tier": "free_l1",
            })

    args, kwargs, route, paid_hooks = _apply_pending_paid_surgery_to_generate(
        core, tokenizer, args, kwargs, route, source="attach_debugger"
    )
    prompt_preview = _decode_input_preview(args, kwargs) or prompt_preview

    t0 = time.perf_counter()
    try:
        intercepted = _run_paid_output_hodge_intercept(
            core=core,
            tokenizer=tokenizer,
            original_generate=original_generate,
            args=args,
            kwargs=kwargs,
            route=route,
            source="attach_debugger",
        )
        if intercepted and intercepted[0] is not None:
            out, route, intercept_latency = intercepted
            latency = float(intercept_latency if intercept_latency is not None else round(time.perf_counter() - t0, 4))
        else:
            out = original_generate(*args, **kwargs)
            latency = round(time.perf_counter() - t0, 4)
    finally:
        _remove_paid_hooks(paid_hooks)

    answer_preview = ""
    try:
        if args and hasattr(args[0], "shape"):
            input_len = int(args[0].shape[-1])
        elif "input_ids" in kwargs:
            input_len = int(kwargs["input_ids"].shape[-1])
        else:
            input_len = 0
        new_ids = out[0][input_len:] if len(out.shape) > 1 else out[input_len:]
        answer_preview = tokenizer.decode(new_ids, skip_special_tokens=True).strip()[:240]
    except Exception as e:
        answer_preview = ""
        logger.debug("[attach_debugger] answer preview decode failed: %s", e)

    if enable_capture:
        # ── Extract per-layer hidden states for IRS-DCE ──
        # Per 2026-05-03 user policy: OBDA/IRSDCE/geometry are public-free,
        # so we capture per-layer hidden states here.  This is read by
        # `bdp_insight.indicators.irsdce_dynamics.analyze_capture_run`
        # (the static debugger's IRS-DCE Dynamics tab).
        #
        # IMPORTANT — shape: list[layer] of list[T tokens × H hidden].
        # PR_s.py's PCA / participation_ratio / stringiness need a TOKEN
        # MATRIX per layer, not just the last token.  Storing only the
        # last token would make ID always 1.0 and PC1r always 0.0
        # (degenerate single-point cloud).
        #
        # Failure of this block must NEVER break capture itself — if the
        # forward pass errors out (OOM / device mismatch / etc.), we fall
        # back to capture without hidden states.
        hidden_states_per_layer = None
        try:
            import torch as _torch
            with _torch.no_grad():
                # Use the FINAL output sequence as input to one forward pass
                # so we get hidden states for the realised answer.
                if len(out.shape) > 1:
                    final_ids = out[0]
                else:
                    final_ids = out
                # Cap to avoid huge tensors on long generations.
                # 256 tokens × 42 layers × 4096 hidden × 4 bytes ≈ 170 MB
                # JSON serialised ≈ 2× that — manageable on CPU/8GB GPU.
                MAX_TOKENS_FOR_HS = 256
                if final_ids.shape[-1] > MAX_TOKENS_FOR_HS:
                    final_ids = final_ids[..., -MAX_TOKENS_FOR_HS:]
                fwd_kwargs = {
                    "input_ids":             final_ids.unsqueeze(0)
                                              if final_ids.dim() == 1 else final_ids,
                    "output_hidden_states":  True,
                    "return_dict":           True,
                    "use_cache":             False,
                }
                fwd_out = core.model(**fwd_kwargs)
                hs = getattr(fwd_out, "hidden_states", None)
                if hs is not None:
                    # hs is tuple[len = n_layers + 1] of tensor(B, T, H).
                    # We keep ALL tokens of the realised sequence so
                    # PR_s's per-layer PCA / participation_ratio /
                    # stringiness are well-defined (T-point cloud, not 1).
                    hidden_states_per_layer = []
                    for layer_h in hs:
                        # layer_h: (1, T, H) — drop batch dim, keep all tokens
                        token_matrix = layer_h[0, :, :].detach().to(_torch.float32)
                        # Optional: down-sample H to keep payload modest if
                        # the model is large (4096+ hidden).  We use a
                        # deterministic stride that preserves variance.
                        H = token_matrix.shape[-1]
                        STRIDE_THRESHOLD = 1024
                        if H > STRIDE_THRESHOLD:
                            stride = max(1, H // STRIDE_THRESHOLD)
                            token_matrix = token_matrix[:, ::stride]
                        hidden_states_per_layer.append(
                            token_matrix.cpu().numpy().tolist()
                        )
        except Exception as _hs_exc:
            logger.debug("[attach_debugger] hidden-state capture skipped: %s",
                         _hs_exc)
            hidden_states_per_layer = None

        try:
            core.capture_writer.write_run(
                prompt_preview,   # ★ L1 적용됐으면 새 프롬프트 기준
                {
                    "answer":      answer_preview,
                    "latency_sec": latency,
                    "route":       route,
                    # IRS-DCE 무료 공개 정책 (2026-05-03) — 옵셔널 키:
                    "hidden_states_per_layer": hidden_states_per_layer,
                },
                model_id=core.model_id,
                route=route,      # ★ route 구분
            )
        except Exception as e:
            logger.warning("[attach_debugger] capture 실패: %s", e)

    core.debug_controller.poll_and_checkpoint(
        core,
        "after_generate",
        {
            "answer_preview": answer_preview[:80],
            "latency_sec": latency,
            "l1_rewrite_applied": rewrite_applied,
            "route": route,
        },
        "attach_debugger",
    )

    try:
        atomic_write_json(Path(core.run_dir) / "dynamic_debug" / "runtime_status.json", {
            "ok": True,
            "source": "attach_debugger",
            "ts": time.time(),
            "last_route": route,
            "status": core.status(),
            "entitlement": getattr(getattr(core, "entitlement", None), "public_dict", lambda: {})(),
        })
    except Exception as exc:
        core.debug_controller.queue.append_event({
            "kind": "runtime_status_write_failed",
            "error": f"{type(exc).__name__}: {exc}",
            "ts": time.time(),
        })

    logger.info(
        "[attach_debugger] generate done route=%s latency=%.3fs answer=%r",
        route, latency, answer_preview[:40],
    )
    return out

# ─────────────────────────────────────────────────────────────────────────────
# MRISession
# ─────────────────────────────────────────────────────────────────────────────

class MRISession:
    """
    attach()가 반환하는 디버거 세션.

    모든 generate 호출은 .run() 을 통해 이루어진다.
    MRI 캡처와 L1 rewrite 적용이 자동으로 처리된다.

    사용 예 (기존 하네스에 붙이기):
        # 기존 코드
        for prompt in my_prompts:
            answer = my_model.generate(prompt)   # ← 기존

        # MRI 붙인 코드 (한 줄 추가)
        dbg = attach("model_name", max_new_tokens=64)
        for prompt in my_prompts:
            r = dbg.run(prompt)                  # ← 교체
            answer = r["answer"]
    """

    def __init__(self, core: BaseModelDebugCore, *, max_new_tokens: int = 128):
        self._core = core
        self._max_new_tokens = max_new_tokens
        self._run_count = 0
        self._dashboard_thread: Optional[threading.Thread] = None

    # ── generate ──────────────────────────────────────────────────────────
    def run(
        self,
        prompt: str,
        *,
        max_new_tokens: Optional[int] = None,
        temperature: float = 0.0,
        capture: bool = True,
    ) -> Dict[str, Any]:
        """
        프롬프트를 실행하고 결과 dict를 반환한다.

        큐에 L1 rewrite 명령이 있으면 generate 직전에 자동 적용된다.

        Parameters
        ----------
        prompt        : 실행할 프롬프트
        max_new_tokens: 이 호출에만 적용할 토큰 수 (없으면 attach() 기본값 사용)
        temperature   : 0.0 = greedy, > 0 = sampling
        capture       : False면 MRI 파일 저장 생략

        Returns
        -------
        dict with keys:
            answer          : str
            latency_sec     : float
            route           : str  ("BASE")
            capture_session_id : str (capture=True일 때)
            tier            : "free"
        """
        tokens = max_new_tokens if max_new_tokens is not None else self._max_new_tokens
        result = self._core.run(
            prompt,
            max_new_tokens=tokens,
            temperature=temperature,
            capture=capture,
        )
        self._run_count += 1
        logger.info("[run] #%d answer=%r latency=%.3fs",
                    self._run_count, str(result.get("answer", ""))[:40],
                    result.get("latency_sec", 0))
        return result

    def run_batch(
        self,
        prompts: List[str],
        **kwargs,
    ) -> List[Dict[str, Any]]:
        """여러 프롬프트 순차 실행."""
        return [self.run(p, **kwargs) for p in prompts]

    # ── L1 ────────────────────────────────────────────────────────────────
    def l1_rewrite(self, new_prompt: str) -> Dict[str, Any]:
        """
        다음 run() 에서 사용할 프롬프트를 교체한다 (L1 free).

        run()에 어떤 prompt를 넘기든 new_prompt로 교체되어 실행된다.
        한 번 적용되면 초기화된다 (1회성).

        Returns
        -------
        {"ok": True, "tier": "free_l1", "cmd": {...}}
        """
        q = CommandQueue(Path(self._core.run_dir))
        cmd = q.push_command("rewrite_prompt", new_prompt=new_prompt)
        logger.info("[l1_rewrite] queued %d chars", len(new_prompt))
        return {"ok": True, "tier": "free_l1", "cmd": cmd}

    # ── dashboard ──────────────────────────────────────────────────────────
    def dashboard(
        self,
        host: str = "127.0.0.1",
        port: int = 7860,
        *,
        open_browser: bool = True,
        blocking: bool = True,
        run_dir: Optional[str] = None,
        capture_dir: Optional[str] = None,
    ) -> None:
        """
        Flask 대시보드 + 프롤로그를 실행한다.

        브라우저에서 http://{host}:{port} 접속.
        첫 방문 시 인터랙티브 프롤로그 팝업이 자동으로 표시된다.

        Parameters
        ----------
        host         : Flask 바인드 주소 (기본 127.0.0.1)
        port         : 포트 번호 (기본 7860)
        open_browser : True면 1초 후 브라우저 자동 오픈
        blocking     : True면 Ctrl-C 전까지 블로킹 (기본 True)
                       False면 백그라운드 스레드로 실행
        """
        from .dashboard_min import create_app

        app = create_app(
            capture_dir=capture_dir or self._core.outdir,
            run_dir=run_dir or self._core.run_dir,
        )

        if open_browser:
            def _open():
                time.sleep(1.2)
                webbrowser.open(f"http://{host}:{port}")
            threading.Thread(target=_open, daemon=True).start()

        logger.info("[dashboard] http://%s:%d  (blocking=%s)", host, port, blocking)
        if blocking:
            app.run(host=host, port=port, debug=False, use_reloader=False)
        else:
            self._dashboard_thread = threading.Thread(
                target=lambda: app.run(host=host, port=port, debug=False,
                                       use_reloader=False),
                daemon=True,
            )
            self._dashboard_thread.start()
            logger.info("[dashboard] 백그라운드 실행 중 http://%s:%d", host, port)

    # ── selftest ───────────────────────────────────────────────────────────
    def selftest(self) -> Dict[str, Any]:
        """
        무료 정책 selftest.

        L1 허용 / L2·L3 차단 / L4 excluded / ephemeral_lease 보안 검증.
        """
        from .selftest import run_selftest
        return run_selftest()

    # ── status ─────────────────────────────────────────────────────────────
    def status(self) -> Dict[str, Any]:
        s = self._core.status()
        s["session_run_count"] = self._run_count
        s["max_new_tokens"] = self._max_new_tokens
        return s

    # ── 직접 접근 (기존 하네스 호환) ─────────────────────────────────────
    @property
    def model(self) -> Any:
        """BaseModelDebugCore가 래핑한 원본 모델."""
        return self._core.model

    @property
    def tokenizer(self) -> Any:
        """BaseModelDebugCore가 래핑한 원본 토크나이저."""
        return self._core.tokenizer

    @property
    def core(self) -> BaseModelDebugCore:
        """BaseModelDebugCore 직접 접근 (고급 사용자용)."""
        return self._core

    def __repr__(self) -> str:
        return (f"<MRISession model={self._core.model_id!r} "
                f"runs={self._run_count} "
                f"max_new_tokens={self._max_new_tokens}>")


# ─────────────────────────────────────────────────────────────────────────────
# HF 모델 로더
# ─────────────────────────────────────────────────────────────────────────────

def _load_hf_model(
    name: str,
    *,
    device: str,
    load_in_8bit: bool,
    trust_remote_code: bool,
):
    try:
        from transformers import AutoModelForCausalLM, AutoTokenizer
    except ImportError as e:
        raise ImportError(
            "transformers 패키지가 필요합니다:\n"
            "  pip install meta13-mri[hf]\n"
            "또는\n"
            "  pip install torch transformers"
        ) from e

    tok = AutoTokenizer.from_pretrained(name, trust_remote_code=trust_remote_code)
    if getattr(tok, "pad_token_id", None) is None:
        tok.pad_token_id = tok.eos_token_id

    kw: Dict[str, Any] = {"trust_remote_code": trust_remote_code}

    if load_in_8bit:
        kw["load_in_8bit"] = True
        kw["device_map"] = "auto"
    elif device == "auto":
        try:
            import torch
            if torch.cuda.is_available():
                kw["torch_dtype"] = torch.float16
                kw["device_map"] = "auto"
            else:
                kw["torch_dtype"] = torch.float32
        except ImportError:
            pass
    elif device == "cpu":
        try:
            import torch
            kw["torch_dtype"] = torch.float32
        except ImportError:
            pass
    else:  # "cuda"
        try:
            import torch
            kw["torch_dtype"] = torch.float16
            kw["device_map"] = device
        except ImportError:
            pass

    mdl = AutoModelForCausalLM.from_pretrained(name, **kw)
    if device == "cpu" and "device_map" not in kw:
        try:
            mdl = mdl.to("cpu")
        except Exception:
            pass
    mdl.eval()
    return mdl, tok
