from __future__ import annotations
import json
import os
import time
from pathlib import Path
from typing import Any, Dict
from flask import Flask, jsonify, render_template_string, request, session
from .atomic import atomic_write_json


def _read_json(path: Path, default: Any = None) -> Any:
    try:
        if path.exists(): return json.loads(path.read_text(encoding='utf-8'))
    except Exception: pass
    return default


_DASHBOARD_HTML = """<!doctype html>
<html lang="ko">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Meta-13 MRI Free Debugger</title>
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'JetBrains Mono','Fira Code',monospace;background:#0e0e0f;color:#e8e8ec;min-height:100vh}
.topbar{display:flex;align-items:center;gap:10px;padding:9px 16px;background:#161618;border-bottom:1px solid #2a2a2e}
.topbar h1{font-size:13px;color:#4a9eff;font-weight:500}
.tag{font-size:10px;padding:2px 8px;border-radius:3px}
.tag-free{background:#0d2a0d;border:1px solid #3dd68c;color:#3dd68c}
.tag-model{background:#0d1f3a;border:1px solid #4a9eff;color:#4a9eff}
.main{display:grid;grid-template-columns:1fr 1fr;gap:12px;padding:14px;max-width:1200px;margin:0 auto}
.card{background:#161618;border:1px solid #2a2a2e;border-radius:8px;padding:14px}
.card-title{font-size:10px;text-transform:uppercase;letter-spacing:.1em;color:#55556a;margin-bottom:10px}
.row{display:flex;justify-content:space-between;font-size:12px;padding:4px 0;border-bottom:1px solid #1e1e21}
.row:last-child{border-bottom:none}
.rk{color:#8888a0}.rv{color:#e8e8ec}
#debug-route{color:#3dd68c}
#debug-deff{color:#f5a623}
pre{background:#0a0a0b;border:1px solid #2a2a2e;border-radius:5px;padding:10px;
    font-size:10px;white-space:pre-wrap;max-height:260px;overflow-y:auto;color:#b0b0c0}
.surgery-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:6px;margin-top:8px}
.sc{border:1px solid #2a2a2e;border-radius:6px;padding:8px 6px;text-align:center;
    background:#1e1e21;cursor:pointer;transition:all .12s}
.sc:hover:not(.locked){border-color:#3a3a40}
.sc.l1{border-color:#3dd68c;background:#0d1f12;cursor:pointer}
.sc.locked{opacity:.5;cursor:not-allowed}
.st{font-size:9px;color:#55556a;text-transform:uppercase;letter-spacing:.08em}
.sn{font-size:11px;margin-top:2px;color:#e8e8ec}
.ss{font-size:9px;color:#55556a;margin-top:2px}
.egg{font-size:9px;padding:1px 5px;background:#2a1a00;border:1px solid #5a3a00;
     border-radius:2px;color:#f5a623;display:inline-block;margin-top:2px}
.l1panel{display:block;margin-top:10px;border:1px solid #26312a;background:#101812;border-radius:7px;padding:10px}
.static-title{font-size:10px;text-transform:uppercase;letter-spacing:.09em;color:#3dd68c;margin-bottom:8px}
.static-help{font-size:9px;color:#77778a;line-height:1.45;margin:7px 0}
.l1tools{display:flex;flex-wrap:wrap;gap:6px;margin-top:7px}
.tokenctl{display:flex;align-items:center;gap:6px;margin-top:7px;font-size:10px;color:#8888a0}
.tokenctl input{width:58px;background:#0a0a0b;border:1px solid #2a2a2e;border-radius:4px;color:#e8e8ec;padding:4px 6px;font-family:inherit;font-size:10px}
.midstatus{font-size:10px;color:#f5a623;margin-top:8px;min-height:14px}
.midpreview{margin-top:6px;background:#09090a;border:1px solid #242428;border-radius:5px;padding:7px;font-size:10px;color:#b8b8c8;max-height:80px;overflow-y:auto;white-space:pre-wrap}
.cmdbar{display:flex;flex-wrap:wrap;gap:6px;margin-top:10px}
.cmdbar .btn{font-size:9px;padding:5px 8px}
.cmdnote{font-size:9px;color:#66667a;margin-top:7px;line-height:1.4}
.l1form{display:flex;gap:6px}
.l1form input{flex:1;background:#0a0a0b;border:1px solid #2a2a2e;border-radius:4px;
              padding:6px 8px;color:#e8e8ec;font-family:inherit;font-size:11px}
.l1form input:focus{outline:none;border-color:#3dd68c}
.btn{padding:5px 12px;border-radius:4px;border:1px solid #2a2a2e;background:#1e1e21;
     color:#8888a0;font-family:inherit;font-size:10px;cursor:pointer;transition:all .12s}
.btn:hover{border-color:#4a9eff;color:#4a9eff}
.btn-l1{border-color:#3dd68c;color:#3dd68c;background:#0d1f12}
.btn-l1:hover{background:#0d2a14}
.evts{max-height:220px;overflow-y:auto}
.evt{font-size:10px;color:#55556a;padding:2px 0;border-bottom:1px solid #1e1e21}
.evt .ek{color:#4a9eff}.evt .ev{color:#8888a0}

.paidpanel{display:block;margin-top:10px;border:1px solid #332f43;background:#14121b;border-radius:7px;padding:10px}
.paid-title{font-size:10px;text-transform:uppercase;letter-spacing:.09em;color:#b58cff;margin-bottom:8px}
.paid-grid{display:grid;grid-template-columns:1fr;gap:7px}
.paid-card{border:1px solid #2a2a36;background:#111117;border-radius:6px;padding:8px}
.paid-card h4{font-size:10px;color:#e8e8ec;margin-bottom:4px;font-weight:500}
.paid-card p{font-size:9px;color:#77778a;line-height:1.4;margin-bottom:6px}
.paid-card .btn{border-color:#5d4a7d;color:#b58cff;background:#171020}
.paid-card .btn:hover{border-color:#b58cff;color:#d7c1ff}
.paid-status-line{font-size:10px;color:#b58cff;margin:4px 0 7px 0}
.paid-form{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:5px;margin:6px 0}
.paid-form label{display:flex;flex-direction:column;gap:3px;font-size:8px;color:#77778a}
.paid-form input,.paid-form select{background:#0a0a0b;border:1px solid #2a2a36;border-radius:4px;color:#e8e8ec;padding:5px 6px;font-family:inherit;font-size:10px;min-width:0}
.paid-form input:focus,.paid-form select:focus{outline:none;border-color:#b58cff}
.paid-unlocked{border-color:#3dd68c!important;background:#0b1912!important}
.paid-unlocked .ss{color:#3dd68c}
.badge{display:inline-block;font-size:8px;border:1px solid #33333d;border-radius:3px;padding:1px 4px;margin-right:4px;text-transform:uppercase;letter-spacing:.05em}
.badge-actual{border-color:#2a8055;color:#3dd68c;background:#07140d}
.badge-blocked{border-color:#80672a;color:#f5c542;background:#1b1608}
.badge-preview{border-color:#5d4a7d;color:#b58cff;background:#171020}
.badge-sim{border-color:#385072;color:#7fb2ff;background:#0b1320}
.badge-error{border-color:#7d3030;color:#ff7474;background:#1b0808}
.paid-sep{margin-top:12px;padding-top:10px;border-top:1px dashed #2e3a4f;color:#b58cff;font-size:12px;text-transform:uppercase;letter-spacing:.04em}

.safegrid{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:8px}
.safeitem{background:#0b0b0d;border:1px solid #24242a;border-radius:5px;padding:7px;font-size:10px;color:#b9b9c8;min-height:32px}
.safeitem b{color:#e8e8ec;font-weight:500}
.tabbar{display:flex;flex-wrap:wrap;gap:5px;margin:6px 0 8px 0}
.tabbar .btn{font-size:9px;padding:4px 7px}
.public-safe-note{font-size:9px;color:#77778a;line-height:1.45;margin-top:7px;border-top:1px dashed #2a2a36;padding-top:7px}
.focus-row{display:grid;grid-template-columns:34px 1fr 96px 64px;gap:5px;font-size:10px;padding:3px 0;border-bottom:1px solid #1e1e21}
.focus-row span{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.graph-node{display:inline-block;border:1px solid #34415a;background:#0b1320;border-radius:4px;padding:2px 5px;margin:2px;font-size:10px;color:#9fc5ff}
.graph-edge{font-size:9px;color:#77778a;margin:2px 0}
.focus-row.focus-click{cursor:pointer;border-radius:4px;padding:4px 3px}
.focus-row.focus-click:hover{background:#101824;border-color:#2f4d78}
.focus-actions{display:flex;gap:4px;flex-wrap:wrap;justify-content:flex-end}
.mini-btn{font-size:8px;padding:2px 5px;border-radius:3px;border:1px solid #34415a;background:#0b1320;color:#9fc5ff;cursor:pointer;font-family:inherit}
.mini-btn:hover{border-color:#4a9eff;color:#e8f1ff}
.suggestion-row{display:grid;grid-template-columns:1fr auto;gap:6px;align-items:center;font-size:10px;padding:5px 0;border-bottom:1px solid #1e1e21}
.suggestion-title{color:#e8e8ec}.suggestion-meta{color:#77778a;font-size:9px;margin-top:2px}

.timeline-row{border-left:3px solid #2a2a2e;padding:6px 8px;margin:5px 0;background:#111114;border-radius:4px;font-size:10px}
.timeline-row.before{border-left-color:#4a9eff}.timeline-row.after{border-left-color:#3dd68c}
.timeline-row.intervention_applied{border-left-color:#b58cff}.timeline-row.intervention_noop{border-left-color:#f5a623}
.timeline-row.blocked{border-left-color:#ff6b6b}.timeline-row.control{border-left-color:#77778a}
.timeline-title{color:#e8e8ec;font-size:10px}.timeline-meta{color:#77778a;margin-top:2px;font-size:9px}
.graph-marker{border-color:#b58cff!important;color:#b58cff!important;background:#171020!important}
.graph-legend{font-size:9px;color:#77778a;margin-top:8px;line-height:1.4}

</style>
</head>
<body>
<div class="topbar">
  <h1>Meta-13 MRI Runtime Debugger</h1>
  <span class="tag tag-free" id="tier-tag">FREE</span>
  <span class="tag tag-model" id="model-tag" data-prologue-id="metric-model">model</span>
</div>
<div class="main">

  <div class="card">
    <div class="card-title">perception metrics</div>
    <div data-prologue-id="prompt-panel" style="display:none"></div>
    <div data-prologue-id="token-row"  style="display:none"></div>
    <div class="row">
      <span class="rk">route</span>
      <span class="rv" id="debug-route"
            data-prologue-id="metric-route" data-metric="route">—</span>
    </div>
    <div class="row">
      <span class="rk">tau</span>
      <span class="rv" id="debug-tau"
            data-prologue-id="metric-tau" data-metric="tau">—</span>
    </div>
    <div class="row">
      <span class="rk">drift</span>
      <span class="rv" id="debug-drift"
            data-prologue-id="metric-drift" data-metric="drift">—</span>
    </div>
    <div class="row">
      <span class="rk">D_eff</span>
      <span class="rv" id="debug-deff"
            data-prologue-id="metric-deff" data-metric="deff">—</span>
    </div>
    <div style="margin-top:10px;display:flex;gap:6px">
      <button class="btn" onclick="loadState()">↻ state</button>
      <button class="btn" onclick="loadEvents()">↻ events</button>
    </div>
  </div>

  <div class="card">
    <div class="card-title">surgery levels</div>
    <div class="surgery-grid">
      <div class="sc l1" data-prologue-id="surgery-l1"
           data-surgery-level="L1" onclick="toggleL1()">
        <div class="st">L1</div>
        <div class="sn">Rewrite</div>
        <div class="ss">free ✓</div>
      </div>
      <div class="sc locked" id="surgery-l2-card" data-prologue-id="surgery-l2" data-surgery-level="L2">
        <div class="st">L2</div>
        <div class="sn">Token</div>
        <div class="ss" id="surgery-l2-status">paid 🔒</div>
      </div>
      <div class="sc locked" id="surgery-l3-card" data-prologue-id="surgery-l3" data-surgery-level="L3">
        <div class="st">L3</div>
        <div class="sn">Embed</div>
        <div class="ss" id="surgery-l3-status">paid 🔒</div>
      </div>
      <div class="sc locked" data-prologue-id="surgery-l4" data-surgery-level="L4">
        <div class="st">L4</div>
        <div class="sn">Graft</div>
        <span class="egg">soon</span>
      </div>
    </div>
    <div class="l1panel" id="l1panel">
      <div class="static-title">static modification debugger · L1 free</div>
      <div class="l1form">
        <input id="l1input" type="text" placeholder="L1 새 프롬프트 / 중간 수정 내용을 입력...">
      </div>
      <div class="tokenctl">
        <span>mid stop after tokens</span>
        <input id="l1tokens" type="number" min="1" max="64" value="8">
      </div>
      <div class="l1tools">
        <button class="btn btn-l1" onclick="submitL1Immediate()">▶ L1 immediate next</button>
        <button class="btn btn-l1" onclick="armL1Mid()">⏸ Arm L1 mid-edit</button>
        <button class="btn btn-l1" onclick="applyL1MidAndResume()">✎ Apply while paused + resume</button>
        <button class="btn" onclick="sendCmd('disarm_l1_mid_rewrite')">Cancel L1 mid</button>
      </div>
      <div class="static-help">
        즉시 실행은 다음 generate 시작 전에 바꾸고, 예약 실행은 일부 토큰 생성 후 mid_generate에서 멈춘 뒤 여기서 수정합니다.
      </div>
      <div class="midstatus" id="l1mid-status">mid L1: idle</div>
      <div class="midpreview" id="l1mid-preview">partial preview will appear here while paused.</div>
    </div>
    <div class="cmdbar" aria-label="dynamic debugger commands">
      <button class="btn" onclick="sendCmd('pause')">⏸ Freeze next</button>
      <button class="btn" onclick="sendCmd('resume')">▶ Resume</button>
      <button class="btn" onclick="sendCmd('abort')">⛔ Abort next</button>
      <button class="btn" onclick="sendCmd('snapshot')">📸 Snapshot</button>
      <button class="btn" onclick="sendCmd('embed_perturb',{position:3,magnitude:0.3,mode:'suppress'})">L3 free local test</button>
    </div>
    <div class="cmdnote">Freeze/Abort는 다음 generate 직전 예약형입니다. L1과 L3는 무료 로컬 실행, 유료 L2는 HodgeConverter auto 하나만 API Hub/Modal 서버 커널로 실행됩니다.</div>

    <div class="paidpanel" id="paidpanel">
      <div class="paid-title">paid dynamic surgery · runtime gate</div>
      <div class="paid-status-line" id="paid-runtime-status">runtime: checking...</div>
      <div class="cmdnote">RapidAPI 키/URL이 있으면 HodgeConverter auto는 API Hub→Modal 서버 커널로 실행됩니다. L3 Embedding Surgery는 무료 로컬 one-generate hook입니다.</div>
      <div class="paid-grid">
        <div class="paid-card">
          <h4 id="l2-title">L2 HodgeConverter 🔒</h4>
          <p>Paid boundary: only HodgeConverter auto calls the API Hub/Modal server kernel. Manual token swap and public Output intercept remain removed from the product surface.</p>
          <div class="paid-sep">HodgeConverter auto · paid API Hub/Modal server kernel</div>
          <p>Public surface exposes only replacement value and optional target regex. Internals are not exposed. Product L2 uses hidden output-prefix fallback: the prompt remains unchanged, a partial assistant output is generated, the server Hodge kernel patches the target when it appears, then continuation resumes from the patched prefix. Do not enter secrets or sensitive data; raw prompt/output text is not stored by BDP.</p>
          <div class="paid-form">
            <label>auto new_word<input id="l2-hodge-new-word" value="9" placeholder="예: 9"></label>
            <label>target_regex(optional)<input id="l2-hodge-regex" placeholder="예: 2 또는 (?&lt;==\s*)\d+"></label>
            <label>wait_tokens<input id="l2-hodge-wait-tokens" type="number" value="8"></label>
            <label>continuation_tokens<input id="l2-hodge-cont-tokens" type="number" value="16"></label>
          </div>
          <button class="btn" onclick="runHodgeAuto()">Run/Queue HodgeConverter</button>
          <button class="btn" onclick="previewHodgeAuto()">Preview Hodge contract</button>
        </div>
        <div class="paid-card">
          <h4 id="l3-title">L3 Embedding Surgery · FREE</h4>
          <p>amplify / suppress / noise / replace. 무료 로컬 one-generate embedding hook으로 적용됩니다. 서버 .so 호출/유료 차감 없음.</p>
          <div class="paid-form">
            <label>position<input id="l3-position" type="number" value="3"></label>
            <label>magnitude<input id="l3-magnitude" type="number" step="0.05" value="0.3"></label>
            <label>mode<select id="l3-mode"><option value="suppress">suppress</option><option value="amplify">amplify</option><option value="noise">noise</option></select></label>
            <label>note<input id="l3-note" value="one-generate hook" disabled></label>
          </div>
          <button class="btn" onclick="runL3Perturb()">Run/Queue L3 perturb</button>
          <button class="btn" onclick="previewL3Perturb()">Preview contract</button>
        </div>
        <div class="paid-card">
          <h4 id="deep-title">Deep Insight 🔒</h4>
          <p>OBDA phi / spectral entropy / effective rank / attractor lens. 현재 v1.12.x에서는 metadata/preview만 표시합니다.</p>
          <button class="btn" onclick="paidPreview('deep.obda_phi',{capture_id:'latest',layer_range:[0,-1]})">Preview Deep MRI</button>
          <button class="btn" onclick="paidStatus()">Paid status</button>
        </div>
      </div>
      <div class="cmdnote">SaaS 전환 시 이 경로는 entitlement 확인 → 암호화 통신 → 서명된 난독화 native lease로 교체됩니다. prompt/log/tensor 원문 업로드 금지 계약은 유지합니다.</div>
    </div>
  </div>

  <div class="card">
    <div class="card-title">debug state</div>
    <pre id="state-pre">loading...</pre>
  </div>

  <div class="card" data-prologue-id="result-panel">
    <div class="card-title">events (last 50) · public-safe</div>
    <div class="tabbar">
      <button class="btn" onclick="loadEvents('all')">all</button>
      <button class="btn" onclick="loadEvents('actual')">actual</button>
      <button class="btn" onclick="loadEvents('preview')">preview</button>
      <button class="btn" onclick="loadEvents('system')">system</button>
    </div>
    <div class="evts" id="evts">loading...</div>
    <div class="public-safe-note">raw score, weight, candidate rank, score_components는 public-safe 응답에서 제거됩니다. 내부 디버그는 META13_INTERNAL_HODGE=1 + raw=1일 때만 사용합니다.</div>
  </div>

  <div class="card">
    <div class="card-title">static debugger · public manifest</div>
    <div class="tabbar">
      <button class="btn" onclick="loadStaticManifest()">↻ manifest</button>
      <button class="btn" onclick="loadStaticSection('tokenizer')">tokenizer</button>
      <button class="btn" onclick="loadStaticSection('generation')">generation</button>
      <button class="btn" onclick="loadStaticSection('modules')">modules</button>
      <button class="btn" onclick="loadStaticSection('compat')">compat</button>
      <button class="btn" onclick="loadStaticSection('irsdce')">IRSDCE axis</button>
      <button class="btn" onclick="loadPublicInternals()">public internals</button>
      <button class="btn" onclick="loadTokenFocus()">token focus</button>
      <button class="btn" onclick="loadTokenGraph()">token graph</button>
      <button class="btn" onclick="loadTokenTimeline()">timeline</button>
      <button class="btn" onclick="loadSuggestedSurgery()">suggested surgery</button>
    </div>
    <div class="safegrid" id="static-summary"><div class="safeitem">loading...</div></div>
    <pre id="static-pre">loading...</pre>
  </div>

  <div class="card">
    <div class="card-title">token focus / relation graph / intervention timeline · public-safe</div>
    <div class="tabbar">
      <button class="btn" onclick="loadTokenFocus()">focus</button>
      <button class="btn" onclick="loadTokenGraph()">relation graph</button>
      <button class="btn" onclick="loadIRSDCEGeometry()">IRSDCE geometry</button>
      <button class="btn" onclick="loadPublicInternals()">public internals</button>
      <button class="btn" onclick="loadTokenTimeline()">timeline</button>
    </div>
    <div id="focus-view" class="evts">loading...</div>
    <div id="timeline-view" class="evts" style="margin-top:8px"></div>
    <div class="public-safe-note">토큰 연결 그래프는 role/focus/strength bucket을 표시합니다. IRSDCE 및 공개된 내부 관측축(attention/activation/logit/gradient availability)은 bucket/coverage로 표시하고, 12_6 Hodge/SMAP 후보 랭킹·score_components·weights_json은 숨깁니다.</div>
  </div>

  <div class="card">
    <div class="card-title">suggested surgery · form autofill</div>
    <div class="tabbar">
      <button class="btn" onclick="loadSuggestedSurgery()">↻ suggestions</button>
      <button class="btn" onclick="fillOutputFromCurrentL2()">copy L2 target → output intercept</button>
    </div>
    <div id="suggestion-view" class="evts">suggestions will appear after generation.</div>
    <div class="public-safe-note">추천은 public-safe token focus에서 생성됩니다. raw candidate rank, score_components, SMAP/Hodge weight는 표시하지 않습니다.</div>
  </div>

</div>
<script>
function esc(s){return String(s==null?'':s).replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'})[c])}
async function loadState(){
  const d=await(await fetch('/api/debug/state')).json();
  document.getElementById('state-pre').textContent=JSON.stringify(d,null,2);

  const extra = d.extra || {};
  const status = d.status || {};

  const route = d.route || extra.route || status.route || '—';
  const tau = d.tau ?? extra.tau ?? status.tau ?? '—';
  const drift = d.drift ?? extra.drift ?? status.drift ?? '—';
  const deff = d.d_eff ?? d.deff ?? extra.d_eff ?? extra.deff ?? status.d_eff ?? status.deff ?? '—';

  document.getElementById('debug-route').textContent = route;
  document.getElementById('debug-tau').textContent = tau;
  document.getElementById('debug-drift').textContent = drift;
  document.getElementById('debug-deff').textContent = deff;

  const model = status.model_id || d.model_id || 'model';
  const mt = document.getElementById('model-tag');
  if (mt) mt.textContent = model.split('/').slice(-1)[0] || model;
  updatePaidUiFromStatus(status || d.status || {}, d);

  const midStatus = document.getElementById('l1mid-status');
  const midPreview = document.getElementById('l1mid-preview');
  if (midStatus) {
    const phase = d.phase || 'unknown';
    const paused = !!d.paused;
    const waiting = extra.waiting_for || '';
    const route2 = extra.route || route || '';
    midStatus.textContent = 'mid L1: ' + (paused ? 'PAUSED · ' : 'idle · ') + phase + (waiting ? ' · ' + waiting : '') + (route2 ? ' · ' + route2 : '');
  }
  if (midPreview) {
    const pp = extra.partial_answer_preview || (extra.last_prologue_log && extra.last_prologue_log.value) || '';
    midPreview.textContent = pp || 'partial preview will appear here while paused.';
  }
}
function eventBadge(e){
  const k=String((e&&e.kind)||'');
  if(k.indexOf('prologue_sim')>=0) return '<span class="badge badge-sim">simulated</span>';
  if(k.indexOf('paid_command_accepted')>=0 || k.indexOf('paid_surgery_applied')>=0) return '<span class="badge badge-actual">paid</span>';
  if(k.indexOf('paid_preview')>=0 || (e && (e.actual_model_event===false || e.preview_only))) return '<span class="badge badge-preview">preview</span>';
  if(k.indexOf('blocked')>=0) return '<span class="badge badge-blocked">blocked</span>';
  if(k.indexOf('error')>=0 || k.indexOf('skipped')>=0) return '<span class="badge badge-error">warn</span>';
  return '<span class="badge badge-actual">actual</span>';
}
async function loadEvents(group){
  group = group || window._eventGroup || 'all';
  window._eventGroup = group;
  const d=await(await fetch('/api/debug/events?group='+encodeURIComponent(group))).json();
  document.getElementById('evts').innerHTML=(d.items||[]).slice(-50).reverse().map(e=>
    `<div class="evt">${eventBadge(e)}<span class="ek">${esc(e.kind||'')}</span> <span class="ev">${esc(JSON.stringify(e))}</span></div>`
  ).join('') || '<div class="evt">no events</div>';
}
async function loadStaticManifest(){
  const d=await(await fetch('/api/debug/static/manifest')).json();
  const m=d.manifest||{};
  const pc=d.paid_compatibility||{};
  const el=document.getElementById('static-summary');
  if(el){
    el.innerHTML = [
      ['model', m.model_id||'model'], ['tier', (m.tier||'free')+' · '+(m.paid_mode||'free')],
      ['tokenizer', (d.tokenizer&&d.tokenizer.available)?(d.tokenizer.class||'available'):'files only'],
      ['L2/L3', (pc.l2_token_surgery?'L2✓':'L2 locked')+' / '+(pc.l3_embedding_hook?'L3✓':'L3 locked')]
    ].map(x=>`<div class="safeitem"><b>${esc(x[0])}</b><br>${esc(x[1])}</div>`).join('');
  }
  document.getElementById('static-pre').textContent=JSON.stringify(d,null,2);
  return d;
}
async function loadStaticSection(section){
  const d=await(await fetch('/api/debug/static/'+encodeURIComponent(section))).json();
  const body=d.data||{};
  const el=document.getElementById('static-summary');
  if(el){
    const entries=Object.entries(body).slice(0,8);
    el.innerHTML = entries.map(([k,v])=>`<div class="safeitem"><b>${esc(k)}</b><br>${esc(typeof v==='object'?JSON.stringify(v).slice(0,120):v)}</div>`).join('') || '<div class="safeitem">no data</div>';
  }
  document.getElementById('static-pre').textContent=JSON.stringify(d,null,2);
  return d;
}
function attrEsc(s){return esc(s).replace(/`/g,'&#96;')}
function setVal(id, val){const el=document.getElementById(id); if(el){el.value=(val==null?'':String(val));}}
function fillL2FromToken(token){
  setVal('l2-old-word', token);
  const nw=document.getElementById('l2-new-word'); if(nw && !nw.value) nw.focus();
  alert('L2 old_word filled: '+token);
}
function fillOutputFromToken(token, selector){ fillL2FromToken(token); }
function fillOutputFromCurrentL2(){
  const old=(document.getElementById('l2-old-word')||{}).value || '';
  const nw=(document.getElementById('l2-new-word')||{}).value || '';
  setVal('l2-out-old-word', old);
  if(nw) setVal('l2-out-new-word', nw);
  setVal('l2-out-selector', 'after_equals');
}
function fillSuggestionPayload(s){
  const p=(s&&s.payload_template)||{};
  if((s&&s.form_target)==='output_intercept'){
    setVal('l2-out-old-word', p.old_word||s.token||'');
    setVal('l2-out-new-word', p.new_word||'');
    setVal('l2-out-selector', p.selector||'after_equals');
    setVal('l2-out-after-tokens', p.after_tokens||16);
    setVal('l2-out-cont-tokens', p.continuation_tokens||16);
  } else if((s&&s.form_target)==='l2_manual'){
    setVal('l2-old-word', p.old_word||s.token||'');
    setVal('l2-new-word', p.new_word||'');
    setVal('l2-mode', p.mode||'swap');
  }
}
async function queueSuggestion(s){
  fillSuggestionPayload(s);
  const op=(s&&s.op)||'';
  if(!op){alert('suggestion has no op');return;}
  if((s&&s.form_target)==='output_intercept') return sendCmd(op, hodgeOutputPayload());
  if((s&&s.form_target)==='l2_manual') return sendCmd(op, l2Payload());
  return sendCmd(op, (s&&s.payload_template)||{});
}
async function loadTokenFocus(){
  const d=await(await fetch('/api/debug/token_focus')).json();
  const rows=(d.items||[]).slice(0,60);
  const html=rows.map(r=>{
    const tok=attrEsc(r.token||'');
    const role=attrEsc(r.role||'');
    const selector=(r.role==='intermediate_result')?'after_equals':'auto';
    return `<div class="focus-row focus-click" title="click buttons to fill surgery forms"><span>${esc(r.idx)}</span><span>${esc(r.token)}</span><span>${esc(r.role)}</span><span>${esc(r.focus_bucket||r.confidence_bucket||'')}</span><span class="focus-actions"><button class="mini-btn" onclick="fillL2FromToken(this.dataset.token)" data-token="${tok}">L2</button></span></div>`;
  }).join('') || '<div class="evt">no token focus yet</div>';
  document.getElementById('focus-view').innerHTML=html;
  return d;
}
async function loadTokenGraph(){
  const d=await(await fetch('/api/debug/token_graph')).json();
  const nodes=(d.nodes||[]).slice(0,80).map(n=>{
    const cls=n.marker?'graph-node graph-marker':'graph-node';
    const title=[n.role||'', n.focus_bucket?('focus '+n.focus_bucket):'', n.confidence_bucket?('confidence '+n.confidence_bucket):''].filter(Boolean).join(' · ');
    return `<span class="${cls}" title="${esc(title)}" onclick="fillL2FromToken(this.dataset.token)" data-token="${attrEsc(n.label||n.id)}">${esc(n.label||n.id)}</span>`;
  }).join(' ');
  const edges=(d.edges||[]).slice(0,120).map(e=>`<div class="graph-edge">${esc(e.source)} → ${esc(e.target)} · ${esc(e.relation)} · ${esc(e.strength_bucket)}</div>`).join('');
  const markers=(d.markers||[]).slice(-8).map(m=>`<div class="graph-edge">marker · ${esc(m.kind||'')} · changed=${esc(m.changed)} · actual=${esc(m.actual_model_event)}</div>`).join('');
  const legend=d.legend?`<div class="graph-legend">${esc(d.legend.edge_strength||'public-safe graph')}</div>`:'';
  document.getElementById('focus-view').innerHTML='<div>'+nodes+'</div>'+edges+markers+legend;
  const tl=document.getElementById('timeline-view'); if(tl) tl.innerHTML='';
  return d;
}
async function loadIRSDCEGeometry(){
  const d=await(await fetch('/api/debug/irsdce_geometry')).json();
  const summary=d.axis_summary||{};
  const cards=['irs_weight','dce_weight','cascade_strength','phase_drift','route_pressure','basis_pressure'].map(k=>`<div class="safeitem"><b>${esc(k)}</b><br>${esc(summary[k]==null?'—':summary[k])}</div>`).join('');
  const nodes=(d.nodes||[]).slice(0,80).map(n=>{
    const title=['IRS '+(n.irs_weight??'—'),'DCE '+(n.dce_weight??'—'),'cascade '+(n.cascade_strength??'—'),'phase '+(n.phase_drift??'—'),'route '+(n.route_pressure??'—'),'basis '+(n.basis_pressure??'—')].join(' · ');
    return `<span class="graph-node" title="${esc(title)}">${esc(n.label||n.id)}<small> ${esc(n.irsdce_bucket||'')}</small></span>`;
  }).join(' ');
  const edges=(d.edges||[]).slice(0,120).map(e=>`<div class="graph-edge">${esc(e.source)} → ${esc(e.target)} · ${esc(e.relation)} · IRS=${esc(e.irs_weight??'—')} DCE=${esc(e.dce_weight??'—')} · ${esc(e.strength_bucket||'')}</div>`).join('');
  const note=`<div class="graph-legend">IRSDCE raw/public geometry axis is displayed. 12_6 Hodge/SMAP selector ranking, score_components, weights_json remain hidden.</div>`;
  const el=document.getElementById('focus-view'); if(el) el.innerHTML='<div class="safegrid">'+cards+'</div><div style="margin-top:8px">'+nodes+'</div>'+edges+note;
  const tl=document.getElementById('timeline-view'); if(tl) tl.innerHTML='';
  return d;
}


async function loadPublicInternals(){
  const d=await(await fetch('/api/debug/public_internals')).json();
  const axes=d.axes||[];
  const cards=axes.map(a=>{
    const pct=(a.public_percent==null?'':(' · '+a.public_percent+'%'));
    return `<div class="safeitem"><b>${esc(a.public_name||a.axis)}</b><br>${esc(a.public_bucket||'unknown')}${esc(pct)}<br><small>${esc(a.notes||'')}</small></div>`;
  }).join('');
  const cov=d.capture_coverage||{};
  const covHtml=Object.entries(cov).map(([k,v])=>`<span class="badge badge-preview">${esc(k)}=${esc(v)}</span>`).join(' ');
  const graph=(d.graph&&d.graph.edges?d.graph.edges:[]).slice(0,80).map(e=>`<div class="graph-edge">${esc(e.src)} → ${esc(e.dst)} · ${esc(e.kind)} · ${esc(e.strength_bucket||'')}</div>`).join('');
  const note='<div class="graph-legend">Public internals show bucketed activation/residual, attention focus, logit gap, gradient attribution signal, layer-token-dim coverage, MLP activity, and effective-rank geometry. Raw tensors/logits/gradients and 12_6 selector internals are not returned.</div>';
  const el=document.getElementById('focus-view'); if(el) el.innerHTML='<div class="safegrid">'+cards+'</div><div style="margin-top:8px">'+covHtml+'</div>'+graph+note;
  const sp=document.getElementById('static-pre'); if(sp) sp.textContent=JSON.stringify(d,null,2);
  const tl=document.getElementById('timeline-view'); if(tl) tl.innerHTML='';
  return d;
}

async function loadTokenTimeline(){
  const d=await(await fetch('/api/debug/token_timeline')).json();
  const rows=(d.items||[]).slice(-60).map(item=>{
    const role=item.timeline_role||'control';
    const detail=item.answer_preview||item.prompt_preview||item.route||item.phase||'';
    return `<div class="timeline-row ${esc(role)}"><div class="timeline-title">${esc(item.kind||'event')} · ${esc(role)}</div><div class="timeline-meta">${esc(item.phase||'')} ${esc(item.route||'')} changed=${esc(item.changed)} condition=${esc(item.condition_passed)}</div>${detail?`<div class="timeline-meta">${esc(detail)}</div>`:''}</div>`;
  }).join('') || '<div class="evt">no timeline yet</div>';
  const el=document.getElementById('timeline-view') || document.getElementById('focus-view');
  el.innerHTML=rows;
  return d;
}
async function loadSuggestedSurgery(){
  const d=await(await fetch('/api/debug/suggested_surgery')).json();
  const rows=(d.items||[]).slice(0,40);
  const html=rows.map((s,i)=>{
    const encoded=attrEsc(JSON.stringify(s));
    return `<div class="suggestion-row"><div><div class="suggestion-title">${esc(s.title||s.op||'suggestion')}</div><div class="suggestion-meta">${esc(s.role||'')} · ${esc(s.focus_bucket||'')} · ${esc(s.function_id||'')}</div></div><div class="focus-actions"><button class="mini-btn" onclick="fillSuggestionPayload(JSON.parse(this.dataset.s))" data-s="${encoded}">fill</button><button class="mini-btn" onclick="queueSuggestion(JSON.parse(this.dataset.s))" data-s="${encoded}">queue</button></div></div>`;
  }).join('') || '<div class="evt">no suggestions yet</div>';
  const el=document.getElementById('suggestion-view'); if(el) el.innerHTML=html;
  return d;
}

window.loadState = loadState;
window.loadEvents = loadEvents;
function toggleL1(){const p=document.getElementById('l1panel');p.style.display=p.style.display==='none'?'block':'none';}
function _l1Text(){return document.getElementById('l1input').value.trim();}
function _l1Tokens(){
  const el=document.getElementById('l1tokens');
  let n=parseInt((el && el.value) || '8',10);
  if(!Number.isFinite(n)) n=8;
  return Math.max(1,Math.min(64,n));
}
async function submitL1Immediate(){
  const np=_l1Text();
  if(!np){alert('L1 프롬프트를 입력하세요');return;}
  const d=await sendCmd('rewrite_prompt',{new_prompt:np,mode:'immediate_next'},false);
  if(d && d.ok){alert('L1 immediate queued ✓');}
}
async function submitL1(){ return submitL1Immediate(); }
async function armL1Mid(){
  const d=await sendCmd('arm_l1_mid_rewrite',{after_tokens:_l1Tokens()},false);
  if(d && d.ok){alert('L1 mid-edit armed ✓ 다음 대화에서 일부 토큰 후 멈춥니다.');}
}
async function applyL1MidAndResume(){
  const np=_l1Text();
  if(!np){alert('정지 중 적용할 L1 프롬프트를 입력하세요');return;}
  const d1=await sendCmd('rewrite_prompt',{new_prompt:np,mode:'mid_generate'},false);
  const d2=await sendCmd('resume',{clear_phases:true},false);
  if(d1 && d1.ok && d2 && d2.ok){alert('L1 mid rewrite applied + resume ✓');}
}
function updatePaidUiFromStatus(status, state){
  const ent = (status && status.entitlement) || (state && state.entitlement) || {};
  const paid = !!(status && status.paid_enabled) || !!ent.paid_enabled || !!(state && state.paid_enabled);
  const mode = (status && status.paid_mode) || ent.paid_mode || (state && state.paid_mode) || 'free';
  const tier = paid ? 'PAID' : 'FREE';
  const tierTag = document.getElementById('tier-tag');
  if(tierTag){
    tierTag.textContent = paid ? 'PAID · '+mode : 'FREE';
    tierTag.className = 'tag tag-free';
    if(paid){tierTag.style.borderColor='#b58cff';tierTag.style.color='#b58cff';tierTag.style.background='#171020';}
  }
  const line = document.getElementById('paid-runtime-status');
  if(line) line.textContent = paid ? ('runtime: PAID enabled · '+mode+' · paid L2 Hodge/Output on server, L3 free local') : 'runtime: FREE · L3 free local, paid L2 Hodge/Output requires key/url';
  const l2 = document.getElementById('surgery-l2-card');
  const l3 = document.getElementById('surgery-l3-card');
  if(l2) l2.className = paid ? 'sc paid-unlocked' : 'sc locked';
  if(l3) l3.className = paid ? 'sc paid-unlocked' : 'sc locked';
  const l2s = document.getElementById('surgery-l2-status');
  const l3s = document.getElementById('surgery-l3-status');
  if(l2s) l2s.textContent = paid ? 'paid ✓' : 'paid 🔒';
  if(l3s) l3s.textContent = 'free ✓';
  const l2t = document.getElementById('l2-title');
  const l3t = document.getElementById('l3-title');
  if(l2t) l2t.textContent = paid ? 'L2 HodgeConverter ✓' : 'L2 HodgeConverter 🔒';
  if(l3t) l3t.textContent = 'L3 Embedding Surgery · FREE';
}
function hodgePayload(){
  const newWord=(document.getElementById('l2-hodge-new-word')||{}).value || '';
  const regex=(document.getElementById('l2-hodge-regex')||{}).value || '';
  const waitRaw=(document.getElementById('l2-hodge-wait-tokens')||{}).value || '8';
  const contRaw=(document.getElementById('l2-hodge-cont-tokens')||{}).value || '16';
  const wait=parseInt(waitRaw,10);
  const cont=parseInt(contRaw,10);
  const p={new_word:newWord,auto_output_fallback:true,internal_selector:'auto'};
  if(String(regex).trim()!=='') p.target_regex=String(regex).trim();
  if(Number.isFinite(wait)) p.hodge_wait_tokens=wait;
  if(Number.isFinite(cont)) p.continuation_tokens=cont;
  return p;
}
async function runHodgeAuto(){ return sendCmd('hodge_token_auto', hodgePayload()); }
async function previewHodgeAuto(){ return paidPreview('l2.hodge_auto', hodgePayload()); }
async function runHodgeOutputIntercept(){ return Promise.resolve(alert('Output intercept was merged into HodgeConverter and removed from the public product surface.')); }
async function previewHodgeOutputIntercept(){ return Promise.resolve(alert('Output intercept preview removed. Use HodgeConverter preview.')); }
function l3Payload(){
  const pos=parseInt((document.getElementById('l3-position')||{}).value || '3',10);
  const mag=parseFloat((document.getElementById('l3-magnitude')||{}).value || '0.3');
  const mode=(document.getElementById('l3-mode')||{}).value || 'suppress';
  return {position:Number.isFinite(pos)?pos:3,magnitude:Number.isFinite(mag)?mag:0.3,mode:mode};
}
async function runL3Perturb(){ return sendCmd('embed_perturb', l3Payload()); }
async function previewL3Perturb(){ return Promise.resolve(alert('L3 is free local hook; no paid server preview needed.')); }
async function sendCmd(op, payload, showAlert){
  const r=await fetch('/api/debug/command',{
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body:JSON.stringify({op:op,payload:payload||{}})
  });
  const d=await r.json();
  console.log('[Meta13 cmd]', d);
  if(showAlert!==false){
    if(d.ok) alert('command queued: '+op);
    else alert('command error: '+JSON.stringify(d));
  }
  setTimeout(function(){
    if(typeof loadState==='function') loadState();
    if(typeof loadEvents==='function') loadEvents();
  },300);
  return d;
}

async function paidPreview(functionId, payload){
  const r=await fetch('/api/paid/preview',{
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body:JSON.stringify({function_id:functionId,payload:payload||{}})
  });
  const d=await r.json();
  console.log('[Meta13 paid preview]', d);
  if(d.ok) alert('paid preview recorded: '+functionId);
  else alert('paid preview error: '+JSON.stringify(d));
  setTimeout(function(){
    if(typeof loadState==='function') loadState();
    if(typeof loadEvents==='function') loadEvents();
  },300);
  return d;
}
async function paidStatus(){
  const d=await(await fetch('/api/paid/status')).json();
  console.log('[Meta13 paid status]', d);
  alert(JSON.stringify(d,null,2));
  return d;
}
window.sendCmd = sendCmd;
window.paidPreview = paidPreview;
window.paidStatus = paidStatus;
window.runL2Swap = runL2Swap;
window.previewL2Swap = previewL2Swap;
window.runL3Perturb = runL3Perturb;
window.previewL3Perturb = previewL3Perturb;
window.fillL2FromToken = fillL2FromToken;
window.fillOutputFromToken = fillOutputFromToken;
window.fillOutputFromCurrentL2 = fillOutputFromCurrentL2;
window.fillSuggestionPayload = fillSuggestionPayload;
window.queueSuggestion = queueSuggestion;
window.loadSuggestedSurgery = loadSuggestedSurgery;
window.submitL1Immediate = submitL1Immediate;
window.armL1Mid = armL1Mid;
window.applyL1MidAndResume = applyL1MidAndResume;
setInterval(()=>{loadState();loadEvents(window._eventGroup||'all');},3000);
loadState();loadEvents('all');loadStaticManifest();loadTokenFocus();loadSuggestedSurgery();
</script>
{{ prologue_js | safe }}
</body>
</html>"""


def create_app(capture_dir: str = 'results/base_mri_capture', run_dir: str = 'results/base_debug_run',
               session_obj: Any = None):
    from .prologue_bridge import prologue_bp, inject_prologue_js

    app = Flask(__name__)
    app.secret_key = os.getenv('META13_SECRET_KEY', 'meta13-free-dev-key')
    app.register_blueprint(prologue_bp)

    cap_root = Path(capture_dir).resolve()
    run_root = Path(run_dir).resolve()

    def _append_debug_event(event: Dict[str, Any]) -> Dict[str, Any]:
        dyn = run_root / 'dynamic_debug'
        dyn.mkdir(parents=True, exist_ok=True)

        event = dict(event or {})
        event.setdefault('ts', time.time())

        path = dyn / 'events.jsonl'
        with path.open('a', encoding='utf-8') as f:
            f.write(json.dumps(event, ensure_ascii=False) + '\n')

        return event

    def _merge_debug_state(*, phase: str, source: str, extra: Dict[str, Any]) -> Dict[str, Any]:
        """current_state.json을 기존 상태 보존 방식으로 병합한다."""
        dyn = run_root / 'dynamic_debug'
        dyn.mkdir(parents=True, exist_ok=True)
        state_path = dyn / 'current_state.json'
        old = _read_json(state_path, {}) or {}
        old_extra = old.get('extra') or {}
        merged_extra = {**old_extra, **{k: v for k, v in (extra or {}).items() if v is not None}}
        old.update({
            'phase': phase or old.get('phase', 'PROLOGUE'),
            'source': source or old.get('source', 'prologue'),
            'tier': old.get('tier', 'free'),
            'extra': merged_extra,
            'ts': time.time(),
        })
        atomic_write_json(state_path, old)
        return old

    def _compact_str(value: Any, limit: int = 500) -> str:
        if value is None:
            return ''
        return str(value)[:limit]

    def _runtime_status_from_files() -> Dict[str, Any]:
        """Return runtime status written by attach_debugger, falling back to env.

        v1.12.2: the dashboard must show and queue commands against the same
        entitlement that the live runner uses.  Prefer dynamic_debug/runtime_status.json
        and current_state.json over process environment so separate launches do
        not falsely display paid while the runner is free, or vice versa.
        """
        dyn = run_root / 'dynamic_debug'
        rs = _read_json(dyn / 'runtime_status.json', {}) or {}
        if isinstance(rs, dict) and rs.get('status'):
            status = dict(rs.get('status') or {})
            ent = rs.get('entitlement') or status.get('entitlement') or {}
            return {
                'ok': True,
                'source': 'runtime_status.json',
                'tier': status.get('tier') or ent.get('tier') or 'free',
                'paid_enabled': bool(status.get('paid_enabled') or ent.get('paid_enabled')),
                'paid_mode': status.get('paid_mode') or ent.get('paid_mode') or 'free',
                'actual_execution': bool(status.get('paid_enabled') and (status.get('paid_mode') in {'local_import', 'modal_remote'})),
                'entitlement': ent,
                'status': status,
                'runtime_status_path': str((dyn / 'runtime_status.json').resolve()),
            }
        state = _read_json(dyn / 'current_state.json', {}) or {}
        status = state.get('status') if isinstance(state.get('status'), dict) else {}
        ent = status.get('entitlement') if isinstance(status.get('entitlement'), dict) else {}
        if status or ent:
            paid = bool(status.get('paid_enabled') or ent.get('paid_enabled') or state.get('paid_enabled'))
            mode = status.get('paid_mode') or ent.get('paid_mode') or state.get('paid_mode') or 'free'
            return {
                'ok': True,
                'source': 'current_state.json',
                'tier': status.get('tier') or ent.get('tier') or state.get('tier') or ('paid' if paid else 'free'),
                'paid_enabled': paid,
                'paid_mode': mode,
                'actual_execution': bool(paid and mode in {'local_import', 'modal_remote'}),
                'entitlement': ent,
                'status': status,
                'runtime_status_path': str((dyn / 'runtime_status.json').resolve()),
            }
        from .premium_client import PremiumDebuggerClient
        status = PremiumDebuggerClient().paid_status()
        status['source'] = 'environment_fallback'
        status['runtime_status_path'] = str((dyn / 'runtime_status.json').resolve())
        return status

    def _prologue_log_event(item: Dict[str, Any]) -> Dict[str, Any]:
        item = dict(item or {})
        extra = item.get('extra') if isinstance(item.get('extra'), dict) else {}
        raw_kind = _compact_str(item.get('kind') or 'prologue_sim_log', 80)
        # v1.11: prologue traces are product previews/simulations, not actual
        # attach_debugger model events.  Keep prologue_open distinct, but mark
        # every prologue-origin log as preview/simulated to prevent confusion.
        kind = 'prologue_open' if raw_kind == 'prologue_open' else 'prologue_sim_log'
        return {
            'kind': kind,
            'source': 'prologue',
            'phase': _compact_str(item.get('phase') or 'PROLOGUE_LOG', 80),
            'tier': 'free',
            'simulated': True,
            'preview_only': True,
            'actual_model_event': False,
            'locked_feature_preview': True,
            'session_id': _compact_str(item.get('session_id'), 120),
            'log_key': _compact_str(item.get('log_key') or item.get('key'), 120),
            'log_value': _compact_str(item.get('log_value') or item.get('value'), 1000),
            'current_L': item.get('current_L'),
            'experiment_count': item.get('experiment_count'),
            'extra': {
                'route': extra.get('route'),
                'tau': extra.get('tau'),
                'drift': extra.get('drift'),
                'deff': extra.get('deff'),
                'answer': extra.get('answer'),
                'latency': extra.get('latency'),
                'simulated': True,
                'preview_only': True,
                'actual_model_event': False,
            },
            'ts': item.get('ts') or time.time(),
        }

    @app.route('/')
    def index():
        return render_template_string(
            _DASHBOARD_HTML,
            prologue_js=inject_prologue_js(auto_check=True),
        )

    @app.route('/api/capture/list')
    def capture_list():
        rows = []
        index = cap_root / 'index.jsonl'
        if index.exists():
            for line in index.read_text(encoding='utf-8', errors='ignore').splitlines()[-200:]:
                try: rows.append(json.loads(line))
                except Exception: pass
        return jsonify({'ok': True, 'tier': 'free', 'capture_dir': str(cap_root), 'items': rows})

    @app.route('/api/capture/session/<sid>')
    def capture_session(sid: str):
        d = cap_root / sid
        if not d.exists(): return jsonify({'ok': False, 'error': 'session not found', 'session_id': sid}), 404
        payload: Dict[str, Any] = {'ok': True, 'tier': 'free', 'session_id': sid, 'files': {}}
        for name in ('manifest.json', 'capture_index.json', 'result_minimal.json'):
            payload['files'][name] = _read_json(d / name, None)
        return jsonify(payload)

    @app.route('/api/debug/state')
    def debug_state():
        from .public_redactor import redact_state
        raw = request.args.get('raw') in ('1', 'true', 'yes')
        path = run_root / 'dynamic_debug' / 'current_state.json'
        if not path.exists():
            return jsonify({
                'ok': False,
                'error': 'no state yet',
                'state_path': str(path.resolve()),
                'hint': 'Run attach_debugger or generate at least once. In v1.7 attach_debugger should create this immediately.',
            })
        data = _read_json(path, {}) or {}
        data.setdefault('state_path', str(path.resolve()))
        return jsonify(redact_state(data, raw=raw))

    @app.route('/api/debug/events')
    def debug_events():
        from .public_redactor import redact_events
        raw = request.args.get('raw') in ('1', 'true', 'yes')
        group = request.args.get('group') or 'all'
        path = run_root / 'dynamic_debug' / 'events.jsonl'
        if not path.exists():
            return jsonify({
                'ok': True,
                'tier': 'free',
                'items': [],
                'warning': 'events.jsonl not found yet',
                'events_path': str(path.resolve()),
                'group': group,
            })
        rows = []
        for line in path.read_text(encoding='utf-8', errors='replace').splitlines()[-300:]:
            if not line.strip():
                continue
            try: rows.append(json.loads(line))
            except Exception: pass
        safe_rows = redact_events(rows, raw=raw, group=group)
        return jsonify({
            'ok': True,
            'tier': 'free',
            'public_safe': not raw,
            'group': group,
            'items': safe_rows[-50:],
            'events_path': str(path.resolve()),
        })

    @app.route('/api/prologue/event', methods=['POST'])
    def api_prologue_event():
        body = request.get_json(silent=True) or {}
        raw_items = body.get('events') if isinstance(body.get('events'), list) else [body]
        saved = []
        for raw in raw_items:
            if not isinstance(raw, dict):
                continue
            ev = _prologue_log_event(raw)
            saved.append(_append_debug_event(ev))

        if saved:
            last = saved[-1]
            _merge_debug_state(
                phase=last.get('phase') or 'PROLOGUE_LOG',
                source='prologue',
                extra={
                    'last_prologue_log': {
                        'key': last.get('log_key'),
                        'value': last.get('log_value'),
                        'phase': last.get('phase'),
                        'ts': last.get('ts'),
                    },
                    'route': (last.get('extra') or {}).get('route'),
                    'tau': (last.get('extra') or {}).get('tau'),
                    'drift': (last.get('extra') or {}).get('drift'),
                    'deff': (last.get('extra') or {}).get('deff'),
                },
            )

        return jsonify({
            'ok': True,
            'saved_count': len(saved),
            'events_path': str((run_root / 'dynamic_debug' / 'events.jsonl').resolve()),
            'state_path': str((run_root / 'dynamic_debug' / 'current_state.json').resolve()),
        })

    @app.route('/api/prologue/result', methods=['POST'])
    def api_prologue_result():
        body = request.get_json(silent=True) or {}
        action = str(body.get('action', ''))

        last_result = body.get('last_result') or {}
        if not isinstance(last_result, dict):
            last_result = {}

        current_L = body.get('current_L')
        experiment_count = body.get('experiment_count')

        safe_extra = {
            'route': last_result.get('route'),
            'drift': last_result.get('drift'),
            'deff': last_result.get('deff'),
            'answer': last_result.get('answer'),
            'latency': last_result.get('latency'),
            'changed': last_result.get('changed'),
            'simulated': True,
            'preview_only': True,
            'actual_model_event': False,
        }

        safe = {
            'kind': 'prologue_compare' if action == 'apply_prologue_result' else 'prologue_event',
            'source': 'prologue',
            'phase': 'COMPARE' if action == 'apply_prologue_result' else action or 'UNKNOWN',
            'tier': 'free',
            'simulated': True,
            'preview_only': True,
            'actual_model_event': False,
            'action': action,
            'current_L': current_L,
            'experiment_count': experiment_count,
            'extra': safe_extra,
        }

        safe = _append_debug_event(safe)

        # 기존 /prologue/check 흐름이 깨지지 않도록 Flask session도 같이 갱신한다.
        session['prologue_seen'] = True
        session['prologue_result'] = {
            'action': action,
            'experiment_count': experiment_count,
            'current_L': current_L,
            'has_result': bool(last_result),
            'last_result_summary': safe_extra if last_result else None,
            'ts': safe.get('ts'),
        }

        # current_state에도 프롤로그 compare를 병합해서 대시보드 새로고침 후 보이게 한다.
        merged_state = _merge_debug_state(
            phase='PROLOGUE_COMPARE' if action == 'apply_prologue_result' else action or 'PROLOGUE',
            source='prologue',
            extra={
                'prologue_compare': safe_extra if action == 'apply_prologue_result' else None,
                'route': safe_extra.get('route'),
                'drift': safe_extra.get('drift'),
                'deff': safe_extra.get('deff'),
            },
        )

        return jsonify({
            'ok': True,
            'saved': safe,
            'events_path': str((run_root / 'dynamic_debug' / 'events.jsonl').resolve()),
            'state_path': str((run_root / 'dynamic_debug' / 'current_state.json').resolve()),
            'state': merged_state,
        })

    @app.route('/api/debug/paths')
    def debug_paths():
        dyn = run_root / 'dynamic_debug'
        return jsonify({
            'ok': True,
            'cwd': os.getcwd(),
            'run_root': str(run_root.resolve()),
            'capture_root': str(cap_root.resolve()),
            'dynamic_debug': str(dyn.resolve()),
            'state_exists': (dyn / 'current_state.json').exists(),
            'events_exists': (dyn / 'events.jsonl').exists(),
            'commands_exists': (dyn / 'commands.jsonl').exists(),
            'runtime_status_exists': (dyn / 'runtime_status.json').exists(),
            'state_path': str((dyn / 'current_state.json').resolve()),
            'events_path': str((dyn / 'events.jsonl').resolve()),
            'commands_path': str((dyn / 'commands.jsonl').resolve()),
            'runtime_status_path': str((dyn / 'runtime_status.json').resolve()),
        })

    @app.route('/api/debug/command', methods=['POST'])
    def debug_command():
        from .command_queue import CommandQueue
        body = request.get_json(silent=True) or {}
        op = str(body.get('op', '')).strip()
        payload = body.get('payload') or {}
        if not isinstance(payload, dict):
            return jsonify({'ok': False, 'error': 'payload must be an object'}), 400
        if not op:
            return jsonify({'ok': False, 'error': 'op required'}), 400
        if op in {'token_swap', 'swap_token', 'swap_basis', 'hodge_output_intercept', 'output_intercept'}:
            return jsonify({'ok': False, 'error': 'removed_product_surface', 'message': 'Manual L2 token swap/graft and Output intercept were removed. Use HodgeConverter auto.'}), 410
        runtime = _runtime_status_from_files()
        cmd = CommandQueue(run_root).push_command(op, **payload)
        return jsonify({
            'ok': True,
            'tier': runtime.get('tier', 'free'),
            'paid_enabled': bool(runtime.get('paid_enabled')),
            'paid_mode': runtime.get('paid_mode', 'free'),
            'runtime_status_source': runtime.get('source'),
            'cmd': cmd,
            'commands_path': str((run_root / 'dynamic_debug' / 'commands.jsonl').resolve()),
            'runtime_status_path': str((run_root / 'dynamic_debug' / 'runtime_status.json').resolve()),
        })

    @app.route('/api/debug/l1_rewrite', methods=['POST'])
    def l1_rewrite():
        from .command_queue import CommandQueue
        body = request.get_json(silent=True) or {}
        new_prompt = str(body.get('new_prompt', ''))
        if not new_prompt: return jsonify({'ok': False, 'error': 'new_prompt required'}), 400
        cmd = CommandQueue(run_root).push_command('rewrite_prompt', new_prompt=new_prompt)
        return jsonify({'ok': True, 'tier': 'free_l1', 'cmd': cmd})


    @app.route('/api/paid/status')
    def paid_status():
        from .premium_client import get_paid_function_registry
        status = _runtime_status_from_files()
        status['registry'] = get_paid_function_registry()
        status.setdefault('message', 'Paid local runtime is enabled by key.' if status.get('paid_enabled') else 'Paid execution requires PremiumDebuggerClient lease runtime.')
        status.setdefault('available_preview', sorted(status['registry'].keys()))
        return jsonify(status)

    @app.route('/api/paid/preview', methods=['POST'])
    def paid_preview():
        from .premium_client import PremiumDebuggerClient
        body = request.get_json(silent=True) or {}
        function_id = str(body.get('function_id', '')).strip()
        payload = body.get('payload') or {}
        if not isinstance(payload, dict):
            return jsonify({'ok': False, 'error': 'payload must be an object'}), 400
        client = PremiumDebuggerClient()
        runtime = _runtime_status_from_files()
        preview = client.preview(function_id, payload)
        if not preview.get('ok'):
            return jsonify(preview), 400
        preview['tier'] = runtime.get('tier', preview.get('tier', 'free'))
        preview['paid_enabled'] = bool(runtime.get('paid_enabled'))
        preview['paid_mode'] = runtime.get('paid_mode', preview.get('paid_mode', 'free'))
        preview['runtime_status_source'] = runtime.get('source')
        event = {
            'kind': 'paid_preview',
            'source': 'dashboard',
            'tier': runtime.get('tier', 'free'),
            'paid_enabled': bool(runtime.get('paid_enabled')),
            'function_id': function_id,
            'preview_only': True,
            'simulated': True,
            'actual_model_event': False,
            'payload_preview': _compact_str(payload, 500),
            'route_to': 'PremiumDebuggerClient',
            'status': 'preview_only_paid_available' if runtime.get('paid_enabled') else 'preview_only',
            'ts': time.time(),
        }
        _append_debug_event(event)
        _merge_debug_state(
            phase='PAID_PREVIEW',
            source='dashboard',
            extra={
                'last_paid_preview': {
                    'function_id': function_id,
                    'payload_preview': event['payload_preview'],
                    'preview_only': True,
                    'actual_model_event': False,
                    'ts': event['ts'],
                }
            },
        )
        preview['event'] = event
        preview['events_path'] = str((run_root / 'dynamic_debug' / 'events.jsonl').resolve())
        return jsonify(preview)

    @app.route('/api/debug/static/manifest')
    def debug_static_manifest():
        from .static_inspector import inspect_static
        from .public_redactor import redact_state
        data = inspect_static(run_root=run_root, cap_root=cap_root, session_obj=session_obj)
        return jsonify(redact_state(data, raw=False))

    @app.route('/api/debug/static/<section>')
    def debug_static_section(section):
        from .static_inspector import inspect_static, static_section
        from .public_redactor import redact_state
        data = inspect_static(run_root=run_root, cap_root=cap_root, session_obj=session_obj)
        return jsonify(redact_state(static_section(data, section), raw=False))

    @app.route('/api/debug/token_focus')
    def debug_token_focus():
        from .static_inspector import simple_token_focus_from_state
        from .public_redactor import redact_state
        path = run_root / 'dynamic_debug' / 'current_state.json'
        state = _read_json(path, {}) or {}
        return jsonify(redact_state(simple_token_focus_from_state(state), raw=False))

    @app.route('/api/debug/token_graph')
    def debug_token_graph():
        from .token_timeline import load_public_graph_from_files
        from .public_redactor import redact_state
        path = run_root / 'dynamic_debug' / 'current_state.json'
        state = _read_json(path, {}) or {}
        return jsonify(redact_state(load_public_graph_from_files(run_root, state), raw=False))

    @app.route('/api/debug/irsdce_geometry')
    def debug_irsdce_geometry():
        from .irsdce_geometry import load_irsdce_geometry_from_files
        from .public_redactor import redact_state
        path = run_root / 'dynamic_debug' / 'current_state.json'
        state = _read_json(path, {}) or {}
        return jsonify(redact_state(load_irsdce_geometry_from_files(run_root, state), raw=False))

    @app.route('/api/debug/public_internals')
    def debug_public_internals():
        from .public_internal_metrics import build_public_internal_metrics, build_public_internal_graph
        from .public_redactor import redact_state
        path = run_root / 'dynamic_debug' / 'current_state.json'
        state = _read_json(path, {}) or {}
        data = build_public_internal_metrics(run_root, cap_root, state)
        data["graph"] = build_public_internal_graph(data)
        return jsonify(redact_state(data, raw=False))

    @app.route('/api/debug/token_timeline')
    def debug_token_timeline():
        from .token_timeline import load_public_timeline_from_files
        from .public_redactor import redact_state
        return jsonify(redact_state(load_public_timeline_from_files(run_root), raw=False))

    @app.route('/api/debug/suggested_surgery')
    def debug_suggested_surgery():
        from .suggested_surgery import build_suggested_surgery_from_state
        from .public_redactor import redact_state
        path = run_root / 'dynamic_debug' / 'current_state.json'
        state = _read_json(path, {}) or {}
        return jsonify(redact_state(build_suggested_surgery_from_state(state), raw=False))

    @app.route('/api/premium/needed')
    def premium_needed():
        return jsonify({'ok': False, 'status': 'premium_required', 'paid_features': ['l2.hodge_auto', 'l2.hodge_output_intercept'], 'debug': {'failure_reason': 'not_in_free_client'}}), 402

    @app.route('/api/easter/l4')
    def l4_preview():
        from .easter_egg import L4EasterEgg
        return jsonify(L4EasterEgg().inject_graft()), 200


    # ── BDP Insight read-only observer (Whitebox MRI · 5 indicators) ──
    try:
        from bdp_insight.bridge.m13 import register_panel
        register_panel(app, run_root, cap_root)
    except Exception as exc:
        # Optional local package. If bdp_insight is absent or broken,
        # the M13 dashboard continues to work exactly as before.
        import logging
        logging.getLogger(__name__).info(
            "BDP Insight panel not registered: %s", exc
        )

    return app


def main():
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument('--capture-dir', default='results/base_mri_capture')
    ap.add_argument('--run-dir', default='results/base_debug_run')
    ap.add_argument('--host', default='127.0.0.1')
    ap.add_argument('--port', type=int, default=7860)
    args = ap.parse_args()
    create_app(args.capture_dir, args.run_dir).run(host=args.host, port=args.port, debug=False)

if __name__ == '__main__': main()
