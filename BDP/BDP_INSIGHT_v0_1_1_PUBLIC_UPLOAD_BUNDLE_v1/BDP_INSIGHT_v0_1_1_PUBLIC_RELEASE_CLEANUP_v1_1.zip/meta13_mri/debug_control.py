from __future__ import annotations
import time
from typing import Any, Dict, Optional, Set
from .command_queue import CommandQueue
from .entitlement import RuntimeEntitlement, resolve_entitlement

PAID_LOCAL_OPS = {'hodge_token_auto', 'hodge_auto', 'hodge_convert', 'hodge_token_convert', 'hodge_output_intercept', 'output_hodge_intercept', 'hodge_mid_output', 'hodge_output_auto'}
FREE_L3_OPS = {'embed_replace', 'embed_perturb'}
REMOVED_L2_OPS = {'token_swap', 'swap_token', 'swap_basis'}
T_ENGINE_OPS = {'t456_graft', 'edit_leaf', 'inject_graft', 'leaf_tau', 'proxy_finalize'}


class DebugController:
    """Free-tier runtime controller.

    This intentionally keeps L1 local and refuses to execute L2/L3/T-engine
    locally. The refusal is explicit, debuggable, and safe: every blocked command
    emits an event with the exact reason and routing hint.
    """

    def __init__(self, run_dir: str, run_id: str = 'live_run', skip_stale_commands: bool = True, entitlement: RuntimeEntitlement | None = None):
        self.run_dir = run_dir
        self.run_id = run_id
        self.queue = CommandQueue(run_dir)
        self.entitlement = entitlement or resolve_entitlement(client_version='0.1.12-runtime')
        if skip_stale_commands:
            try:
                self.cursor = len(self.queue.commands_path.read_text(encoding='utf-8').splitlines()) if self.queue.commands_path.exists() else 0
            except Exception:
                self.cursor = 0
        else:
            self.cursor = 0
        self.pause_requested = False
        self.pause_on_phases: Set[str] = set()
        self.last_phase = ''

    def _effective_entitlement(self, engine: Any) -> RuntimeEntitlement:
        """Return the entitlement that should control this command poll.

        v1.12.2: dashboard command APIs and the generate runtime can live in
        slightly different objects. The core/engine is the source of truth for
        actual model events, so resync the controller entitlement from
        ``engine.entitlement`` before blocking or accepting L2/L3 commands.
        """
        ent = getattr(engine, 'entitlement', None)
        if isinstance(ent, RuntimeEntitlement):
            if ent != self.entitlement:
                self.entitlement = ent
            return ent
        return self.entitlement

    def _snapshot(self, engine: Any, phase: str, extra: Dict[str, Any], source: str) -> Dict[str, Any]:
        ent = self._effective_entitlement(engine)
        status = engine.debug_snapshot() if hasattr(engine, 'debug_snapshot') else {'status': getattr(engine, 'status', lambda: {})()}
        return {
            'run_id': self.run_id,
            'ts': time.time(),
            'phase': phase,
            'source': source,
            'paused': bool(self.pause_requested or any(p.lower() in phase.lower() for p in self.pause_on_phases)),
            'tier': ent.tier,
            'paid_enabled': ent.paid_enabled,
            'paid_mode': ent.paid_mode,
            'free_scope': ['static_basic', 'l1_rewrite_prompt'],
            'paid_scope': ['l2_hodge_auto', 'l2_hodge_output_intercept'],
            'free_l3_scope': ['l3_embed_perturb'],
            't_engine': 'easter_egg_only',
            'extra': extra,
            **status,
        }

    def _blocked(self, op: str, payload: Dict[str, Any], reason: str) -> None:
        self.queue.append_event({
            'kind': 'blocked_command',
            'op': op,
            'payload_preview': str(payload)[:500],
            'reason': reason,
            'route_to': 'PremiumDebuggerClient or paid API server',
            'tier': 'free',
            'actual_model_event': False,
            'ts': time.time(),
        })

    def _paid_function_id(self, op: str) -> str:
        if op in {'token_swap', 'swap_token', 'swap_basis', 'hodge_output_intercept', 'output_intercept'}:
            return 'l2.manual_removed'
        if op in {'hodge_token_auto', 'hodge_auto', 'hodge_convert', 'hodge_token_convert'}:
            return 'l2.hodge_auto'
        if op in {'hodge_output_intercept', 'output_hodge_intercept', 'hodge_mid_output', 'hodge_output_auto'}:
            return 'l2.hodge_output_intercept'
        if op == 'embed_replace':
            return 'l3.embed_replace'
        if op == 'embed_perturb':
            return 'l3.embed_perturb'
        return op

    def _accept_paid_command(self, engine: Any, op: str, payload: Dict[str, Any], entitlement: RuntimeEntitlement | None = None) -> None:
        ent = entitlement or self._effective_entitlement(engine)
        function_id = self._paid_function_id(op)
        if function_id == 'l2.hodge_output_intercept':
            pending = getattr(engine, '_pending_output_hodge_intercept', None)
            if pending is None:
                pending = []
                setattr(engine, '_pending_output_hodge_intercept', pending)
            pending.append({'op': op, 'function_id': function_id, 'payload': dict(payload or {})})
        elif function_id.startswith('l2.'):
            pending = getattr(engine, '_pending_l2_token_surgery', None)
            if pending is None:
                pending = []
                setattr(engine, '_pending_l2_token_surgery', pending)
            pending.append({'op': op, 'function_id': function_id, 'payload': dict(payload or {})})
        elif function_id.startswith('l3.'):
            pending = getattr(engine, '_pending_l3_embed_surgery', None)
            if pending is None:
                pending = []
                setattr(engine, '_pending_l3_embed_surgery', pending)
            pending.append({'op': op, 'function_id': function_id, 'payload': dict(payload or {})})
        self.queue.append_event({
            'kind': 'paid_command_accepted',
            'op': op,
            'function_id': function_id,
            'payload_preview': str(payload)[:500],
            'tier': 'paid',
            'paid_mode': ent.paid_mode,
            'route_to': 'LocalPaidRuntime' if ent.paid_mode == 'local_import' else 'PremiumDebuggerClient',
            'actual_model_event': True,
            'preview_only': False,
            'ts': time.time(),
        })

    def _apply_command(self, engine: Any, cmd: Dict[str, Any]) -> None:
        op = str(cmd.get('op', '')).strip().lower()
        payload = dict(cmd.get('payload') or {})
        if op == 'pause':
            self.pause_requested = True
            phases = payload.get('phases') or []
            if isinstance(phases, str): phases = [x.strip() for x in phases.split(',') if x.strip()]
            self.pause_on_phases.update(phases)
            self.queue.append_event({'kind': 'pause_armed', 'phase_targets': list(self.pause_on_phases), 'ts': time.time()})
        elif op == 'resume':
            self.pause_requested = False
            if payload.get('clear_phases', True): self.pause_on_phases.clear()
            self.queue.append_event({'kind': 'resume', 'ts': time.time()})
        elif op == 'abort':
            setattr(engine, '_debug_abort_requested', True)
            self.pause_requested = False
            self.queue.append_event({'kind': 'abort', 'ts': time.time()})
        elif op == 'snapshot':
            snap = self._snapshot(engine, self.last_phase or 'manual', {'manual': True}, getattr(engine, 'source', 'main'))
            self.queue.append_event({'kind': 'snapshot', 'snapshot': snap, 'ts': time.time()})
        elif op == 'rewrite_prompt':
            new_prompt = payload.get('new_prompt', '')
            if new_prompt and hasattr(engine, '_pending_prompt_rewrite'):
                engine._pending_prompt_rewrite = str(new_prompt)
                self.queue.append_event({
                    'kind': 'rewrite_prompt',
                    'prompt_len': len(new_prompt),
                    'prompt_preview': str(new_prompt)[:160],
                    'ts': time.time(),
                    'tier': 'free_l1',
                    'mode': payload.get('mode') or 'queued',
                })
            else:
                self.queue.append_event({'kind': 'rewrite_prompt_ignored', 'reason': 'new_prompt missing or engine has no _pending_prompt_rewrite', 'ts': time.time()})
        elif op in {'arm_l1_mid_rewrite', 'arm_mid_l1', 'l1_mid_arm'}:
            # v1.10: 다음 generate를 일부 토큰 생성 후 중간 정지시켜 L1 prompt rewrite를 받는다.
            try:
                after_tokens = int(payload.get('after_tokens', 8))
            except Exception:
                after_tokens = 8
            after_tokens = max(1, min(after_tokens, 64))
            setattr(engine, '_l1_mid_rewrite_armed', True)
            setattr(engine, '_l1_mid_rewrite_after_tokens', after_tokens)
            self.queue.append_event({
                'kind': 'l1_mid_rewrite_armed',
                'after_tokens': after_tokens,
                'ts': time.time(),
                'tier': 'free_l1',
            })
        elif op in {'disarm_l1_mid_rewrite', 'cancel_l1_mid', 'l1_mid_cancel'}:
            setattr(engine, '_l1_mid_rewrite_armed', False)
            self.pause_requested = False
            self.queue.append_event({'kind': 'l1_mid_rewrite_disarmed', 'ts': time.time(), 'tier': 'free_l1'})
        elif op in REMOVED_L2_OPS:
            self.queue.append_event({
                'kind': 'removed_command',
                'op': op,
                'payload_preview': str(payload)[:500],
                'reason': 'Manual L2 token swap/graft and public Output intercept were removed. Use HodgeConverter auto.',
                'tier': 'removed',
                'actual_model_event': False,
                'ts': time.time(),
            })
        elif op in FREE_L3_OPS:
            function_id = self._paid_function_id(op)
            pending = getattr(engine, '_pending_l3_embed_surgery', None)
            if pending is None:
                pending = []
                setattr(engine, '_pending_l3_embed_surgery', pending)
            pending.append({'op': op, 'function_id': function_id, 'payload': dict(payload or {})})
            self.queue.append_event({
                'kind': 'free_l3_command_accepted',
                'op': op,
                'function_id': function_id,
                'payload_preview': str(payload)[:500],
                'tier': 'free_l3',
                'paid_mode': 'not_required',
                'route_to': 'LocalFreeL3Hook',
                'actual_model_event': True,
                'preview_only': False,
                'ts': time.time(),
            })
        elif op in PAID_LOCAL_OPS:
            ent = self._effective_entitlement(engine)
            if ent.paid_enabled:
                self._accept_paid_command(engine, op, payload, entitlement=ent)
            else:
                self._blocked(op, payload, 'Paid L2 HodgeConverter requires META13_PAID_KEY and Modal/API entitlement')
        elif op in T_ENGINE_OPS:
            self._blocked(op, payload, 'T-engine/L4 is easter-egg preview only until trust validation is complete')
        elif op in {'override', 'clear_override', 'phase_pause', 'phase_clear'}:
            self._blocked(op, payload, 'This operation is not part of the free public debugger surface')
        else:
            self.queue.append_event({'kind': 'unknown_command', 'op': op, 'payload_preview': str(payload)[:500], 'ts': time.time()})


    def _write_state_safely(self, snap: Dict[str, Any], *, phase: str) -> None:
        try:
            self.queue.write_state(snap)
        except Exception as exc:
            # State is diagnostic. Do not crash generation/freeze because the
            # dashboard or Windows briefly locked current_state.json.
            try:
                self.queue.append_event({
                    'kind': 'state_write_skipped',
                    'reason': type(exc).__name__,
                    'error': str(exc),
                    'phase': phase,
                    'ts': time.time(),
                })
            except Exception:
                pass

    def _raise_if_abort_requested(self, engine: Any) -> None:
        if getattr(engine, '_debug_abort_requested', False):
            if not getattr(engine, '_hard_abort_persistent', False):
                try:
                    engine._debug_abort_requested = False
                except Exception:
                    pass
            raise RuntimeError('DebugAbortRequested')

    def poll_commands_only(
        self,
        engine: Any,
        phase: str = 'command_poll',
        extra: Optional[Dict[str, Any]] = None,
        source: str = 'main',
        *,
        write_state: bool = True,
        append_event: bool = False,
    ) -> Dict[str, Any]:
        """Poll queued commands without appending a full checkpoint by default.

        v1.9 freeze waits call this repeatedly while the model is intentionally
        paused. Keeping this separate from poll_and_checkpoint prevents
        events.jsonl from being flooded by freeze_wait checkpoints every 150ms,
        while still allowing resume/abort/snapshot/L2-L3 blocked-command checks
        to be processed.
        """
        self.last_phase = phase
        extra = dict(extra or {})
        cmds, self.cursor = self.queue.read_commands_since(self.cursor)
        for cmd in cmds:
            self._apply_command(engine, cmd)
        snap = self._snapshot(engine, phase, extra, source)
        if write_state:
            self._write_state_safely(snap, phase=phase)
        if append_event:
            self.queue.append_event({
                'kind': 'command_poll',
                'phase': phase,
                'source': source,
                'extra': extra,
                'ts': time.time(),
            })
        self._raise_if_abort_requested(engine)
        return snap

    def poll_and_checkpoint(self, engine: Any, phase: str, extra: Optional[Dict[str, Any]] = None, source: str = 'main') -> Dict[str, Any]:
        self.last_phase = phase
        extra = dict(extra or {})
        cmds, self.cursor = self.queue.read_commands_since(self.cursor)
        for cmd in cmds:
            self._apply_command(engine, cmd)
        snap = self._snapshot(engine, phase, extra, source)
        self._write_state_safely(snap, phase=phase)
        self.queue.append_event({'kind': 'checkpoint', 'phase': phase, 'source': source, 'extra': extra, 'ts': time.time()})
        self._raise_if_abort_requested(engine)
        return snap
