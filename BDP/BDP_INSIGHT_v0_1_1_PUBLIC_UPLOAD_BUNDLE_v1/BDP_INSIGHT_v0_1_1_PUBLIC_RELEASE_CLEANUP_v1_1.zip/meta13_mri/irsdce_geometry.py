"""irsdce_geometry.py — paid-gated IRSDCE geometry stubs for v1.13.4.

IRSDCE geometry is a paid Whitebox MRI feature.  The free wheel keeps the
endpoint/wrapper importable and returns a locked card; graph generation is
handled by leased native/private code or a dev-only reference implementation.
"""
from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, Iterable
import importlib
import os

from .entitlement import resolve_entitlement
from .premium_client import PremiumDebuggerClient


def _locked_card(reason: str = "paid_runtime_required") -> Dict[str, Any]:
    return {
        "ok": True,
        "locked": True,
        "tier": "free",
        "axis": "IRSDCE geometry",
        "label": "IRSDCE Geometry: Locked",
        "message": "IRSDCE geometry is available in paid runtime.",
        "reason": reason,
        "public_safe": True,
        "nodes": [],
        "edges": [],
    }


def _load_reference_module():
    try:
        return importlib.import_module("dev_extras.irsdce_geometry_reference")
    except Exception:
        return None


def _dispatch_irsdce_paid(op: str, primitive_payload: Dict[str, Any]) -> Dict[str, Any]:
    ent = resolve_entitlement()
    if not ent.paid_enabled:
        return _locked_card()
    if ent.paid_mode == "lease_remote":
        client = PremiumDebuggerClient(api_key=os.getenv("META13_PAID_KEY") or os.getenv("META13_API_KEY"))
        lease = client.lease_function(f"deep.irsdce.{op}")
        return lease.execute("apply", primitive_payload)
    if ent.paid_mode == "local_import":
        ref = _load_reference_module()
        if ref is None:
            return _locked_card("local_import_reference_missing")
        fn = getattr(ref, f"_irsdce_{op}", None)
        if fn is None:
            return _locked_card(f"reference_impl_missing_{op}")
        return fn(primitive_payload)
    if ent.paid_mode == "lease_stub":
        return {"ok": False, "stub": True, "op": op, "reason": "lease_stub_no_remote", "nodes": [], "edges": []}
    return _locked_card("unknown_paid_mode")


def build_irsdce_geometry_graph(
    state: Dict[str, Any],
    events: Iterable[Dict[str, Any]] | None = None,
) -> Dict[str, Any]:
    ent = resolve_entitlement()
    if not ent.paid_enabled:
        return _locked_card()
    return _dispatch_irsdce_paid("build_graph", {"state": state or {}, "events": list(events or [])})


def load_irsdce_geometry_from_files(
    run_root: Path,
    state: Dict[str, Any] | None = None,
) -> Dict[str, Any]:
    ent = resolve_entitlement()
    if not ent.paid_enabled:
        return _locked_card()
    # File IO is free-side; paid/private code builds the actual graph.
    events = []
    try:
        path = Path(run_root) / "dynamic_debug" / "events.jsonl"
        if path.exists():
            import json
            for line in path.read_text(encoding="utf-8", errors="replace").splitlines()[-400:]:
                if line.strip():
                    try:
                        events.append(json.loads(line))
                    except Exception:
                        pass
    except Exception:
        events = []
    return build_irsdce_geometry_graph(state or {}, events)


__all__ = ["build_irsdce_geometry_graph", "load_irsdce_geometry_from_files", "_locked_card"]
