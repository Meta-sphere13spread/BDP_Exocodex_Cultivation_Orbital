"""paid_local_ops.py — paid surgery stubs for v1.13.4.

Free wheel policy
-----------------
This module keeps the public call surface importable, but does not contain the
paid surgery algorithms.  Paid function bodies are delivered by the SaaS/native
lease path, or by the Modal/SaaS server runtime when modal_remote is enabled.

Pattern A
---------
The client normalizes Python objects into primitive payloads first. Native
functions receive primitive values only; Python tokenizer/model objects are not
sent to the server and are not passed across the native ABI boundary.
"""
from __future__ import annotations

from dataclasses import dataclass
import importlib
import os
import re
import time
from typing import Any, Dict, Tuple

from .entitlement import resolve_entitlement
from .premium_client import PremiumDebuggerClient, PremiumRequired


@dataclass
class PaidApplyResult:
    ok: bool
    route: str
    changed: bool = False
    meta: Dict[str, Any] | None = None
    error: str = ""

    def event(self, *, function_id: str, source: str) -> Dict[str, Any]:
        return {
            "kind": "paid_surgery_applied" if self.ok and self.changed else "paid_surgery_noop",
            "function_id": function_id,
            "route": self.route,
            "changed": self.changed,
            "meta": self.meta or {},
            "error": self.error,
            "source": source,
            "tier": "paid",
            "actual_model_event": True,
            "preview_only": False,
            "ts": time.time(),
        }


def _paid_result_from_dict(result: Any, *, route: str) -> PaidApplyResult:
    if isinstance(result, PaidApplyResult):
        return result
    if isinstance(result, dict):
        return PaidApplyResult(
            ok=bool(result.get("ok", True)),
            route=str(result.get("route") or route),
            changed=bool(result.get("changed", False)),
            meta=dict(result.get("meta") or {k: v for k, v in result.items() if k not in {"ok", "route", "changed", "error"}}),
            error=str(result.get("error") or result.get("reason") or ""),
        )
    return PaidApplyResult(False, route, False, error=f"unexpected paid result type: {type(result).__name__}")


def _load_reference_module():
    """Release build: local Python paid reference is not shipped."""
    raise PremiumRequired(
        "local_import is disabled in this server-connected release; "
        "use META13_PAID_MODE=modal_remote"
    )


_BILLING_PER_CALL_USD = 0.5   # User policy 2026-05-03: $0.5 per dynamic debugger call
_BILLING_MARKER_PATH_ENV = "META13_BILLING_LOG"


def _emit_billing_marker(function_id: str, op: str, route: str,
                         paid_mode: str, ok: bool) -> None:
    """Append a $0.5 billing marker for this paid call.

    Per user policy 2026-05-03: dynamic debugger calls are billed
    individually so users only pay for what they invoke.

    The marker is appended to one of:
        $META13_BILLING_LOG (env)         — preferred path
        results/.billing/billing.jsonl    — fallback
    Each line is one paid call, JSON encoded.  Failures are silent —
    billing must NEVER break the runtime.
    """
    import json as _json
    import os as _os
    import time as _time
    try:
        log_path = _os.environ.get(_BILLING_MARKER_PATH_ENV)
        if not log_path:
            from pathlib import Path as _Path
            base = _Path("results") / ".billing"
            base.mkdir(parents=True, exist_ok=True)
            log_path = str(base / "billing.jsonl")
        rec = {
            "ts":             _time.time(),
            "function_id":    function_id,
            "op":             op,
            "route":          route,
            "paid_mode":      paid_mode,
            "amount_usd":     _BILLING_PER_CALL_USD,
            "ok":             bool(ok),
            "billing_policy": "per_call_2026_05_03",
        }
        with open(log_path, "a", encoding="utf-8") as f:
            f.write(_json.dumps(rec, ensure_ascii=False) + "\n")
    except Exception:
        # Billing record failures must NEVER affect the runtime call.
        pass



# --- BDP/M13 Modal remote paid-kernel patch ---
import json as _bdp_json
import urllib.error as _bdp_urlerror
import urllib.request as _bdp_urlrequest
import ssl as _bdp_ssl
import urllib.parse as _bdp_urlparse

_MODAL_REMOTE_PRIMITIVE_OPS = {
    "hodge_auto_replace_text",
    "hodge_output_replace_text",
}


def _modal_remote_debug_enabled() -> bool:
    return os.environ.get("BDP_MODAL_DEBUG", "0").strip().lower() in {"1", "true", "yes", "on"}


def _modal_json_safe(value: Any) -> Any:
    """Allow only JSON-safe primitive data across Modal API.

    Debugger: this intentionally rejects tokenizer/model/tensor objects so raw
    runtime objects are not uploaded by mistake.
    """
    if value is None or isinstance(value, (bool, int, float, str)):
        return value
    if isinstance(value, (list, tuple)):
        return [_modal_json_safe(v) for v in value]
    if isinstance(value, dict):
        return {str(k): _modal_json_safe(v) for k, v in value.items()}
    raise PremiumRequired(
        f"modal_remote only accepts JSON-safe primitive payloads; got {type(value).__name__}. "
        "Object-heavy L2/L3 calls need a primitive plan adapter first."
    )


def _dispatch_modal_remote(op: str, primitive_payload: Dict[str, Any], *, function_id: str, route: str) -> Any:
    """Call Modal-hosted compiled server_kernel.

    Required env:
      BDP_MODAL_KERNEL_URL = https://...--kernel-call-dev.modal.run
      BDP_MODAL_AUTH_TOKEN = same AUTH_TOKEN stored in Modal secret
    Optional env:
      BDP_MODAL_TIMEOUT    = default 60
      BDP_MODAL_DEBUG      = 1 for call logs
    """
    if op not in _MODAL_REMOTE_PRIMITIVE_OPS:
        raise PremiumRequired(
            f"modal_remote currently allows primitive text ops only; blocked op={op}. "
            "Convert tokenizer/model/tensor calls into primitive plans first."
        )

    endpoint = (
        os.environ.get("BDP_MODAL_KERNEL_URL")
        or os.environ.get("META13_MODAL_KERNEL_URL")
        or ""
    ).strip()
    auth_token = (
        os.environ.get("BDP_MODAL_AUTH_TOKEN")
        or os.environ.get("META13_MODAL_AUTH_TOKEN")
        or os.environ.get("META13_PAID_KEY")
        or os.environ.get("META13_API_KEY")
        or ""
    ).strip()

    if not endpoint:
        raise PremiumRequired("BDP_MODAL_KERNEL_URL is missing for modal_remote")
    if not auth_token:
        raise PremiumRequired("BDP_MODAL_AUTH_TOKEN is missing for modal_remote")

    args = _modal_json_safe(list(primitive_payload.get("_args", ())))
    kwargs = _modal_json_safe(dict(primitive_payload.get("_kwargs", {})))
    body = {"auth": auth_token, "op": op, "args": args, "kwargs": kwargs}
    raw_body = _bdp_json.dumps(body, ensure_ascii=False).encode("utf-8")
    req = _bdp_urlrequest.Request(
        endpoint,
        data=raw_body,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    timeout = float(os.environ.get("BDP_MODAL_TIMEOUT", "60"))

    if _modal_remote_debug_enabled():
        print(
            f"[{__name__}] modal_remote CALL op={op} route={route} "
            f"function_id={function_id} endpoint={endpoint} args_len={len(args)}",
            flush=True,
        )

    try:
        with _bdp_urlrequest.urlopen(req, timeout=timeout) as resp:
            resp_text = resp.read().decode("utf-8", errors="replace")
    except _bdp_urlerror.HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="replace")
        raise PremiumRequired(f"modal_remote HTTP {exc.code}: {detail[:1200]}")
    except Exception as exc:
        raise PremiumRequired(f"modal_remote request failed: {type(exc).__name__}: {exc}")

    try:
        data = _bdp_json.loads(resp_text)
    except Exception as exc:
        raise PremiumRequired(f"modal_remote bad JSON: {type(exc).__name__}: {resp_text[:1200]}")

    if not isinstance(data, dict):
        raise PremiumRequired(f"modal_remote bad response type: {type(data).__name__}")
    if data.get("ok") is not True:
        raise PremiumRequired(
            f"modal_remote op={op} failed: {data.get('error_type', 'RemoteError')}: {data.get('error', data)}"
        )

    result = data.get("result")
    # Modal JSON turns tuple -> list. Convert back to existing wrapper contract.
    if op in {"hodge_auto_replace_text", "hodge_output_replace_text"}:
        if isinstance(result, list) and len(result) == 3:
            meta = result[2] if isinstance(result[2], dict) else {"remote_meta_raw": result[2]}
            meta = dict(meta)
            meta["remote_ok"] = True
            meta["remote_route"] = "modal_remote"
            meta["remote_function_id"] = function_id
            meta["remote_op"] = op
            return str(result[0]), bool(result[1]), meta
        if isinstance(result, dict):
            meta = dict(result.get("meta") or {})
            meta["remote_ok"] = True
            meta["remote_route"] = "modal_remote"
            meta["remote_function_id"] = function_id
            meta["remote_op"] = op
            return (
                str(result.get("new_text", primitive_payload.get("text", ""))),
                bool(result.get("changed", False)),
                meta,
            )
    return result

# --- end BDP/M13 Modal remote paid-kernel patch ---


# --- B_I_S6 API Hub / RapidAPI output-fallback bridge ---
from pathlib import Path as _bdp_Path


def _bdp_read_first_existing_text(*names: str) -> str:
    """Read API Hub config from env-friendly package files without logging secrets."""
    candidates = []
    cwd = _bdp_Path.cwd()
    try:
        module_root = _bdp_Path(__file__).resolve().parents[1]
    except Exception:
        module_root = cwd
    for name in names:
        candidates.extend([cwd / name, module_root / name, module_root.parent / name])
    for p in candidates:
        try:
            if p.exists():
                return p.read_text(encoding="utf-8").strip()
        except Exception:
            continue
    return ""


def _rapidapi_config() -> tuple[str, str, str]:
    url = (os.environ.get("BDP_RAPIDAPI_URL") or os.environ.get("META13_RAPIDAPI_URL") or _bdp_read_first_existing_text("rapidapi_url.txt")).strip()
    host = (os.environ.get("BDP_RAPIDAPI_HOST") or os.environ.get("META13_RAPIDAPI_HOST") or _bdp_read_first_existing_text("rapidapi_host.txt")).strip()
    key = (os.environ.get("BDP_RAPIDAPI_KEY") or os.environ.get("META13_RAPIDAPI_KEY") or _bdp_read_first_existing_text("rapidapi_key.txt")).strip()
    if url and not url.rstrip("/").endswith("/v1/hodge/convert"):
        url = url.rstrip("/") + "/v1/hodge/convert"
    return url, host, key


def _rapidapi_config_available() -> bool:
    url, host, key = _rapidapi_config()
    return bool(url and host and key)




def _bdp_rapidapi_host_has_underscore(url: str, host: str) -> bool:
    """RapidAPI may generate an underscore-containing host slug.

    Python's ssl.match_hostname rejects underscores even when other clients
    appear to work.  Product fix is to rename the RapidAPI slug with hyphens.
    This helper only detects that specific compatibility case.
    """
    try:
        parsed_host = _bdp_urlparse.urlparse(str(url)).hostname or ""
    except Exception:
        parsed_host = ""
    return "_" in str(host or "") or "_" in parsed_host


def _bdp_rapidapi_ssl_fallback_enabled() -> bool:
    # Default ON only to keep current RapidAPI underscore slugs usable from
    # Python urllib.  Set to 0 after renaming the API slug to hyphen-only.
    return os.environ.get("BDP_RAPIDAPI_ALLOW_UNDERSCORE_SSL_FALLBACK", "1").strip().lower() in {"1", "true", "yes", "on"}


def _bdp_rapidapi_urlopen(req, *, timeout: float, url: str, host: str):
    try:
        return _bdp_urlrequest.urlopen(req, timeout=timeout)
    except _bdp_urlerror.URLError as exc:
        msg = str(exc)
        if (
            "CERTIFICATE_VERIFY_FAILED" in msg
            and _bdp_rapidapi_host_has_underscore(url, host)
            and _bdp_rapidapi_ssl_fallback_enabled()
        ):
            ctx = _bdp_ssl.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode = _bdp_ssl.CERT_NONE
            if _modal_remote_debug_enabled() or os.environ.get("BDP_RAPIDAPI_DEBUG", "0").lower() in {"1", "true", "yes", "on"}:
                print(
                    f"[{__name__}] rapidapi_remote SSL_COMPAT_FALLBACK underscore_host={host!r} "
                    "reason=python_hostname_mismatch; prefer hyphen-only RapidAPI slug for production",
                    flush=True,
                )
            return _bdp_urlrequest.urlopen(req, timeout=timeout, context=ctx)
        raise


def _payload_pick(payload: Dict[str, Any], *keys: str, default: Any = "") -> Any:
    for k in keys:
        v = payload.get(k)
        if v is not None and str(v) != "":
            return v
    return default


def _to_int(value: Any, default: int, *, lo: int = 0, hi: int = 256) -> int:
    try:
        v = int(value)
    except Exception:
        v = default
    return max(lo, min(hi, v))


def _dispatch_rapidapi_remote(op: str, primitive_payload: Dict[str, Any], *, function_id: str, route: str) -> Any:
    """Call API Hub / RapidAPI endpoint.

    Product rule:
    - M13 package does not contain Hodge scoring/selection logic.
    - For product L2, mode=output sends only model-generated partial output
      to the paid server kernel through RapidAPI.
    - mode=auto is retained only for smoke tests/backward compatibility.
    """
    if op not in {"hodge_auto_replace_text", "hodge_output_replace_text"}:
        raise PremiumRequired(f"rapidapi_remote allows Hodge primitive text ops only; blocked op={op}")

    url, host, key = _rapidapi_config()
    if not url:
        raise PremiumRequired("rapidapi_url.txt or BDP_RAPIDAPI_URL is missing")
    if not host:
        raise PremiumRequired("rapidapi_host.txt or BDP_RAPIDAPI_HOST is missing")
    if not key:
        raise PremiumRequired("rapidapi_key.txt or BDP_RAPIDAPI_KEY is missing")

    args = list(primitive_payload.get("_args", ()))
    kwargs0 = dict(primitive_payload.get("_kwargs", {}))

    if op == "hodge_output_replace_text":
        text = str(args[0] if args else primitive_payload.get("text", ""))
        payload = dict(args[1] if len(args) > 1 and isinstance(args[1], dict) else primitive_payload.get("payload", {}) or {})
        replacement = str(_payload_pick(payload, "new_word", "replacement", "value", default=""))
        target_regex = payload.get("target_regex")
        body = {
            "text": text,
            "replacement": replacement,
            "target_regex": target_regex,
            "mode": "output",
            "wait_tokens": _to_int(_payload_pick(payload, "hodge_wait_tokens", "wait_tokens", "after_tokens", default=8), 8, lo=0, hi=256),
            "continuation_tokens": _to_int(payload.get("continuation_tokens", 16), 16, lo=0, hi=128),
        }
        # Optional explicit target for server-side fail-closed output replacement.
        old_word = _payload_pick(payload, "old_word", "target", "old_value", default="")
        if str(old_word).strip():
            body["old_word"] = str(old_word)
    else:
        text = str(args[0] if args else primitive_payload.get("text", ""))
        replacement = str(args[1] if len(args) > 1 else primitive_payload.get("new_word", primitive_payload.get("replacement", "")))
        body = {
            "text": text,
            "replacement": replacement,
            "target_regex": kwargs0.get("target_regex", primitive_payload.get("target_regex")),
            "mode": "auto",
        }

    raw_body = _bdp_json.dumps(body, ensure_ascii=False).encode("utf-8")
    req = _bdp_urlrequest.Request(
        url,
        data=raw_body,
        headers={
            "Content-Type": "application/json; charset=utf-8",
            "X-RapidAPI-Key": key,
            "X-RapidAPI-Host": host,
        },
        method="POST",
    )
    timeout = float(os.environ.get("BDP_RAPIDAPI_TIMEOUT", os.environ.get("BDP_MODAL_TIMEOUT", "60")))

    if _modal_remote_debug_enabled() or os.environ.get("BDP_RAPIDAPI_DEBUG", "0").lower() in {"1", "true", "yes", "on"}:
        print(
            f"[{__name__}] rapidapi_remote CALL op={op} route={route} function_id={function_id} "
            f"endpoint={url} mode={body.get('mode')} text_len={len(str(body.get('text','')))}",
            flush=True,
        )

    try:
        with _bdp_rapidapi_urlopen(req, timeout=timeout, url=url, host=host) as resp:
            resp_text = resp.read().decode("utf-8", errors="replace")
    except _bdp_urlerror.HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="replace")
        raise PremiumRequired(f"rapidapi_remote HTTP {exc.code}: {detail[:1200]}")
    except Exception as exc:
        raise PremiumRequired(f"rapidapi_remote request failed: {type(exc).__name__}: {exc}")

    try:
        data = _bdp_json.loads(resp_text)
    except Exception as exc:
        raise PremiumRequired(f"rapidapi_remote bad JSON: {type(exc).__name__}: {resp_text[:1200]}")
    if not isinstance(data, dict):
        raise PremiumRequired(f"rapidapi_remote bad response type: {type(data).__name__}")
    if data.get("ok") is not True:
        raise PremiumRequired(f"rapidapi_remote op={op} failed: {data.get('error_type','RemoteError')}: {data.get('error', data)}")

    meta = {
        "remote_ok": True,
        "remote_route": "rapidapi_remote",
        "remote_function_id": function_id,
        "remote_op": op,
        "request_id": data.get("request_id", ""),
        "public_mode": data.get("mode", ""),
    }
    return str(data.get("text", body.get("text", ""))), bool(data.get("changed", False)), meta
# --- end B_I_S6 bridge ---


def _dispatch_paid(op: str, primitive_payload: Dict[str, Any], *, function_id: str, route: str) -> Dict[str, Any]:
    """Dispatch a primitive payload to paid runtime.

    - lease_remote: lease native material and execute locally
    - local_import: server runtime
    - lease_stub: controlled no-op flow test

    Billing: every successful paid call emits a $0.5 billing marker
    (per user policy 2026-05-03).
    """
    ent = resolve_entitlement()
    if not ent.paid_enabled:
        raise PremiumRequired(f"op={op} requires paid entitlement")

    result: Dict[str, Any]
    ok = False
    try:
        # B_I_S6.1 hotfix: API Hub / RapidAPI config takes precedence for
        # primitive Hodge ops, even when CLI paid-mode is modal_remote.
        # Without this, the old direct-Modal path raises
        # "BDP_MODAL_KERNEL_URL is missing for modal_remote".
        if _rapidapi_config_available() and op in {"hodge_auto_replace_text", "hodge_output_replace_text"}:
            result = _dispatch_rapidapi_remote(op, primitive_payload, function_id=function_id, route=route)
            ok = True
        elif ent.paid_mode == "modal_remote":
            result = _dispatch_modal_remote(op, primitive_payload, function_id=function_id, route=route)
            ok = True
        elif ent.paid_mode == "lease_remote":
            client = PremiumDebuggerClient(api_key=os.getenv("META13_PAID_KEY") or os.getenv("META13_API_KEY"))
            lease = client.lease_function(function_id)
            result = lease.execute("apply", primitive_payload)
            ok = bool(result.get("ok", True)) if isinstance(result, dict) else True
        elif ent.paid_mode == "local_import":
            ref = _load_reference_module()
            fn = getattr(ref, op, None)
            if fn is None:
                raise PremiumRequired(f"reference implementation missing for op={op}")
            result = fn(**primitive_payload) if op.startswith("_primitive_") else fn(*primitive_payload.get("_args", ()), **primitive_payload.get("_kwargs", {}))
            ok = True
        elif ent.paid_mode == "lease_stub":
            result = {
                "ok": False,
                "stub": True,
                "route": route,
                "changed": False,
                "error": "lease_stub_no_remote",
                "meta": {"op": op, "function_id": function_id},
            }
            ok = False
        else:
            raise PremiumRequired(f"unknown paid_mode={ent.paid_mode}")
    finally:
        # Emit billing marker for every paid call attempt.  Stub mode
        # is NOT billed (it's a flow-test, not a real surgery).
        if ent.paid_mode != "lease_stub":
            _emit_billing_marker(function_id=function_id, op=op,
                                 route=route, paid_mode=ent.paid_mode,
                                 ok=ok)

    return result



# --- B_I_S1 Hodge fail-closed target guards ---
def _bis1_regex_search(text: str, pattern: Any) -> tuple[bool, str]:
    """Return (found, reason). Invalid/missing patterns fail closed only when explicitly provided."""
    pat = "" if pattern is None else str(pattern)
    if not pat.strip():
        return True, "no_explicit_regex"
    try:
        return (re.search(pat, str(text)) is not None), "regex_found" if re.search(pat, str(text)) else "regex_not_found"
    except Exception as exc:
        return False, f"invalid_regex:{type(exc).__name__}:{exc}"


def _bis1_payload_target_present(text: str, payload: Dict[str, Any]) -> tuple[bool, Dict[str, Any]]:
    """Fail closed for paid output intercept.

    Product rule:
    - If target_regex is supplied and it does not match, do not replace another candidate.
    - If target old_word is supplied and it is absent, do not replace another candidate.
    - If selector=after_equals and no explicit regex exists, require an equals-result number.
    """
    payload = dict(payload or {})
    stext = str(text or "")
    selector = str(payload.get("selector", "") or "").strip().lower()
    target_regex = payload.get("target_regex")
    old_word = payload.get("old_word", payload.get("target_old_word", payload.get("target", None)))

    if target_regex is not None and str(target_regex).strip():
        ok, reason = _bis1_regex_search(stext, target_regex)
        if not ok:
            return False, {"reason": "target_regex_not_found_fail_closed", "regex_reason": reason, "target_regex": str(target_regex)[:160]}
        return True, {"target_guard": "regex_present"}

    if old_word is not None and str(old_word).strip():
        old = str(old_word)
        if old not in stext:
            return False, {"reason": "old_word_not_found_fail_closed", "old_word_preview": old[:80]}
        return True, {"target_guard": "old_word_present"}

    if selector in {"after_equals", "result_number"}:
        default_pat = r"(?<==\s*)\d+"
        ok, reason = _bis1_regex_search(stext, default_pat)
        if not ok:
            return False, {"reason": "after_equals_value_not_found_fail_closed", "regex_reason": reason, "target_regex": default_pat}
        payload.setdefault("target_regex", default_pat)
        return True, {"target_guard": "after_equals_default_regex", "target_regex": default_pat}

    return True, {"target_guard": "auto_allowed"}


def _bis1_auto_target_present(text: str, selector: str | None, target_regex: Any) -> tuple[bool, Dict[str, Any]]:
    """Fail closed for Hodge auto when caller gave an explicit target regex."""
    stext = str(text or "")
    if target_regex is not None and str(target_regex).strip():
        ok, reason = _bis1_regex_search(stext, target_regex)
        if not ok:
            return False, {"reason": "target_regex_not_found_fail_closed", "regex_reason": reason, "target_regex": str(target_regex)[:160]}
        return True, {"target_guard": "regex_present"}
    return True, {"target_guard": "auto_allowed"}
# --- end B_I_S1 guards ---


# --- Hodge-only public redaction ---
def _hodge_only_redact_meta(meta: Dict[str, Any] | None) -> Dict[str, Any]:
    """Keep reverse-engineering-sensitive selector/scoring details out of client-visible events.

    Full hiding requires server endpoint redaction or a rebuilt native .so.
    This client-side redaction protects dashboard/log surfaces.
    """
    src = dict(meta or {})
    keep = {}
    for k in ("mode", "match_path", "old_text_preview", "new_text_preview", "char_position", "segment_preview", "partial_preview_before", "partial_preview_after", "remote_ok", "remote_route", "remote_function_id", "remote_op", "target_guard", "reason"):
        if k in src:
            keep[k] = src[k]
    # Explicitly drop selector/candidate scoring internals.
    keep["public_redacted"] = True
    return keep

def hodge_auto_replace_text(
    text: str,
    new_word: Any,
    *,
    selector: str = "auto",
    target_regex: str | None = None,
) -> Tuple[str, bool, Dict[str, Any]]:
    """Text in/text out paid Hodge conversion.

    This is the safest first native candidate because all inputs are primitive.
    """
    target_ok, target_meta = _bis1_auto_target_present(text, selector, target_regex)
    if not target_ok:
        return str(text), False, {**target_meta, "mode": "hodge_auto_fail_closed"}
    primitive = {
        "_args": (text, new_word),
        "_kwargs": {"selector": selector, "target_regex": target_regex},
        "text": text,
        "new_word": "" if new_word is None else str(new_word),
        "selector": selector,
        "target_regex": target_regex,
    }
    result = _dispatch_paid(
        "hodge_auto_replace_text",
        primitive,
        function_id="l2.hodge_auto",
        route="L2_HODGE_AUTO",
    )
    if isinstance(result, tuple) and len(result) == 3:
        return result[0], bool(result[1]), _hodge_only_redact_meta(result[2])
    if isinstance(result, dict):
        return (
            str(result.get("new_text", text)),
            bool(result.get("changed", False)),
            _hodge_only_redact_meta(result.get("meta") or {}),
        )
    return text, False, {"reason": "unexpected paid result type"}


def hodge_output_replace_text(text: str, payload: Dict[str, Any]) -> Tuple[str, bool, Dict[str, Any]]:
    payload = dict(payload or {})
    target_ok, target_meta = _bis1_payload_target_present(text, payload)
    if not target_ok:
        return str(text), False, {**target_meta, "mode": "output_hodge_fail_closed"}
    if target_meta.get("target_regex") and not payload.get("target_regex"):
        payload["target_regex"] = target_meta.get("target_regex")
    primitive = {
        "_args": (text, payload),
        "_kwargs": {},
        "text": text,
        "payload": dict(payload or {}),
    }
    result = _dispatch_paid(
        "hodge_output_replace_text",
        primitive,
        function_id="l2.hodge_output_intercept",
        route="L2_HODGE_OUTPUT_INTERCEPT",
    )
    if isinstance(result, tuple) and len(result) == 3:
        return result[0], bool(result[1]), _hodge_only_redact_meta(result[2])
    if isinstance(result, dict):
        return (
            str(result.get("new_text", text)),
            bool(result.get("changed", False)),
            _hodge_only_redact_meta(result.get("meta") or {}),
        )
    return text, False, {"reason": "unexpected paid result type"}


def apply_l2_hodge_auto_surgery(tokenizer: Any, args: tuple, kwargs: dict, payload: Dict[str, Any]) -> Tuple[tuple, dict, PaidApplyResult]:
    """L2 Hodge auto surgery wrapper.

    Dev local_import delegates to reference implementation. lease_remote expects
    primitive payload in future native builds.
    """
    primitive = {"_args": (tokenizer, args, kwargs, dict(payload or {})), "_kwargs": {}, "payload": dict(payload or {})}
    try:
        result = _dispatch_paid(
            "apply_l2_hodge_auto_surgery",
            primitive,
            function_id="l2.hodge_auto",
            route="L2_HODGE_AUTO",
        )
    except PremiumRequired as exc:
        return args, kwargs, PaidApplyResult(False, "L2_HODGE_AUTO", False, error=str(exc))
    if isinstance(result, tuple) and len(result) == 3:
        return result[0], bool(result[1]), _hodge_only_redact_meta(result[2])
    pr = _paid_result_from_dict(result, route="L2_HODGE_AUTO")
    return args, kwargs, pr


def apply_l2_token_surgery(tokenizer: Any, args: tuple, kwargs: dict, payload: Dict[str, Any]) -> Tuple[tuple, dict, PaidApplyResult]:
    """Removed product surface: manual L2 token swap/graft/basis surgery.

    Paid L2 value is now limited to HodgeConverter auto and Output intercept.
    Keeping this stub prevents old callers from silently executing a deprecated
    path while preserving import compatibility.
    """
    return args, kwargs, PaidApplyResult(
        True,
        "L2_TOKEN_SURGERY_REMOVED",
        False,
        meta={
            "removed": True,
            "reason": "manual L2 token swap/graft/basis surgery removed from product surface",
            "use": "hodge_auto_or_output_intercept",
        },
    )


def install_l3_embedding_hook(model: Any, payload: Dict[str, Any]) -> Tuple[Any, PaidApplyResult]:
    """Install a one-generate embedding hook.

    Dashboard execution fix:
    - model hooks must be local because the model object lives locally.
    - modal_remote still keeps L2/Hodge scoring on the server; L3 mode names are
      non-secret and are applied as a one-shot local tensor transform.
    """
    # L3 is a free local one-generate hook. It intentionally does not require
    # paid entitlement and does not call the Modal/server kernel.

    mode = str(payload.get("mode", "suppress") or "suppress").lower()
    try:
        position = int(payload.get("position", 0) or 0)
    except Exception:
        position = 0
    try:
        magnitude = float(payload.get("magnitude", payload.get("strength", 0.3)) or 0.3)
    except Exception:
        magnitude = 0.3
    magnitude = max(0.0, min(abs(magnitude), 5.0))

    if mode not in {"amplify", "suppress", "noise", "replace"}:
        return None, PaidApplyResult(False, "L3_EMBED_PERTURB", False, error=f"unsupported L3 mode={mode}")

    try:
        emb = model.get_input_embeddings()
    except Exception as exc:
        return None, PaidApplyResult(False, "L3_EMBED_PERTURB", False, error=f"input embeddings unavailable: {type(exc).__name__}: {exc}")

    state = {"used": False}

    def _hook(_module, _inputs, output):
        if state["used"]:
            return output
        state["used"] = True
        try:
            y = output.clone()
            if y.ndim < 3:
                return output
            seq_len = int(y.shape[1])
            pos = position
            if pos < 0:
                pos = seq_len + pos
            pos = max(0, min(pos, seq_len - 1))
            if mode == "amplify":
                y[:, pos, :] = y[:, pos, :] * (1.0 + magnitude)
            elif mode == "suppress":
                y[:, pos, :] = y[:, pos, :] * max(0.0, 1.0 - magnitude)
            elif mode == "noise":
                y[:, pos, :] = y[:, pos, :] + y[:, pos, :].new_empty(y[:, pos, :].shape).normal_(0, magnitude)
            elif mode == "replace":
                y[:, pos, :] = 0
            return y
        except Exception:
            return output

    try:
        handle = emb.register_forward_hook(_hook)
    except Exception as exc:
        return None, PaidApplyResult(False, "L3_EMBED_PERTURB", False, error=f"hook install failed: {type(exc).__name__}: {exc}")

    return handle, PaidApplyResult(
        True,
        "L3_EMBED_PERTURB",
        True,
        meta={
            "mode": mode,
            "position": position,
            "magnitude": magnitude,
            "one_generate_hook": True,
            "remote_route": "free_local_hook",
            "tier": "free_l3",
        },
    )

