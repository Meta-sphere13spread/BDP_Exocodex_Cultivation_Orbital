/* dashboard_prologue_host.js — v0.2
   Parent dashboard bridge for Meta-13 Interactive Prologue.
   No framework dependency. No user prompt/model/log/tensor upload. */
(function () {
  'use strict';

  const DEFAULT_CONFIG = {
    autoCheck: true,
    enableSse: false,
    checkUrl: '/prologue/check',
    openUrl: '/prologue/open',
    resultUrl: '/api/prologue/result',
    resetUrl: '/prologue/reset',
    eventsUrl: '/prologue/events',
    targetsUrl: '/prologue/targets'
  };

  const COMMON_TARGETS = {
    'metric-route': ['#debug-route', '[data-metric="route"]'],
    'metric-drift': ['#debug-drift', '[data-metric="drift"]'],
    'metric-tau': ['#debug-tau', '[data-metric="tau"]'],
    'metric-deff': ['#debug-deff', '[data-metric="deff"]', '[data-metric="d_eff"]'],
    'prompt-panel': ['#prompt-panel', '[data-panel="prompt"]', '[data-prologue-role="prompt"]', 'textarea'],
    'token-row': ['#token-row', '[data-panel="tokens"]', '[data-prologue-role="tokens"]'],
    'surgery-l1': ['#surgery-l1', '[data-surgery-level="L1"]'],
    'surgery-l2': ['#surgery-l2', '[data-surgery-level="L2"]'],
    'surgery-l3': ['#surgery-l3', '[data-surgery-level="L3"]'],
    'surgery-l4': ['#surgery-l4', '[data-surgery-level="L4"]'],
    'result-panel': ['#result-panel', '[data-panel="result"]', '[data-prologue-role="result"]']
  };

  const state = {
    config: { ...DEFAULT_CONFIG },
    pwin: null,
    highlighted: null,
    tooltip: null,
    dim: null,
    freezeBanner: null,
    toastTimer: null,
    sse: null,
    initialized: false
  };

  function log(...args) {
    if (window.localStorage && localStorage.getItem('META13_PROLOGUE_DEBUG') === '1') {
      console.debug('[Meta13PrologueHost]', ...args);
    }
  }

  function safeFetch(url, options) {
    return fetch(url, options).catch(function (err) {
      log('fetch failed', url, err);
      return null;
    });
  }

  function escapeHtml(s) {
    return String(s == null ? '' : s).replace(/[&<>'"]/g, function (c) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' })[c];
    });
  }

  function ensureDefaultTargets() {
    Object.keys(COMMON_TARGETS).forEach(function (target) {
      if (document.querySelector('[data-prologue-id="' + target + '"]')) return;
      const selectors = COMMON_TARGETS[target];
      for (let i = 0; i < selectors.length; i++) {
        const el = document.querySelector(selectors[i]);
        if (el) {
          el.setAttribute('data-prologue-id', target);
          return;
        }
      }
    });
  }

  function findTarget(target) {
    if (!target) return null;
    const exact = document.querySelector('[data-prologue-id="' + CSS.escape(target) + '"]');
    if (exact) return exact;
    const byId = document.getElementById(target);
    if (byId) return byId;
    const fallbacks = COMMON_TARGETS[target] || [];
    for (let i = 0; i < fallbacks.length; i++) {
      const el = document.querySelector(fallbacks[i]);
      if (el) return el;
    }
    return null;
  }

  function removeEl(el) {
    if (el && el.parentNode) el.parentNode.removeChild(el);
  }

  function clearHighlight() {
    if (state.highlighted) {
      state.highlighted.classList.remove('meta13-prologue-highlight');
      state.highlighted.removeAttribute('data-meta13-prologue-kind');
    }
    state.highlighted = null;
    removeEl(state.tooltip);
    removeEl(state.dim);
    removeEl(state.freezeBanner);
    state.tooltip = null;
    state.dim = null;
    state.freezeBanner = null;
  }

  function placeTooltip(anchor, title, message, kind) {
    const tip = document.createElement('div');
    tip.className = 'meta13-prologue-tooltip';
    tip.setAttribute('role', 'status');
    tip.innerHTML = [
      '<div class="m13p-tip-title">' + escapeHtml(title || 'Meta-13 Prologue') + '</div>',
      '<div class="m13p-tip-body">' + escapeHtml(message || '') + '</div>',
      '<div class="m13p-tip-actions"><button type="button" data-m13p-close>닫기</button></div>'
    ].join('');
    tip.querySelector('[data-m13p-close]').onclick = clearHighlight;
    document.body.appendChild(tip);

    const r = anchor.getBoundingClientRect();
    const tw = tip.offsetWidth || 280;
    const th = tip.offsetHeight || 100;
    let left = Math.min(Math.max(12, r.left), window.innerWidth - tw - 12);
    let top = r.bottom + 12;
    if (top + th > window.innerHeight - 12) top = Math.max(12, r.top - th - 12);
    tip.style.left = Math.round(left) + 'px';
    tip.style.top = Math.round(top) + 'px';
    tip.dataset.kind = kind || 'info';
    state.tooltip = tip;
  }

  function showFreezeBanner(text) {
    removeEl(state.freezeBanner);
    const b = document.createElement('div');
    b.className = 'meta13-prologue-freeze-banner';
    b.textContent = text || 'AUTO_FREEZE — 수술 타이밍 고정';
    document.body.appendChild(b);
    state.freezeBanner = b;
  }

  function highlight(target, title, message, kind) {
    ensureDefaultTargets();
    clearHighlight();
    const el = findTarget(target);
    if (!el) {
      toast('표시할 대시보드 위치를 찾지 못했습니다: ' + target);
      log('target not found', target);
      return false;
    }
    const dim = document.createElement('div');
    dim.className = 'meta13-prologue-dim';
    document.body.appendChild(dim);
    state.dim = dim;

    el.classList.add('meta13-prologue-highlight');
    el.setAttribute('data-meta13-prologue-kind', kind || 'info');
    state.highlighted = el;
    el.scrollIntoView({ behavior: 'smooth', block: 'center', inline: 'center' });
    setTimeout(function () { placeTooltip(el, title, message, kind); }, 180);
    if (String(title || '').toLowerCase().indexOf('freeze') >= 0) showFreezeBanner(title);
    return true;
  }

  function clearPreview(target) {
    const el = findTarget(target);
    if (!el) return;
    const next = el.nextElementSibling;
    if (next && next.classList.contains('meta13-prologue-preview-badge')) removeEl(next);
  }

  function previewValue(target, value, kind, note) {
    ensureDefaultTargets();
    const el = findTarget(target);
    if (!el) {
      toast('preview 위치를 찾지 못했습니다: ' + target);
      return false;
    }
    clearPreview(target);
    const badge = document.createElement('span');
    badge.className = 'meta13-prologue-preview-badge';
    badge.dataset.kind = kind || 'simulated';
    badge.title = note || '프롤로그 예상값입니다. 실제 실행 결과와 구분하세요.';
    badge.textContent = String(value == null ? '—' : value);
    el.insertAdjacentElement('afterend', badge);
    return true;
  }

  function clearAllPreviews() {
    document.querySelectorAll('.meta13-prologue-preview-badge').forEach(removeEl);
  }

  function applyResultToDashboard(d) {
    const r = d && d.last_result;
    if (!r) return;
    const map = {
      'metric-route': r.route,
      'metric-drift': r.drift,
      'metric-deff': r.deff
    };
    Object.keys(map).forEach(function (target) {
      const val = map[target];
      if (val == null) return;
      const el = findTarget(target);
      if (el) {
        el.textContent = val;
        previewValue(target, val, 'actual', '프롤로그 적용 결과');
      }
    });
    highlight('result-panel', 'COMPARE', 'Before/After 결과가 대시보드에 반영되었습니다.', 'success');
  }

  function toast(message) {
    let t = document.querySelector('.meta13-prologue-toast');
    if (!t) {
      t = document.createElement('div');
      t.className = 'meta13-prologue-toast';
      document.body.appendChild(t);
    }
    t.textContent = message;
    clearTimeout(state.toastTimer);
    state.toastTimer = setTimeout(function () { removeEl(t); }, 2600);
  }

  function postResult(data) {
    return fetch(state.config.resultUrl || '/api/prologue/result', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data || {})
    })
      .then(function (r) {
        return r.json().then(function (j) {
          if (!r.ok || !j.ok) {
            console.warn('[Meta13 Prologue] result save failed', r.status, j);
            toast('프롤로그 결과 저장 실패: ' + (j.error || r.status));
          } else {
            console.log('[Meta13 Prologue] result saved', j);
          }
          return j;
        });
      })
      .catch(function (err) {
        console.warn('[Meta13 Prologue] result save error', err);
        toast('프롤로그 결과 저장 오류: ' + err);
        return null;
      });
  }

  function handleMessage(ev) {
    // v0.2: exact origin validation. prologue는 같은 Flask origin에서 열린다.
    if (ev.origin !== window.location.origin) return;
    const d = ev.data;
    if (!d || d.source !== 'meta13_prologue' || typeof d.action !== 'string') return;

    log('message', d.action, d);
    switch (d.action) {
      case 'highlight_target':
        highlight(d.target, d.title, d.message, d.kind);
        break;
      case 'preview_value':
        previewValue(d.target, d.value, d.kind || 'simulated', d.note);
        break;
      case 'clear_highlight':
        clearHighlight();
        break;
      case 'clear_preview':
        if (d.target) clearPreview(d.target); else clearAllPreviews();
        break;
      case 'apply_prologue_result':
        if (!d.direct_saved) postResult(d);
        applyResultToDashboard(d);
        toast('프롤로그 결과가 대시보드에 적용되었습니다.');

        setTimeout(function () {
          if (typeof window.loadState === 'function') window.loadState();
          if (typeof window.loadEvents === 'function') window.loadEvents();
        }, 250);
        break;
      case 'apply_l1_rewrite':
        applyL1Rewrite(d.prompt || d.new_prompt);
        break;
      case 'skip_prologue':
        postResult(d);
        clearHighlight();
        toast('프롤로그를 건너뛰었습니다.');
        break;
      default:
        log('unknown message action', d.action);
    }
  }

  function showPrompt() {
    if (document.getElementById('_meta13_prologue_prompt')) return;
    const p = document.createElement('div');
    p.id = '_meta13_prologue_prompt';
    p.className = 'meta13-prologue-prompt';
    p.innerHTML = [
      '<div class="m13p-kicker">Meta-13 Debugger</div>',
      '<div class="m13p-title">게임형 프롤로그를 시작할까요?</div>',
      '<div class="m13p-desc">FREEZE 타이밍에서 화면이 멈추고, L1/L2/L3 수술 위치를 직접 클릭해볼 수 있습니다.</div>',
      '<div class="m13p-actions">',
      '<button class="m13p-start" type="button">▶ 시작</button>',
      '<button class="m13p-skip" type="button">건너뛰기</button>',
      '</div>'
    ].join('');
    p.querySelector('.m13p-start').onclick = function () { removeEl(p); openPrologue(); };
    p.querySelector('.m13p-skip').onclick = function () {
      removeEl(p);
      const payload = { source: 'meta13_prologue', action: 'skip_prologue', experiment_count: 0 };
      postResult(payload);
    };
    document.body.appendChild(p);
  }

  function openPrologue() {
    const w = 920;
    const h = 660;
    const left = Math.max(0, Math.floor((screen.width - w) / 2));
    const top = Math.max(0, Math.floor((screen.height - h) / 2));
    const url = state.config.openUrl;
    state.pwin = window.open(
      url,
      'meta13_prologue',
      'width=' + w + ',height=' + h + ',left=' + left + ',top=' + top + ',resizable=yes,scrollbars=yes,toolbar=no,menubar=no,location=no'
    );
    if (!state.pwin) toast('팝업이 차단됐습니다. 브라우저 팝업 허용 후 다시 시도하세요.');
  }

  function addReopenButton() {
    if (document.getElementById('_meta13_prologue_reopen')) return;
    const b = document.createElement('button');
    b.id = '_meta13_prologue_reopen';
    b.className = 'meta13-prologue-reopen';
    b.type = 'button';
    b.title = '인터랙티브 프롤로그 다시 보기';
    b.textContent = 'prologue';
    b.onclick = openPrologue;
    document.body.appendChild(b);
  }

  function checkFirstRun() {
    safeFetch(state.config.checkUrl)
      .then(function (r) { return r && r.ok ? r.json() : null; })
      .then(function (data) {
        if (data && data.ok && !data.seen) showPrompt();
      });
  }

  function connectSse() {
    if (!state.config.enableSse || !window.EventSource) return;
    try {
      state.sse = new EventSource(state.config.eventsUrl);
      state.sse.addEventListener('freeze', function (ev) {
        let frame = null;
        try { frame = JSON.parse(ev.data); } catch (e) { frame = null; }
        if (!frame) return;
        highlight(frame.target || 'prompt-panel', frame.title || 'AUTO_FREEZE', frame.message || 'Freeze frame reached.', 'warn');
      });
      state.sse.onerror = function () { log('sse error'); };
    } catch (e) {
      log('sse init failed', e);
    }
  }

  function applyL1Rewrite(prompt) {
    if (!prompt) {
      toast('L1 rewrite prompt가 비어 있습니다.');
      return;
    }
    safeFetch('/api/debug/l1_rewrite', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({new_prompt: prompt})
    })
      .then(function (r) { return r && r.ok ? r.json() : null; })
      .then(function (data) {
        if (data && data.ok) {
          toast('L1 rewrite queued ✓');
          highlight(
            'result-panel',
            'L1 rewrite queued',
            '다음 generate에서 "' + prompt.slice(0, 60) + '..." 가 적용됩니다.',
            'success'
          );
          log('applyL1Rewrite success', data);
        } else {
          toast('L1 rewrite 실패: ' + JSON.stringify(data));
          log('applyL1Rewrite fail', data);
        }
      })
      .catch(function (err) {
        toast('L1 rewrite API 오류: ' + err);
        log('applyL1Rewrite error', err);
      });
  }

  function resetSeen() {
    return safeFetch(state.config.resetUrl, { method: 'POST' }).then(function () {
      toast('프롤로그 세션을 초기화했습니다.');
    });
  }

  function init(config) {
    if (state.initialized) return;
    state.initialized = true;
    state.config = { ...DEFAULT_CONFIG, ...(config || {}) };
    ensureDefaultTargets();
    window.addEventListener('message', handleMessage);
    addReopenButton();
    if (state.config.autoCheck) checkFirstRun();
    connectSse();
    log('initialized', state.config);
  }

  window.Meta13PrologueHost = {
    init,
    open: openPrologue,
    highlight,
    previewValue,
    clearHighlight,
    clearAllPreviews,
    resetSeen,
    _state: state
  };
})();
