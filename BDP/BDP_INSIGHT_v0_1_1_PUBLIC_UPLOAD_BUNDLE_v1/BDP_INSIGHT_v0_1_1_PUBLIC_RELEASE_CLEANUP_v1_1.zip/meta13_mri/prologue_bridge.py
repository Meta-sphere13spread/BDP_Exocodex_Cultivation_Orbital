"""
prologue_bridge.py — v0.2 Host Highlight Bridge
=================================================
기존 Meta-13 HTML dashboard에 인터랙티브 프롤로그를 overlay 방식으로 붙이는 Flask Blueprint.

설계 원칙
---------
- 기존 대시보드 전체 재작성 금지.
- 프롤로그는 별도 창(`/prologue/open`)으로 실행.
- 별도 창은 `postMessage`로 부모 대시보드의 특정 위치 highlight/preview를 요청.
- 부모 대시보드는 `dashboard_prologue_host.js/css`가 처리.
- 사용자 prompt/model/log/tensor/snapshot/result 원문은 저장하지 않음.
- L1/L2/L3/L4 실제 엔진 연결은 하지 않고, demo/simulated 흐름과 UI bridge만 제공.

기존 대시보드에 붙이는 최소 코드
---------------------------------
    from prologue_bridge import prologue_bp, inject_prologue_js
    app.register_blueprint(prologue_bp)

    # HTML </body> 직전:
    {{ inject_prologue_js(auto_check=True) | safe }}

DEBUG
-----
- 모든 route는 debug.failure_reason 필드를 포함.
- 문제가 나면 기존 대시보드에서 `inject_prologue_js(...)` 한 줄만 제거하면 롤백 가능.
"""
from __future__ import annotations

import json
import logging
import time
from pathlib import Path
from typing import Any, Dict, Iterable

from flask import (
    Blueprint,
    Response,
    jsonify,
    request,
    send_from_directory,
    session,
    stream_with_context,
)

logger = logging.getLogger("meta13.prologue_bridge")

_HERE = Path(__file__).resolve().parent
_ASSETS = _HERE / "prologue_assets"
PROLOGUE_HTML = _HERE / "prologue_assets" / "meta13_prologue.html"

prologue_bp = Blueprint("prologue", __name__, url_prefix="/prologue")

# Dashboard elements that the host bridge can highlight.
# 실제 대시보드에 해당 data-prologue-id가 없더라도 JS가 #debug-route 등 흔한 ID를 자동 보정한다.
PROLOGUE_TARGETS: Dict[str, Dict[str, str]] = {
    "prompt-panel": {
        "label": "Prompt Panel",
        "fallback": "#prompt-panel, [data-panel='prompt'], textarea, pre",
        "note": "L1 freeze에서 프롬프트 텍스트가 바뀌는 위치",
    },
    "token-row": {
        "label": "Token Row",
        "fallback": "#token-row, [data-panel='tokens'], [data-metric='tokens']",
        "note": "L2 freeze에서 weighted token을 보여주는 위치",
    },
    "metric-route": {
        "label": "Route",
        "fallback": "#debug-route, [data-metric='route']",
        "note": "T3/T2/BASE 등 route 결과 표시 위치",
    },
    "metric-drift": {
        "label": "Drift",
        "fallback": "#debug-drift, [data-metric='drift']",
        "note": "L3 perturbation 후 drift 변화 표시 위치",
    },
    "metric-tau": {
        "label": "Tau",
        "fallback": "#debug-tau, [data-metric='tau']",
        "note": "tau phase indicator 표시 위치",
    },
    "metric-deff": {
        "label": "D_eff",
        "fallback": "#debug-deff, [data-metric='deff'], [data-metric='d_eff']",
        "note": "T9/T10 teaser로 이어지는 유효 차원 지표",
    },
    "surgery-l1": {
        "label": "L1 Card",
        "fallback": "#surgery-l1, [data-surgery-level='L1']",
        "note": "L1 edit_token 선택 카드",
    },
    "surgery-l2": {
        "label": "L2 Card",
        "fallback": "#surgery-l2, [data-surgery-level='L2']",
        "note": "L2 HodgeConverter 선택 카드",
    },
    "surgery-l3": {
        "label": "L3 Card",
        "fallback": "#surgery-l3, [data-surgery-level='L3']",
        "note": "L3 embed_perturb 선택 카드",
    },
    "surgery-l4": {
        "label": "L4 Card",
        "fallback": "#surgery-l4, [data-surgery-level='L4']",
        "note": "L4 Coming Soon / T-Engine teaser 카드",
    },
    "result-panel": {
        "label": "Result Panel",
        "fallback": "#result-panel, [data-panel='result'], [data-prologue-role='result']",
        "note": "Before/After 비교 결과 표시 위치",
    },
}

_ALLOWED_RESULT_KEYS = {
    "action",
    "experiment_count",
    "current_L",
    "l3_mode",
    "l3_scale",
    "has_result",
    "last_result_summary",
    "selected_token_summary",
}


def _json(data: Dict[str, Any], status: int = 200):
    return jsonify(data), status


def _safe_int(value: Any, default: int = 0) -> int:
    try:
        return int(value)
    except Exception:
        return default


def _safe_float(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except Exception:
        return default


def _summarize_last_result(value: Any) -> Dict[str, Any] | None:
    """프롤로그 demo 결과 중 UI 비교에 필요한 낮은 민감도 값만 보관."""
    if not isinstance(value, dict):
        return None
    allowed = {"route", "drift", "answer", "latency", "basisT2", "deff", "changed"}
    out = {k: value.get(k) for k in allowed if k in value}
    return out or None


def _summarize_token(value: Any) -> Dict[str, Any] | None:
    if not isinstance(value, dict):
        return None
    return {
        "pos": _safe_int(value.get("pos"), -1),
        "token": str(value.get("token", ""))[:32],
        "weight": _safe_float(value.get("weight"), 0.0),
    }


@prologue_bp.route("/check", methods=["GET"])
def check():
    seen = bool(session.get("prologue_seen", False))
    result = session.get("prologue_result", None)
    logger.debug("[prologue_bridge:v0.2] check seen=%s", seen)
    return jsonify({"ok": True, "seen": seen, "result": result, "debug": {"failure_reason": ""}})


@prologue_bp.route("/open", methods=["GET"])
def open_prologue():
    if not PROLOGUE_HTML.exists():
        logger.error("[prologue_bridge:v0.2] HTML not found: %s", PROLOGUE_HTML)
        return _json({"ok": False, "error": "prologue HTML not found", "debug": {"failure_reason": "html_missing"}}, 404)
    logger.info("[prologue_bridge:v0.2] serving prologue HTML")
    return send_from_directory(str(_ASSETS), "meta13_prologue.html")


@prologue_bp.route("/assets/<path:filename>", methods=["GET"])
def assets(filename: str):
    if ".." in filename or filename.startswith("/"):
        return _json({"ok": False, "error": "bad asset path", "debug": {"failure_reason": "bad_asset_path"}}, 400)
    return send_from_directory(str(_ASSETS), filename)


@prologue_bp.route("/targets", methods=["GET"])
def targets():
    return jsonify({"ok": True, "targets": PROLOGUE_TARGETS, "debug": {"failure_reason": ""}})


@prologue_bp.route("/result", methods=["POST"])
def receive_result():
    try:
        data: Dict[str, Any] = request.get_json(force=True) or {}
    except Exception as exc:
        return _json({"ok": False, "error": str(exc), "debug": {"failure_reason": "bad_json"}}, 400)

    action = str(data.get("action", ""))
    if action not in {"apply_prologue_result", "skip_prologue", "clear_highlight"}:
        # highlight/preview 류는 client-only 메시지라 서버에 저장할 필요가 없다.
        return jsonify({"ok": True, "ignored": True, "debug": {"failure_reason": "client_only_action"}})

    last_summary = _summarize_last_result(data.get("last_result"))
    token_summary = _summarize_token(data.get("selected_token"))

    safe_record: Dict[str, Any] = {
        "action": action,
        "experiment_count": _safe_int(data.get("experiment_count"), 0),
        "current_L": _safe_int(data.get("current_L"), 1),
        "l3_mode": str(data.get("l3_mode", "suppress"))[:32],
        "l3_scale": _safe_float(data.get("l3_scale"), 0.3),
        "has_result": last_summary is not None,
        "last_result_summary": last_summary,
        "selected_token_summary": token_summary,
        "ts": time.time(),
    }
    safe_record = {k: v for k, v in safe_record.items() if k in _ALLOWED_RESULT_KEYS or k == "ts"}

    session["prologue_seen"] = True
    session["prologue_result"] = safe_record

    logger.info(
        "[prologue_bridge:v0.2] result action=%s experiments=%s current_L=%s",
        action,
        safe_record.get("experiment_count"),
        safe_record.get("current_L"),
    )
    return jsonify({"ok": True, "saved": safe_record, "debug": {"failure_reason": ""}})


@prologue_bp.route("/reset", methods=["POST"])
def reset():
    session.pop("prologue_seen", None)
    session.pop("prologue_result", None)
    logger.info("[prologue_bridge:v0.2] prologue session reset")
    return jsonify({"ok": True, "debug": {"failure_reason": ""}})


@prologue_bp.route("/events", methods=["GET"])
def events():
    """
    Demo SSE endpoint. 실제 FREEZE 엔진 연결 전까지 UI 테스트용.
    기본 사용 흐름은 postMessage bridge이고, 이 route는 선택 사항이다.
    """

    def _event_stream() -> Iterable[str]:
        payload = {
            "kind": "demo_freeze",
            "freeze_point": "L1_BEFORE_TOKENIZE",
            "target": "prompt-panel",
            "title": "AUTO_FREEZE",
            "message": "Demo freeze frame reached. L1 edit_token을 체험할 수 있습니다.",
            "ts": time.time(),
        }
        yield "event: freeze\n"
        yield "data: " + json.dumps(payload, ensure_ascii=False) + "\n\n"
        yield ": meta13-prologue-demo-end\n\n"

    headers = {
        "Cache-Control": "no-cache, no-store, must-revalidate",
        "X-Accel-Buffering": "no",
    }
    return Response(stream_with_context(_event_stream()), mimetype="text/event-stream", headers=headers)


def inject_prologue_js(auto_check: bool = True, enable_sse: bool = False) -> str:
    """
    기존 dashboard HTML의 </body> 직전에 삽입하는 asset loader.

    - `dashboard_prologue_host.css`: parent dashboard highlight/preview 스타일
    - `dashboard_prologue_host.js`: popup bridge, highlight API, preview badge, prompt card
    - init config: autoCheck, enableSse
    """
    cfg = {
        "autoCheck": bool(auto_check),
        "enableSse": bool(enable_sse),
        "checkUrl": "/prologue/check",
        "openUrl": "/prologue/open",
        "resultUrl": "/api/prologue/result",
        "resetUrl": "/prologue/reset",
        "eventsUrl": "/prologue/events",
        "targetsUrl": "/prologue/targets",
    }
    cfg_json = json.dumps(cfg, ensure_ascii=False)
    return f"""
<!-- Meta-13 Prologue Host Bridge v0.2 -->
<link rel="stylesheet" href="/prologue/assets/dashboard_prologue_host.css">
<script src="/prologue/assets/dashboard_prologue_host.js"></script>
<script>
(function() {{
  function boot() {{
    if (window.Meta13PrologueHost && typeof window.Meta13PrologueHost.init === 'function') {{
      window.Meta13PrologueHost.init({cfg_json});
    }} else {{
      console.warn('[Meta13PrologueHost] host script missing');
    }}
  }}
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
}})();
</script>
"""


# v0.1 호환 이름
inject_prologue_assets = inject_prologue_js
