from __future__ import annotations

"""Public-safe internal metric summaries for the dashboard.

This module deliberately exposes only metrics that are already common in public
interpretability/debugging practice: activation/residual summaries, attention
focus/entropy, logit gap/entropy, gradient attribution availability, and
layer-token-dimension coverage.

It does NOT expose Hodge/SMAP 12_6 candidate ranking, score_components,
weights_json, selector bias, raw hidden vectors, logits, tensors, or gradients.
"""

from pathlib import Path
from typing import Any, Dict, Iterable, List
from .entitlement import resolve_entitlement
from .mri_metric_schema import METRIC_REGISTRY, get_label, locked_card
import json
import math


def _read_json(path: Path, default: Any = None) -> Any:
    try:
        if path.exists():
            return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        pass
    return default


def _read_events(run_root: Path, limit: int = 80) -> List[Dict[str, Any]]:
    path = run_root / "dynamic_debug" / "events.jsonl"
    rows: List[Dict[str, Any]] = []
    try:
        if path.exists():
            for line in path.read_text(encoding="utf-8", errors="replace").splitlines()[-limit:]:
                if not line.strip():
                    continue
                try:
                    rows.append(json.loads(line))
                except Exception:
                    pass
    except Exception:
        pass
    return rows


def _bucket(value: Any, *, low: float = 0.25, high: float = 0.66, unknown: str = "unknown") -> str:
    try:
        x = float(value)
        if math.isnan(x) or math.isinf(x):
            return unknown
        if x < low:
            return "low"
        if x < high:
            return "mid"
        return "high"
    except Exception:
        return unknown


def _norm_percent(value: Any, *, scale: float = 1.0) -> int | None:
    try:
        x = abs(float(value)) / max(scale, 1e-9)
        return int(max(0, min(99, round(100.0 * x / (1.0 + x)))))
    except Exception:
        return None


def _pick_nested(payloads: Iterable[Dict[str, Any]], names: Iterable[str]) -> Any:
    wanted = [str(n).lower() for n in names]
    def walk(obj: Any) -> Any:
        if isinstance(obj, dict):
            for k, v in obj.items():
                lk = str(k).lower()
                if lk in wanted:
                    return v
            for v in obj.values():
                got = walk(v)
                if got is not None:
                    return got
        elif isinstance(obj, list):
            for v in obj[:40]:
                got = walk(v)
                if got is not None:
                    return got
        return None
    for p in payloads:
        got = walk(p)
        if got is not None:
            return got
    return None


def _capture_coverage(run_root: Path, cap_root: Path, state: Dict[str, Any], events: List[Dict[str, Any]]) -> Dict[str, Any]:
    status = state.get("status") if isinstance(state.get("status"), dict) else {}
    extra = state.get("extra") if isinstance(state.get("extra"), dict) else {}
    cap_index = cap_root / "index.jsonl"
    has_capture_index = cap_index.exists()
    event_text = json.dumps(events[-20:], ensure_ascii=False).lower() if events else ""
    return {
        "capture_index_exists": has_capture_index,
        "hidden_or_activation_capture": bool(status.get("capture_hidden") or extra.get("capture_hidden") or "hidden" in event_text or "activation" in event_text),
        "attention_capture": bool(status.get("capture_attn") or extra.get("capture_attn") or "attn" in event_text or "attention" in event_text),
        "lens_or_logit_capture": bool(status.get("capture_lens") or extra.get("capture_lens") or "logit" in event_text or "lens" in event_text),
        "gradient_capture": bool(extra.get("gradient_capture") or "grad" in event_text),
        "public_safe": True,
    }


def build_public_internal_metrics(run_root: Path, cap_root: Path, state: Dict[str, Any] | None = None) -> Dict[str, Any]:
    """Build a public-safe set of internal-view metrics.

    The returned values are intentionally coarse/bucketed.  They are suitable
    for a paid-ready dashboard where the UI may show full feature cards while
    free mode remains locked/preview and raw diagnostics stay private.
    """
    state = state or _read_json(run_root / "dynamic_debug" / "current_state.json", {}) or {}
    ent = resolve_entitlement()
    irsdce_visible = bool(ent.paid_enabled)
    events = _read_events(run_root)
    payloads: List[Dict[str, Any]] = [state] + events[-50:]

    extra = state.get("extra") if isinstance(state.get("extra"), dict) else {}
    status = state.get("status") if isinstance(state.get("status"), dict) else {}

    # Publicly common axes.  Names avoid raw "hidden/logits/tensor" payloads.
    attn_entropy = _pick_nested(payloads, ["attention_entropy", "attn_entropy", "attn_ent"])
    entropy = _pick_nested(payloads, ["entropy", "spectral_entropy", "output_entropy"])
    logit_gap = _pick_nested(payloads, ["logit_gap", "logit_margin", "topk_margin", "margin"])
    activation_norm = _pick_nested(payloads, ["activation_norm", "residual_norm", "stream_norm", "act_norm"])
    mlp_norm = _pick_nested(payloads, ["mlp_norm", "mlp_activity", "ffn_norm"])
    grad_norm = _pick_nested(payloads, ["gradient_norm", "grad_norm", "attribution_norm"])
    eff_rank = _pick_nested(payloads, ["effective_rank", "eff_rank", "d_eff", "deff"])
    drift = _pick_nested(payloads, ["drift", "phase_drift", "route_drift"])

    prompt_len = extra.get("prompt_len") or _pick_nested(payloads, ["prompt_len"])
    latency = extra.get("latency_sec") or _pick_nested(payloads, ["latency_sec", "latency"])
    route = extra.get("route") or state.get("route") or status.get("route")

    coverage = _capture_coverage(run_root, cap_root, state, events)

    # If raw values are absent, still expose capability/bucket state rather than
    # fabricating precise diagnostics.
    activation_percent = _norm_percent(activation_norm, scale=8.0)
    attention_bucket = _bucket(1.0 - float(attn_entropy) if isinstance(attn_entropy, (int, float)) else attn_entropy) if attn_entropy is not None else ("available" if coverage["attention_capture"] else "unknown")
    logit_bucket = _bucket(logit_gap, low=0.1, high=1.0) if logit_gap is not None else ("available" if coverage["lens_or_logit_capture"] else "unknown")
    grad_bucket = _bucket(grad_norm, low=0.05, high=0.5) if grad_norm is not None else ("available" if coverage["gradient_capture"] else "locked_or_not_captured")

    axes = [
        {
            "axis": "activation_residual_activity",
            "public_name": "Activation / Residual Activity",
            "public_bucket": _bucket(activation_norm, low=1.5, high=8.0) if activation_norm is not None else ("available" if coverage["hidden_or_activation_capture"] else "unknown"),
            "public_percent": activation_percent,
            "unit": "bucketed_norm",
            "exposes_raw_vector": False,
            "notes": "Common public internal view; raw vectors/tensors are not returned.",
        },
        {
            "axis": "attention_focus",
            "public_name": "Attention Focus",
            "public_bucket": attention_bucket,
            "unit": "bucketed_attention_entropy",
            "exposes_raw_matrix": False,
            "notes": "Attention heatmaps are public/common; this endpoint returns only coarse focus.",
        },
        {
            "axis": "logit_gap",
            "public_name": "Logit Gap / Output Confidence",
            "public_bucket": logit_bucket,
            "unit": "bucketed_margin",
            "exposes_raw_logits": False,
            "notes": "Shows distribution confidence without returning logits.",
        },
        {
            "axis": "gradient_attribution_signal",
            "public_name": "Gradient Attribution Signal",
            "public_bucket": grad_bucket,
            "unit": "availability_or_bucketed_norm",
            "exposes_raw_gradients": False,
            "notes": "Gradient access is a public interpretability primitive; raw gradients stay hidden.",
        },
        {
            "axis": "layer_token_dim_coverage",
            "public_name": "Layer × Token × Dimension Coverage",
            "public_bucket": "available" if (coverage["hidden_or_activation_capture"] or coverage["attention_capture"]) else "metadata_only",
            "unit": "coverage",
            "exposes_raw_tensor": False,
            "notes": "Public summary of whether the runtime can index layer/token/dim axes.",
        },
        {
            "axis": "mlp_ffn_activity",
            "public_name": "MLP / FFN Activity",
            "public_bucket": _bucket(mlp_norm, low=1.5, high=8.0) if mlp_norm is not None else "unknown",
            "unit": "bucketed_norm",
            "exposes_raw_tensor": False,
            "notes": "Public summary only; no per-neuron score table.",
        },
        {
            "axis": "effective_rank_geometry",
            "public_name": "Effective Rank / Geometry",
            "public_bucket": _bucket(eff_rank, low=2.0, high=8.0) if eff_rank is not None else "unknown",
            "unit": "bucketed_rank",
            "exposes_raw_spectrum": False,
            "notes": "Rank-like geometry summary; raw spectrum is not returned.",
        },
    ]

    for ax in axes:
        metric_id = str(ax.get("axis") or "")
        bucket = str(ax.get("public_bucket") or "unknown")
        ax["label"] = get_label(metric_id, bucket)
        if metric_id in METRIC_REGISTRY:
            ax["registry_public_name"] = METRIC_REGISTRY[metric_id].get("public_name")

    locked_axes = []
    if not irsdce_visible:
        locked_axes.append(locked_card("irsdce_geometry"))

    return {
        "ok": True,
        "public_safe": True,
        "source": "state_events_capture_summary",
        "route": route or "—",
        "tier": status.get("tier") or state.get("tier") or "free",
        "paid_enabled": bool(status.get("paid_enabled") or state.get("paid_enabled")),
        "capture_coverage": coverage,
        "runtime_public": {
            "prompt_len_bucket": _bucket(prompt_len, low=80, high=400) if prompt_len is not None else "unknown",
            "latency_bucket": _bucket(latency, low=0.5, high=3.0) if latency is not None else "unknown",
            "drift_bucket": _bucket(drift, low=0.2, high=0.65) if drift is not None else "unknown",
        },
        "axes": axes,
        "redaction": {
            "shown": [
                "activation/residual activity bucket",
                "attention focus bucket",
                "logit gap bucket",
                "gradient attribution signal bucket",
                "layer-token-dimension coverage",
                "effective-rank geometry bucket",
            ] + (["IRSDCE geometry axis"] if irsdce_visible else []),
            "hidden": [
                "raw hidden vectors",
                "raw logits",
                "raw tensors",
                "raw gradients",
                "candidate ranking formula",
                "12_6 selector score_components",
                "weights_json",
            ],
            "locked": locked_axes,
        },
    }


def build_public_internal_graph(metrics: Dict[str, Any]) -> Dict[str, Any]:
    """Represent public internal axes as a safe graph."""
    axes = metrics.get("axes") or []
    nodes = [{
        "id": "runtime",
        "label": "runtime",
        "role": "source",
        "focus_bucket": "mid",
        "public_safe": True,
    }]
    edges = []
    for i, ax in enumerate(axes):
        aid = str(ax.get("axis") or f"axis_{i}")
        bucket = str(ax.get("public_bucket") or "unknown")
        nodes.append({
            "id": aid,
            "label": ax.get("public_name") or aid,
            "role": "public_internal_axis",
            "focus_bucket": bucket,
            "public_safe": True,
        })
        edges.append({
            "src": "runtime",
            "dst": aid,
            "kind": "public_internal_summary",
            "strength_bucket": "high" if bucket in {"high", "available"} else "mid" if bucket in {"mid"} else "low",
            "public_safe": True,
        })
    return {
        "ok": True,
        "public_safe": True,
        "nodes": nodes,
        "edges": edges,
        "note": "Graph exposes public/bucketed internal axes only; raw tensors, logits, gradients and 12_6 selector internals are excluded.",
    }
