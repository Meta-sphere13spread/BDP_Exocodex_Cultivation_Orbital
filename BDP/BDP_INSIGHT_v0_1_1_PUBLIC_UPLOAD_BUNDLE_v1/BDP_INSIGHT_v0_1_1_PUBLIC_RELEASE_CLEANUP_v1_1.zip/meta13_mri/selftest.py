from __future__ import annotations

import json
import tempfile
from pathlib import Path

from .capture_basic import BasicCaptureWriter
from .command_queue import CommandQueue
from .debug_control import DebugController
from .entitlement import RuntimeEntitlement
from .easter_egg import L4EasterEgg
from .ephemeral_blob import EphemeralBlob
from .ephemeral_lease import EphemeralFunctionLease, LeaseConsumed, LeaseMaterialAccessBlocked


class DummyEngine:
    def __init__(self):
        self._pending_prompt_rewrite = ""
        self._debug_abort_requested = False
        self._hard_abort_persistent = False

    def debug_snapshot(self):
        return {"status": {"ok": True, "dummy": True}}


def _run_ephemeral_lease_selftest() -> dict:
    raw = b"not-a-real-so-for-loader-construction-only"
    blob = EphemeralBlob(raw, op="deep.obda_phi")
    lease = EphemeralFunctionLease(op="deep.obda_phi", _blob=blob)

    bytes_blocked = False
    try:
        bytes(lease)
    except LeaseMaterialAccessBlocked:
        bytes_blocked = True

    save_blocked = False
    try:
        lease.save("/tmp/should_not_exist.so")
    except LeaseMaterialAccessBlocked:
        save_blocked = True

    loader = lease.consume()
    # Do not enter the loader context: the bytes are intentionally not a real .so.
    loader._clear()

    reuse_blocked = False
    try:
        lease.consume()
    except LeaseConsumed:
        reuse_blocked = True

    return {
        "bytes_blocked": bytes_blocked,
        "save_blocked": save_blocked,
        "single_use_blocked": reuse_blocked,
        "lease_consumed": lease.consumed,
        "ok": bytes_blocked and save_blocked and reuse_blocked and lease.consumed,
    }


def run_selftest() -> dict:
    with tempfile.TemporaryDirectory() as td:
        root = Path(td)
        sid = BasicCaptureWriter(outdir=str(root / "cap")).write_run(
            "hello", {"answer": "world", "latency_sec": 0.1}, model_id="dummy"
        )
        q = CommandQueue(root / "run")
        q.push_command("rewrite_prompt", new_prompt="patched")

        # Release boundary v1:
        # - L2 manual token swap/graft was removed from the product surface.
        # - L3 embedding surgery is free/local.
        # - Paid L2 public surface is HodgeConverter auto only; hidden fallback may use server Hodge output internally.
        #
        # The free-policy selftest must therefore assert all three boundaries:
        #   1) free L1 rewrite still applies,
        #   2) free L3 is accepted locally,
        #   3) paid L2 Hodge is blocked when entitlement is forced to free.
        q.push_command("embed_perturb", layer=1, position=0, magnitude=0.1, mode="suppress")
        q.push_command("hodge_auto", new_word="patched", selector="auto", target_regex="hello")
        q.push_command("token_swap", old_word="2", new_word="9")

        eng = DummyEngine()
        # This is a *free policy* selftest.
        # It must remain deterministic even when the runner is launched with
        # --paid-key or META13_PAID_KEY is present. Forcing free entitlement here
        # prevents paid runtime configuration from changing release-boundary tests.
        free_entitlement = RuntimeEntitlement(
            tier="free",
            paid_enabled=False,
            paid_mode="free",
            key_source="selftest_forced_free",
            client_version="0.1.13.4-release-boundary",
        )
        c = DebugController(
            str(root / "run"),
            skip_stale_commands=False,
            entitlement=free_entitlement,
        )
        snap = c.poll_and_checkpoint(eng, "before_generate")
        events = (root / "run/dynamic_debug/events.jsonl").read_text(encoding="utf-8").splitlines()

        has_blocked_paid_l2 = any(
            ("blocked_command" in e and "hodge_auto" in e)
            for e in events
        )
        has_free_l3_accept = any(
            ("free_l3_command_accepted" in e and "embed_perturb" in e)
            for e in events
        )
        has_removed_manual_l2 = any(
            ("removed_command" in e and "token_swap" in e)
            for e in events
        )

        l4 = L4EasterEgg().inject_graft()
        lease_test = _run_ephemeral_lease_selftest()
        ok = bool(
            sid
            and eng._pending_prompt_rewrite == "patched"
            and has_blocked_paid_l2
            and has_free_l3_accept
            and has_removed_manual_l2
            and l4["status"] == "preview_only"
            and lease_test["ok"]
        )
        return {
            "ok": ok,
            "session_id": sid,
            "events": len(events),
            "snapshot_ok": bool(snap),
            "free_policy_forced": True,
            "selftest_tier": "free",
            "release_boundary": {
                "paid_l2_hodge_blocked_in_free": has_blocked_paid_l2,
                "free_l3_accepted": has_free_l3_accept,
                "manual_l2_removed": has_removed_manual_l2,
            },
            "ephemeral_lease": lease_test,
            "failure_reason": "" if ok else "release-boundary selftest invariant failed",
        }


def main():
    print(json.dumps(run_selftest(), ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
