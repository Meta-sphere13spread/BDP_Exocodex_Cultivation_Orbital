from __future__ import annotations

"""Static debugger inspection helpers.

This module is intentionally read-only and public-safe by default.  It extracts
model/tokenizer/generation/module compatibility metadata when a live session is
available, and otherwise falls back to runtime_status/current_state/capture
files so the standalone dashboard can still show useful diagnostics.
"""

import json
from pathlib import Path
from typing import Any, Dict, List
from .entitlement import resolve_entitlement
from .mri_metric_schema import locked_card


def _read_json(path: Path, default: Any = None) -> Any:
    try:
        if path.exists():
            return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        pass
    return default


def _safe_str(value: Any, limit: int = 240) -> str | None:
    if value is None:
        return None
    return str(value)[:limit]


def _obj_name(obj: Any) -> str | None:
    if obj is None:
        return None
    try:
        return obj.__class__.__name__
    except Exception:
        return type(obj).__name__


def _config_dict(cfg: Any) -> Dict[str, Any]:
    if cfg is None:
        return {}
    if hasattr(cfg, "to_dict"):
        try:
            return dict(cfg.to_dict())
        except Exception:
            pass
    out = {}
    for k in ("model_type", "vocab_size", "hidden_size", "num_hidden_layers", "num_attention_heads", "intermediate_size", "torch_dtype", "architectures", "max_position_embeddings"):
        try:
            v = getattr(cfg, k, None)
            if v is not None:
                out[k] = str(v) if "dtype" in k else v
        except Exception:
            pass
    return out


def _generation_config_dict(model: Any) -> Dict[str, Any]:
    gc = getattr(model, "generation_config", None)
    if gc is None:
        return {}
    if hasattr(gc, "to_dict"):
        try:
            d = dict(gc.to_dict())
            return {k: d.get(k) for k in ("max_new_tokens", "do_sample", "temperature", "top_p", "top_k", "eos_token_id", "pad_token_id", "bos_token_id") if k in d}
        except Exception:
            pass
    return {}


def _tokenizer_info(tok: Any) -> Dict[str, Any]:
    if tok is None:
        return {"available": False}
    info = {"available": True, "class": _obj_name(tok)}
    for name in ("vocab_size", "model_max_length", "is_fast", "bos_token", "eos_token", "pad_token", "unk_token", "bos_token_id", "eos_token_id", "pad_token_id", "unk_token_id"):
        try:
            v = getattr(tok, name, None)
            if v is not None:
                info[name] = v
        except Exception:
            pass
    try:
        info["chat_template"] = bool(getattr(tok, "chat_template", None))
    except Exception:
        pass
    try:
        info["added_tokens_count"] = len(getattr(tok, "added_tokens_decoder", {}) or {})
    except Exception:
        pass
    return info


def _module_summary(model: Any) -> Dict[str, Any]:
    if model is None:
        return {"available": False}
    info: Dict[str, Any] = {"available": True, "class": _obj_name(model)}
    try:
        emb = model.get_input_embeddings()
        info["input_embeddings"] = _obj_name(emb)
        info["l3_embedding_hook_possible"] = emb is not None
    except Exception as exc:
        info["input_embeddings"] = None
        info["l3_embedding_hook_possible"] = False
        info["embedding_error"] = _safe_str(exc)
    try:
        names = [name for name, _ in model.named_modules()]
        info["module_count"] = len(names)
        layer_like = [n for n in names if any(part in n.lower() for part in ("layer", "block", "decoder.layers", "model.layers"))]
        info["layer_like_count"] = len(layer_like)
        info["sample_modules"] = names[:40]
    except Exception as exc:
        info["module_error"] = _safe_str(exc)
    try:
        p = next(model.parameters())
        info["device"] = str(getattr(p, "device", None))
        info["dtype"] = str(getattr(p, "dtype", None))
    except Exception:
        pass
    return info


def inspect_static(*, run_root: Path, cap_root: Path, session_obj: Any = None) -> Dict[str, Any]:
    dyn = run_root / "dynamic_debug"
    runtime_status = _read_json(dyn / "runtime_status.json", {}) or {}
    current_state = _read_json(dyn / "current_state.json", {}) or {}
    status = runtime_status.get("status") or current_state.get("status") or {}
    core = None
    if session_obj is not None:
        core = getattr(session_obj, "core", None) or getattr(session_obj, "_meta13_core", None) or session_obj
    model = getattr(core, "model", None) if core is not None else None
    tokenizer = getattr(core, "tokenizer", None) if core is not None else None

    cfg = _config_dict(getattr(model, "config", None)) if model is not None else {}
    if not cfg:
        # runtime status generally contains model_id only; keep this path useful.
        cfg = {"model_id": status.get("model_id") or current_state.get("model_id")}

    capture_index = cap_root / "index.jsonl"
    capture_latest = None
    if capture_index.exists():
        try:
            lines = [ln for ln in capture_index.read_text(encoding="utf-8", errors="replace").splitlines() if ln.strip()]
            if lines:
                capture_latest = json.loads(lines[-1])
        except Exception:
            capture_latest = None

    paid_enabled = bool(status.get("paid_enabled") or current_state.get("paid_enabled"))
    paid_mode = status.get("paid_mode") or current_state.get("paid_mode") or "free"

    return {
        "ok": True,
        "public_safe": True,
        "source": "live_session" if model is not None or tokenizer is not None else "files_only",
        "manifest": {
            "model_id": status.get("model_id") or cfg.get("model_id") or "model",
            "tier": status.get("tier") or current_state.get("tier") or ("paid" if paid_enabled else "free"),
            "paid_enabled": paid_enabled,
            "paid_mode": paid_mode,
            "run_root": str(run_root.resolve()),
            "capture_root": str(cap_root.resolve()),
            "runtime_status_exists": (dyn / "runtime_status.json").exists(),
            "state_exists": (dyn / "current_state.json").exists(),
            "events_exists": (dyn / "events.jsonl").exists(),
        },
        "model_config": cfg,
        "tokenizer": _tokenizer_info(tokenizer),
        "generation_config": _generation_config_dict(model),
        "module_tree": _module_summary(model),
        "paid_compatibility": {
            "l1_prompt_rewrite": True,
            "l2_token_surgery": bool(paid_enabled),
            "l3_embedding_hook": bool(paid_enabled and (_module_summary(model).get("l3_embedding_hook_possible", True) if model is not None else True)),
            "deep_insight": bool(paid_enabled),
            "execution_note": "locked/preview in free; runtime gated in paid mode",
        },
        "capture_latest": capture_latest,
        "current_state": current_state,
    }


def simple_token_focus_from_state(state: Dict[str, Any]) -> Dict[str, Any]:
    extra = state.get("extra") or {}
    text = extra.get("answer_preview") or extra.get("partial_answer_preview") or extra.get("prompt_preview") or ""
    tokens = str(text).replace("\n", " \n ").split()
    rows: List[Dict[str, Any]] = []
    for i, tok in enumerate(tokens[:80]):
        role = "number" if any(ch.isdigit() for ch in tok) else "operator" if tok in {"+", "-", "*", "/", "=", "="} else "text"
        if role == "number" and (i > 0 and tokens[i-1] in {"=", "는", "은"}):
            role = "intermediate_result"
        focus = "high" if role in {"intermediate_result", "number"} else "mid" if role == "operator" else "low"
        rows.append({
            "idx": i,
            "token": tok[:80],
            "role": role,
            "focus_bucket": focus,
            "confidence_bucket": focus,
            "public_safe": True,
            "reasons_public": [role],
        })
    return {"ok": True, "public_safe": True, "source": "current_state_preview", "items": rows}


def simple_token_graph_from_state(state: Dict[str, Any]) -> Dict[str, Any]:
    # v1.13 step4: delegate to public-safe graph builder.
    # Kept for backward compatibility with earlier dashboard endpoints.
    from .token_timeline import build_public_token_relation_graph
    return build_public_token_relation_graph(state, events=[])



def samp_axis_overview_from_state(state: Dict[str, Any] | None = None) -> Dict[str, Any]:
    """Public SAMP/SMAP axis overview.

    v1.13.4 policy:
    - public internal axes remain free as buckets/metadata
    - IRSDCE graph/canonical values are paid-only
    - 12_6/T-engine selector internals remain hidden
    """
    state = state or {}
    extra = state.get("extra") if isinstance(state.get("extra"), dict) else {}
    status = state.get("status") if isinstance(state.get("status"), dict) else {}
    try:
        ent = resolve_entitlement()
    except Exception:
        ent = None
    paid = bool(getattr(ent, "paid_enabled", False))

    def pick(*names, default=None):
        for src in (extra, status, state):
            if isinstance(src, dict):
                for n in names:
                    if n in src:
                        return src.get(n)
        return default

    irsdce_body: Dict[str, Any]
    if paid:
        irsdce_body = {
            "irs_weight": pick("irs_weight", "irs", "irreducible_representation_shift"),
            "dce_weight": pick("dce_weight", "dce", "dimensional_cascade", "d_eff", "deff"),
            "cascade_strength": pick("cascade_strength", "dce_cascade_strength", "cascade"),
            "phase_drift": pick("phase_drift", "drift"),
            "route_pressure": pick("route_pressure", "route"),
            "basis_pressure": pick("basis_pressure", "basis"),
            "public_axis": True,
            "tier_required": "paid",
        }
    else:
        irsdce_body = locked_card("irsdce_geometry")

    return {
        "ok": True,
        "public_safe": True,
        "axis": "SAMP/SMAP public geometry",
        "irsdce": irsdce_body,
        "capability_map": {
            "token_position": True,
            "layer_index": True,
            "hidden_dimension": True,
            "basis_route_phase": True,
            "t_engine_control_axis": "excluded",
            "weighted_selector_12_6": "internal/hidden",
        },
        "redaction_policy": {
            "show": ["public internal axes buckets", "token-layer-dim coverage summary"],
            "paid_show": ["IRSDCE geometry graph", "basis/route/phase canonical pressure"],
            "hide": ["12_6 candidate ranking", "score_components", "weights_json", "selector bias", "native lease internals"],
        },
    }

def static_section(data: Dict[str, Any], section: str) -> Dict[str, Any]:
    """Return one public-safe static debugger section.

    The dashboard can call separate endpoints without recomputing its own
    parsing logic.  Raw Hodge/SMAP internals are intentionally not returned.
    """
    section = str(section or "manifest").strip().lower()
    if section in {"samp", "smap", "axis", "irsdce"}:
        body = samp_axis_overview_from_state(data.get("current_state") if isinstance(data, dict) else {})
        return {
            "ok": True,
            "public_safe": True,
            "section": section,
            "data": body,
            "source": data.get("source") if isinstance(data, dict) else "unknown",
        }
    if section in {"internals", "public_internals", "internal_axes"}:
        # File-backed dashboard mode uses the dedicated endpoint for live
        # run/capture data.  Static section still advertises the public-safe
        # internal axes so the UI remains useful in files-only mode.
        body = {
            "ok": True,
            "public_safe": True,
            "section": "public_internals",
            "axes": [
                "activation_residual_activity",
                "attention_focus",
                "logit_gap",
                "gradient_attribution_signal",
                "layer_token_dim_coverage",
                "mlp_ffn_activity",
                "effective_rank_geometry",
            ],
            "locked_axes": [locked_card("irsdce_geometry")],
            "policy": {
                "show": ["bucketed public internal axes"],
                "paid_show": ["IRSDCE geometry"],
                "hide": ["raw tensors", "raw logits", "raw gradients", "12_6 selector internals"],
            },
        }
        return {
            "ok": True,
            "public_safe": True,
            "section": section,
            "data": body,
            "source": data.get("source") if isinstance(data, dict) else "unknown",
        }
    mapping = {
        "manifest": "manifest",
        "tokenizer": "tokenizer",
        "generation": "generation_config",
        "modules": "module_tree",
        "compat": "paid_compatibility",
    }
    key = mapping.get(section, "manifest")
    body = data.get(key) if isinstance(data, dict) else None
    return {
        "ok": True,
        "public_safe": True,
        "section": section,
        "data": body or {},
        "source": data.get("source") if isinstance(data, dict) else "unknown",
    }
