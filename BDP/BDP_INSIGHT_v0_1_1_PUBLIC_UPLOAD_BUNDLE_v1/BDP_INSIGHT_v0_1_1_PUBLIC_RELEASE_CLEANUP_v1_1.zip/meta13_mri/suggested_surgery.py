from __future__ import annotations

"""Public-safe suggested surgery helpers.

This module converts public token-focus rows into dashboard actions.  It does
not expose raw SMAP/Hodge selector weights, candidate rank tables, or scoring
components.  The suggestions are UX helpers only: clicking one fills existing
L2/Hodge/output-intercept forms, and queueing still passes through the normal
runtime entitlement gate.
"""

import re
from typing import Any, Dict, List

from .public_projector import public_focus
from .static_inspector import simple_token_focus_from_state


def _safe_token(value: Any, limit: int = 80) -> str:
    s = "" if value is None else str(value)
    return s[:limit]


def _is_numericish(token: str) -> bool:
    return bool(re.search(r"\d", token or ""))


def _clean_token(token: str) -> str:
    # Keep the user-facing token usable as a form value while avoiding raw dumps.
    token = _safe_token(token)
    m = re.search(r"-?\d+(?:\.\d+)?", token)
    if m:
        return m.group(0)
    return token.strip()


def build_suggested_surgery_from_state(state: Dict[str, Any], *, max_items: int = 12) -> Dict[str, Any]:
    focus = simple_token_focus_from_state(state)
    rows = list(focus.get("items") or [])
    suggestions: List[Dict[str, Any]] = []

    for row in rows:
        token_raw = _safe_token(row.get("token"))
        token = _clean_token(token_raw)
        if not token:
            continue
        role = str(row.get("role") or "text")[:80]
        numeric = _is_numericish(token)
        focus_bucket = str(row.get("focus_bucket") or row.get("confidence_bucket") or "mid")
        if not (numeric or role in {"intermediate_result", "number", "operator"}):
            continue

        metric = public_focus({"selector": "suggested_surgery", "target_role": role}, role=role, changed=False, condition_passed=None, selector="suggested_surgery")
        base = {
            "token": token,
            "token_preview": token_raw,
            "idx": row.get("idx"),
            "role": role,
            "focus_bucket": focus_bucket,
            "confidence_bucket": metric.get("confidence_bucket"),
            "confidence_percent": metric.get("confidence_percent"),
            "public_safe": True,
            "reasons_public": list(row.get("reasons_public") or [role])[:4],
        }

        # Existing manual L2 swap form autofill.
        suggestions.append({
            **base,
            "id": f"sug_l2_{row.get('idx')}",
            "kind": "suggested_surgery",
            "title": f"Fill L2 manual target: {token}",
            "form_target": "l2_manual",
            "op": "hodge_token_auto",
            "function_id": "l2.swap_token",
            "payload_template": {"old_word": token, "new_word": "", "mode": "swap"},
            "action": "fill_form",
        })

        # Output intercept is most useful for numeric/intermediate results.
        if numeric or role == "intermediate_result":
            selector = "after_equals" if role == "intermediate_result" else "auto"
            suggestions.append({
                **base,
                "id": f"sug_out_{row.get('idx')}",
                "kind": "suggested_surgery",
                "title": f"Fill output intercept target: {token}",
                "form_target": "output_intercept",
                "op": "hodge_output_intercept",
                "function_id": "l2.hodge_output_intercept",
                "payload_template": {"old_word": token, "new_word": "", "selector": selector, "after_tokens": 16, "continuation_tokens": 16},
                "action": "fill_form",
            })

        if len(suggestions) >= max_items:
            break

    return {
        "ok": True,
        "public_safe": True,
        "source": "current_state_preview",
        "count": len(suggestions),
        "items": suggestions[:max_items],
        "note": "Suggestions fill existing forms only. Queueing still uses /api/debug/command and runtime entitlement gate.",
    }
