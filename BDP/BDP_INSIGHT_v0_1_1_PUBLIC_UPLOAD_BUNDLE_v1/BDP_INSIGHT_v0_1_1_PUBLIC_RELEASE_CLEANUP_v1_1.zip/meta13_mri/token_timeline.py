from __future__ import annotations

"""Public-safe token graph and intervention timeline helpers.

This module deliberately emits only public-safe graph/timeline data:
- role labels
- link strength buckets
- focus/confidence buckets
- changed/condition flags
It does not expose raw SMAP/Hodge weights, score components, candidate ranks,
attractor scores, boundary scores, salience values, logits, tensors, or raw
edge weights.
"""

import json
import re
import time
from pathlib import Path
from typing import Any, Dict, Iterable, List, Tuple

from .public_projector import public_focus, strength_bucket


_NUM_RE = re.compile(r"-?\d+(?:\.\d+)?")
_TOKEN_RE = re.compile(r"-?\d+(?:\.\d+)?|[A-Za-z_][A-Za-z0-9_]*|[가-힣]+|[+\-*/=()?:,.;]|[^\s]")


def _safe_str(value: Any, limit: int = 160) -> str:
    if value is None:
        return ""
    return str(value).replace("\x00", "")[:limit]


def _event_ts(ev: Dict[str, Any]) -> float:
    try:
        return float(ev.get("ts") or 0.0)
    except Exception:
        return 0.0


def _read_jsonl(path: Path, limit: int = 400) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    try:
        if not path.exists():
            return rows
        lines = [ln for ln in path.read_text(encoding="utf-8", errors="replace").splitlines() if ln.strip()]
        for ln in lines[-limit:]:
            try:
                val = json.loads(ln)
                if isinstance(val, dict):
                    rows.append(val)
            except Exception:
                continue
    except Exception:
        pass
    return rows


def _text_from_state(state: Dict[str, Any]) -> str:
    extra = state.get("extra") or {}
    # Prefer actual/partial assistant text. Fall back to prompt preview.
    for key in ("answer_preview", "partial_answer_preview", "output_preview", "prompt_preview"):
        val = extra.get(key)
        if val:
            return _safe_str(val, 4000)
    return ""


def _tokenize_public(text: str, max_tokens: int = 120) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    for i, m in enumerate(_TOKEN_RE.finditer(text or "")):
        if i >= max_tokens:
            break
        tok = m.group(0)
        if _NUM_RE.fullmatch(tok):
            role = "number"
        elif tok in {"+", "-", "*", "/", "="}:
            role = "operator"
        elif tok in {"정답", "결과", "값"}:
            role = "result_cue"
        else:
            role = "text"
        rows.append({
            "idx": i,
            "token": _safe_str(tok, 80),
            "span": [m.start(), m.end()],
            "role": role,
            "public_safe": True,
        })

    # Upgrade result roles: number after "=" or after result cue becomes result-ish.
    for i, row in enumerate(rows):
        if row.get("role") != "number":
            continue
        prev = rows[i - 1]["token"] if i > 0 else ""
        prev2 = rows[i - 2]["token"] if i > 1 else ""
        if prev == "=" or prev2 == "=":
            row["role"] = "intermediate_result"
        elif prev in {"정답", "결과", "값"} or prev2 in {"정답", "결과", "값"}:
            row["role"] = "final_result"
        # First number on a later line after a prior result often acts as carried state.
        prefix = (text or "")[: int(row["span"][0])]
        if "\n" in prefix and any(r.get("role") in {"intermediate_result", "final_result"} for r in rows[:i]):
            if row["role"] == "number":
                row["role"] = "carried_operand"

    # Attach public focus buckets.
    for row in rows:
        metric = public_focus({"selector": "token_relation_graph", "target_role": row.get("role")}, role=row.get("role") or "text", changed=False, condition_passed=None, selector="token_relation_graph")
        row["focus_bucket"] = metric.get("focus_bucket")
        row["confidence_bucket"] = metric.get("confidence_bucket")
        row["reasons_public"] = [row.get("role") or "text"]
    return rows


def _edge(source: int, target: int, relation: str, *, ctx: Dict[str, Any] | None = None, strength: Any = None) -> Dict[str, Any]:
    bucket = strength if isinstance(strength, str) and strength in {"low", "mid", "high", "strong"} else strength_bucket(strength or relation, ctx=ctx or {"relation": relation})
    if bucket == "strong":
        bucket = "high"
    return {
        "source": source,
        "target": target,
        "relation": relation,
        "strength_bucket": bucket,
        "public_safe": True,
    }


def _add_math_edges(tokens: List[Dict[str, Any]], edges: List[Dict[str, Any]]) -> None:
    # Local pattern: number operator number = number
    for i in range(0, max(0, len(tokens) - 4)):
        a, op, b, eq, c = tokens[i:i+5]
        if a.get("role") in {"number", "carried_operand"} and op.get("token") in {"+", "-", "*", "/"} and b.get("role") in {"number", "carried_operand"} and eq.get("token") == "=" and c.get("role") in {"number", "intermediate_result", "final_result"}:
            edges.append(_edge(a["idx"], op["idx"], "operand_to_operator", strength="high"))
            edges.append(_edge(b["idx"], op["idx"], "operand_to_operator", strength="high"))
            edges.append(_edge(op["idx"], c["idx"], "operator_to_result", strength="high"))
            edges.append(_edge(a["idx"], c["idx"], "result_dependency", strength="mid"))
            edges.append(_edge(b["idx"], c["idx"], "result_dependency", strength="mid"))

    # Carry repeated/result numbers forward without raw score.
    result_nums = [r for r in tokens if r.get("role") in {"intermediate_result", "final_result"} and _NUM_RE.fullmatch(str(r.get("token") or ""))]
    for src in result_nums[:12]:
        for dst in tokens:
            if dst["idx"] <= src["idx"]:
                continue
            if dst.get("token") == src.get("token"):
                edges.append(_edge(src["idx"], dst["idx"], "carried_forward", strength="high"))
                break


def _intervention_markers(events: Iterable[Dict[str, Any]]) -> List[Dict[str, Any]]:
    markers: List[Dict[str, Any]] = []
    kinds = {
        "paid_surgery_applied",
        "paid_output_intercept_applied",
        "paid_surgery_noop",
        "l1_prompt_rewrite_applied",
        "l1_mid_rewrite_applied",
        "blocked_command",
    }
    for ev in events or []:
        kind = str(ev.get("kind") or "")
        if kind not in kinds:
            continue
        meta = ev.get("public_meta") if isinstance(ev.get("public_meta"), dict) else ev.get("meta") if isinstance(ev.get("meta"), dict) else {}
        extra = ev.get("extra") if isinstance(ev.get("extra"), dict) else {}
        markers.append({
            "kind": kind,
            "ts": _event_ts(ev),
            "route": _safe_str(ev.get("route") or meta.get("route") or extra.get("route"), 120),
            "changed": bool(ev.get("changed") or meta.get("changed") or extra.get("changed")) if (ev.get("changed") is not None or meta.get("changed") is not None or extra.get("changed") is not None) else None,
            "condition_passed": meta.get("condition_passed") or extra.get("condition_passed"),
            "preview_only": bool(ev.get("preview_only")),
            "actual_model_event": ev.get("actual_model_event"),
            "public_safe": True,
        })
    return markers[-20:]


def build_public_token_relation_graph(state: Dict[str, Any], events: Iterable[Dict[str, Any]] | None = None) -> Dict[str, Any]:
    text = _text_from_state(state)
    tokens = _tokenize_public(text)
    nodes = [
        {
            "id": row["idx"],
            "label": row["token"],
            "role": row["role"],
            "focus_bucket": row.get("focus_bucket"),
            "confidence_bucket": row.get("confidence_bucket"),
            "reasons_public": row.get("reasons_public") or [],
            "public_safe": True,
        }
        for row in tokens
    ]
    edges: List[Dict[str, Any]] = []
    for a, b in zip(tokens, tokens[1:]):
        rel = "next_token"
        strength = "mid" if a.get("role") != "text" or b.get("role") != "text" else "low"
        edges.append(_edge(a["idx"], b["idx"], rel, strength=strength))
    _add_math_edges(tokens, edges)

    # Attach a public IRSDCE geometry axis.  Unlike 12_6 Hodge/SMAP selector
    # internals, IRSDCE weights are part of the public theory/geometry axis and
    # may be displayed in the graph.
    irsdce_axis_summary = None
    try:
        from .irsdce_geometry import build_irsdce_geometry_graph
        irg = build_irsdce_geometry_graph(state, events or [])
        irsdce_axis_summary = irg.get("axis_summary")
        # Add one compact virtual axis node rather than exposing selector internals.
        axis_id = "irsdce_axis"
        if irsdce_axis_summary:
            nodes.append({
                "id": axis_id,
                "label": "IRS-DCE",
                "role": "geometry_axis",
                "focus_bucket": "high",
                "confidence_bucket": "high",
                "irs_weight": irsdce_axis_summary.get("irs_weight"),
                "dce_weight": irsdce_axis_summary.get("dce_weight"),
                "cascade_strength": irsdce_axis_summary.get("cascade_strength"),
                "phase_drift": irsdce_axis_summary.get("phase_drift"),
                "route_pressure": irsdce_axis_summary.get("route_pressure"),
                "basis_pressure": irsdce_axis_summary.get("basis_pressure"),
                "public_axis": "IRSDCE",
                "public_safe": True,
            })
            for n in list(nodes)[:80]:
                if n.get("role") in {"intermediate_result", "final_result", "carried_operand", "number"}:
                    edges.append({
                        "source": n.get("id"),
                        "target": axis_id,
                        "relation": "irsdce_axis_projection",
                        "irs_weight": irsdce_axis_summary.get("irs_weight"),
                        "dce_weight": irsdce_axis_summary.get("dce_weight"),
                        "strength_bucket": "high" if max(float(irsdce_axis_summary.get("irs_weight") or 0), float(irsdce_axis_summary.get("dce_weight") or 0)) >= 0.72 else "mid",
                        "public_axis": "IRSDCE",
                        "public_safe": True,
                    })
                    break
    except Exception:
        irsdce_axis_summary = None

    markers = _intervention_markers(events or [])
    # Add virtual marker nodes at the end. They do not reveal raw internals.
    start_id = len(nodes)
    for j, mk in enumerate(markers[-8:]):
        nid = start_id + j
        nodes.append({
            "id": nid,
            "label": "intervention",
            "role": mk.get("kind"),
            "focus_bucket": "high" if mk.get("actual_model_event") else "mid",
            "confidence_bucket": "high" if mk.get("actual_model_event") else "mid",
            "marker": True,
            "public_safe": True,
        })
        # Link marker to the first high-focus target if present.
        target = next((n["id"] for n in nodes if n.get("role") in {"intermediate_result", "final_result", "number"}), None)
        if target is not None and target != nid:
            edges.append(_edge(nid, target, "intervention_target", strength="high"))

    return {
        "ok": True,
        "public_safe": True,
        "source": "current_state_preview+events",
        "graph_kind": "token_relation_public",
        "text_preview": _safe_str(text, 240),
        "nodes": nodes[:160],
        "edges": edges[:260],
        "markers": markers,
        "irsdce_axis_summary": irsdce_axis_summary,
        "legend": {
            "node_role": "text/number/operator/intermediate_result/final_result/carried_operand/intervention/geometry_axis",
            "edge_strength": "low/mid/high buckets; IRSDCE public axis weights are shown; 12_6 selector internals remain hidden",
            "public_safe": True,
        },
    }


def build_public_intervention_timeline(events: Iterable[Dict[str, Any]]) -> Dict[str, Any]:
    timeline_kinds = {
        "checkpoint",
        "paid_command_accepted",
        "paid_surgery_applied",
        "paid_output_intercept_applied",
        "paid_surgery_noop",
        "l1_prompt_rewrite_applied",
        "l1_mid_rewrite_enter",
        "l1_mid_rewrite_applied",
        "l1_mid_rewrite_exit",
        "blocked_command",
        "abort",
        "freeze_enter",
        "freeze_exit",
    }
    rows: List[Dict[str, Any]] = []
    for ev in sorted(list(events or []), key=_event_ts):
        kind = str(ev.get("kind") or "")
        if kind not in timeline_kinds:
            continue
        extra = ev.get("extra") if isinstance(ev.get("extra"), dict) else {}
        meta = ev.get("public_meta") if isinstance(ev.get("public_meta"), dict) else ev.get("meta") if isinstance(ev.get("meta"), dict) else {}
        route = ev.get("route") or extra.get("route") or meta.get("route")
        phase = ev.get("phase") or extra.get("phase")
        changed = ev.get("changed") if ev.get("changed") is not None else meta.get("changed")
        condition = meta.get("condition_passed") if isinstance(meta, dict) else None
        answer_preview = _safe_str(extra.get("answer_preview") or extra.get("partial_answer_preview"), 160)
        prompt_preview = _safe_str(extra.get("prompt_preview"), 160)
        item = {
            "kind": kind,
            "ts": _event_ts(ev),
            "phase": _safe_str(phase, 80),
            "route": _safe_str(route, 120),
            "changed": changed,
            "condition_passed": condition,
            "actual_model_event": ev.get("actual_model_event"),
            "preview_only": ev.get("preview_only"),
            "answer_preview": answer_preview if kind == "checkpoint" else "",
            "prompt_preview": prompt_preview if kind == "checkpoint" else "",
            "public_safe": True,
        }
        # Coarse event role for UI grouping, not raw scoring.
        if kind == "checkpoint" and str(phase).startswith("before"):
            item["timeline_role"] = "before"
        elif kind == "checkpoint" and str(phase).startswith("after"):
            item["timeline_role"] = "after"
        elif "applied" in kind:
            item["timeline_role"] = "intervention_applied"
        elif "noop" in kind:
            item["timeline_role"] = "intervention_noop"
        elif "blocked" in kind:
            item["timeline_role"] = "blocked"
        else:
            item["timeline_role"] = "control"
        rows.append(item)
    return {
        "ok": True,
        "public_safe": True,
        "source": "events_jsonl",
        "count": len(rows[-80:]),
        "items": rows[-80:],
        "note": "Timeline is public-safe. Raw selector weights, score components, and candidate ranks are not exposed.",
    }


def load_public_graph_from_files(run_root: Path, state: Dict[str, Any] | None = None) -> Dict[str, Any]:
    dyn = run_root / "dynamic_debug"
    state = state or {}
    events = _read_jsonl(dyn / "events.jsonl")
    return build_public_token_relation_graph(state, events)


def load_public_timeline_from_files(run_root: Path) -> Dict[str, Any]:
    dyn = run_root / "dynamic_debug"
    events = _read_jsonl(dyn / "events.jsonl")
    return build_public_intervention_timeline(events)
