from __future__ import annotations

from pathlib import Path
import py_compile
import re
import shutil

ROOT = Path(__file__).resolve().parents[1]

FORBIDDEN_FILENAMES = {
    "rapidapi_key.txt",
    "rapidapi_proxy_secret.txt",
    "auth_token.txt",
    "bdp_modal_url.txt",
    "server_kernel.py",
}

PUBLIC_FILES = [
    "README.md",
    "example_run.py",
    "example_interactive.py",
    "examples/example_direct_api.py",
    "examples/example_gemma.py",
]

COMPILE_TARGETS = [
    "example_run.py",
    "example_interactive.py",
    "bdp_insight/api.py",
    "bdp_insight/cli.py",
    "bdp_insight/launchers.py",
    "bdp_insight/attach.py",
    "bdp_insight/capture_basic.py",
]

SKIP_DIR_NAMES = {
    ".git",
    ".hg",
    ".svn",
    ".mypy_cache",
    ".pytest_cache",
    ".ruff_cache",
    ".tox",
    "dist",
    "build",
    "site",
    "htmlcov",
}

SKIP_PREFIXES = (
    ".venv",
    "venv",
    "env",
)


def fail(msg: str) -> None:
    print("[FAIL]", msg)
    raise SystemExit(1)


def ok(msg: str) -> None:
    print("[OK]", msg)


def warn(msg: str) -> None:
    print("[WARN]", msg)


def _is_skipped_dir(path: Path) -> bool:
    name = path.name
    if name in SKIP_DIR_NAMES:
        return True
    if any(name.startswith(prefix) for prefix in SKIP_PREFIXES):
        return True
    if name.endswith(".egg-info"):
        return True
    return False


def _iter_project_files():
    """Iterate project files while ignoring local venv/build/cache dirs."""
    stack = [ROOT]
    while stack:
        cur = stack.pop()
        try:
            children = list(cur.iterdir())
        except Exception:
            continue
        for child in children:
            if child.is_dir():
                if _is_skipped_dir(child):
                    continue
                stack.append(child)
            else:
                yield child


def clean_pycache() -> int:
    count = 0
    stack = [ROOT]
    while stack:
        cur = stack.pop()
        try:
            children = list(cur.iterdir())
        except Exception:
            continue
        for child in children:
            if child.is_dir():
                if _is_skipped_dir(child):
                    continue
                if child.name == "__pycache__":
                    shutil.rmtree(child, ignore_errors=True)
                    count += 1
                else:
                    stack.append(child)
    return count


def main() -> int:
    cleaned = clean_pycache()
    if cleaned:
        ok(f"removed __pycache__ directories: {cleaned}")

    for rel in ["README.md", "pyproject.toml", "MANIFEST.in", "LICENSE", "example_run.py", "example_interactive.py"]:
        if not (ROOT / rel).exists():
            fail(f"missing {rel}")
    ok("required root files exist")

    for p in _iter_project_files():
        if p.name in FORBIDDEN_FILENAMES:
            fail(f"forbidden file present: {p}")
        if p.name.startswith("server_kernel") and p.suffix in {".so", ".pyd", ".dll"}:
            fail(f"server kernel binary must not ship in client package: {p}")
        if p.suffix == ".bat":
            fail(f"BAT file should not ship in release package: {p}")

    ok("forbidden filenames absent")

    for rel in PUBLIC_FILES:
        fp = ROOT / rel
        if not fp.exists():
            continue
        text = fp.read_text(encoding="utf-8", errors="replace")
        if re.search(r"X-RapidAPI-Proxy-Secret|rapidapi_proxy_secret|AUTH_TOKEN\s*=", text, re.I):
            fail(f"provider-side secret wording found in public file: {rel}")

    ok("public files do not expose provider-side secret wording")

    for rel in COMPILE_TARGETS:
        fp = ROOT / rel
        if not fp.exists():
            fail(f"compile target missing: {rel}")
        py_compile.compile(str(fp), doraise=True)

    cleaned_after_compile = clean_pycache()
    if cleaned_after_compile:
        ok(f"removed post-compile __pycache__ directories: {cleaned_after_compile}")

    ok("py_compile passed")
    ok("release-ready checks passed")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
